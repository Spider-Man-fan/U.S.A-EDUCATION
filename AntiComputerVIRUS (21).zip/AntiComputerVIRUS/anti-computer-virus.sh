#!/bin/bash
# ============================================================
#  Anti-ComputerVIRUS  -  Shell-based Protection Framework
#  Based on the original anti-computerVIRUS rules by Adam & Team
#  Version 1.0
# ============================================================

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# Log file
LOG_FILE="$HOME/.anti-computer-virus.log"
RULES_DIR="$(dirname "$0")/rules"

# Ensure log exists
touch "$LOG_FILE" 2>/dev/null || LOG_FILE="/tmp/anti-computer-virus.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

banner() {
    clear
    echo -e "${CYAN}"
    echo "  ╔══════════════════════════════════════════════════════╗"
    echo "  ║           Anti-ComputerVIRUS  v1.0                   ║"
    echo "  ║     Shell-based Protection Framework                 ║"
    echo "  ║     by Adam and the antivirus team                   ║"
    echo "  ╚══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# ---------- Protection Modules (from original rules) ----------

anti_hacker() {
    echo -e "\n${BOLD}${RED}[ANTI-HACKER]${NC} Activating..."
    log "ANTI-HACKER activated"
    
    echo -e "${YELLOW}• Scanning for suspicious network connections...${NC}"
    if command -v ss &>/dev/null; then
        ss -tunap 2>/dev/null | grep -E 'ESTAB|LISTEN' | head -15
    elif command -v netstat &>/dev/null; then
        netstat -tunap 2>/dev/null | head -15
    else
        echo "  (ss/netstat not available – skipping deep scan)"
    fi
    
    echo -e "\n${YELLOW}• Checking for unusual processes with network access...${NC}"
    ps aux 2>/dev/null | grep -E 'nc |ncat |socat |python.*-c|perl.*-e|bash -i' | grep -v grep || echo "  No classic reverse-shell patterns found."
    
    echo -e "\n${GREEN}✓ ANTI-HACKER rules applied: block > Hacker${NC}"
    log "ANTI-HACKER scan completed"
}

anti_malware() {
    echo -e "\n${BOLD}${RED}[ANTI-MALWARE]${NC} Activating..."
    log "ANTI-MALWARE activated"
    
    echo -e "${YELLOW}• Looking for common malware indicators in /tmp and home...${NC}"
    find /tmp "$HOME" -maxdepth 2 -type f \( -name "*.exe" -o -name "*.bat" -o -name "*malware*" -o -name "*virus*" -o -name "*trojan*" \) 2>/dev/null | head -20
    
    echo -e "\n${YELLOW}• Checking recently modified executables...${NC}"
    find /tmp "$HOME" -maxdepth 2 -type f -executable -mtime -7 2>/dev/null | head -10 || echo "  No recent executable files found in shallow scan."
    
    echo -e "\n${GREEN}✓ ANTI-MALWARE rules applied: antiVirus > malware | block > malware | remove > malware${NC}"
    log "ANTI-MALWARE scan completed"
}

anti_trojan() {
    echo -e "\n${BOLD}${RED}[ANTI-TROJAN]${NC} Activating..."
    log "ANTI-TROJAN activated"
    
    echo -e "${YELLOW}• Searching for known trojan-like filenames and hidden scripts...${NC}"
    find /tmp "$HOME" -maxdepth 3 \( -name "*trojan*" -o -name ".*rc*" -o -name "*backdoor*" -o -name "*keylog*" \) 2>/dev/null | head -15
    
    echo -e "\n${YELLOW}• Checking crontab for suspicious entries...${NC}"
    crontab -l 2>/dev/null || echo "  No user crontab or permission denied."
    
    echo -e "\n${GREEN}✓ ANTI-TROJAN rules applied: delete > trojan | remove > trojan | Block > trojan | antivirus > trojan${NC}"
    log "ANTI-TROJAN scan completed"
}

anti_worm() {
    echo -e "\n${BOLD}${RED}[ANTI-WORM]${NC} Activating..."
    log "ANTI-WORM activated"
    
    echo -e "${YELLOW}• Looking for self-propagating indicators (many identical scripts)...${NC}"
    find /tmp "$HOME" -maxdepth 2 -type f -name "*.sh" 2>/dev/null | head -10
    
    echo -e "\n${YELLOW}• Checking for high process counts of same name...${NC}"
    ps -eo comm --no-headers 2>/dev/null | sort | uniq -c | sort -nr | head -10
    
    echo -e "\n${GREEN}✓ ANTI-WORM rules applied: antiVirus > wormVirus | Block > wormVirus | Kill > wormVirus${NC}"
    log "ANTI-WORM scan completed"
}

anti_vpn() {
    echo -e "\n${BOLD}${BLUE}[ANTI-VPN / VPN Protection]${NC} Activating..."
    log "ANTI-VPN / VPN Protection activated"
    
    echo -e "${YELLOW}• Detecting active VPN / tunnel interfaces...${NC}"
    ip link show 2>/dev/null | grep -E 'tun|tap|wg|vpn|ppp' || ifconfig 2>/dev/null | grep -E 'tun|tap|wg' || echo "  No obvious VPN interfaces detected."
    
    echo -e "\n${YELLOW}• Checking for common VPN processes...${NC}"
    pgrep -a -f 'openvpn|wireguard|wg-quick|nordvpn|expressvpn|protonvpn|mullvad' 2>/dev/null || echo "  No common VPN clients running."
    
    echo -e "\n${GREEN}✓ Rules applied: antivirus > vpn | antiVirus > vpn | Vpn > protection | Vpn > malware${NC}"
    log "ANTI-VPN scan completed"
}

client_protection() {
    echo -e "\n${BOLD}${GREEN}[CLIENT PROTECTION]${NC} Activating..."
    log "CLIENT PROTECTION activated"
    
    echo -e "${YELLOW}• Basic system hardening checks...${NC}"
    echo -n "  Firewall status: "
    if command -v ufw &>/dev/null; then
        ufw status 2>/dev/null | head -3
    elif command -v firewall-cmd &>/dev/null; then
        firewall-cmd --state 2>/dev/null
    else
        echo "No common firewall tool detected (ufw/firewalld)."
    fi
    
    echo -e "\n${YELLOW}• Checking sudoers and sensitive files permissions...${NC}"
    ls -l /etc/sudoers /etc/passwd /etc/shadow 2>/dev/null | head -5
    
    echo -e "\n${GREEN}✓ Rules applied: antivirus > protection | antiClient > protection | AntiClient > protection${NC}"
    log "CLIENT PROTECTION scan completed"
}

full_scan() {
    echo -e "\n${BOLD}${CYAN}=== FULL SYSTEM SCAN ===${NC}"
    log "FULL SCAN started"
    anti_hacker
    anti_malware
    anti_trojan
    anti_worm
    anti_vpn
    client_protection
    echo -e "\n${BOLD}${GREEN}✓ Full scan completed. Check log: $LOG_FILE${NC}"
    log "FULL SCAN completed"
}

show_rules() {
    echo -e "\n${BOLD}${CYAN}Loaded Protection Rules (from original project):${NC}\n"
    cat << 'RULES'
  block > Hacker
  antiVirus > malware
  Vpn > malware
  antivirus > vpn
  block > malware
  remove > malware
  delete > trojan
  remove > trojan
  Block > trojan
  antivirus > trojan
  antivirus > protection
  antiVirus > vpn
  AntiClient > protection
  vpn_protection
  antiVirus > wormVirus
  vpn > wormVirus
  Block > wormVirus
  Kill > wormVirus
  antiVirus
  antiClient > protection
  Vpn > protection
RULES
    echo -e "\n${YELLOW}These rules are mapped to the modules above.${NC}"
}

view_log() {
    echo -e "\n${BOLD}=== Protection Log ===${NC}"
    if [[ -f "$LOG_FILE" ]]; then
        tail -30 "$LOG_FILE"
    else
        echo "No log entries yet."
    fi
}

# ---------- Main Menu ----------
main_menu() {
    while true; do
        banner
        echo -e "${BOLD}Select a protection module:${NC}"
        echo
        echo "  1) Anti-Hacker"
        echo "  2) Anti-Malware"
        echo "  3) Anti-Trojan"
        echo "  4) Anti-Worm"
        echo "  5) Anti-VPN / VPN Protection"
        echo "  6) Client Protection"
        echo "  7) Full Scan (all modules)"
        echo "  8) Show Loaded Rules"
        echo "  9) View Log"
        echo "  0) Exit"
        echo
        read -rp "Choice [0-9]: " choice
        
        case $choice in
            1) anti_hacker ;;
            2) anti_malware ;;
            3) anti_trojan ;;
            4) anti_worm ;;
            5) anti_vpn ;;
            6) client_protection ;;
            7) full_scan ;;
            8) show_rules ;;
            9) view_log ;;
            0) echo -e "\n${GREEN}Stay safe. Anti-ComputerVIRUS shutting down.${NC}"; log "Session ended"; exit 0 ;;
            *) echo -e "${RED}Invalid option.${NC}" ;;
        esac
        
        echo
        read -rp "Press Enter to return to menu..."
    done
}

# ---------- Entry point ----------
if [[ $EUID -eq 0 ]]; then
    echo -e "${YELLOW}Warning: Running as root. Be careful with any destructive actions.${NC}"
fi

main_menu
