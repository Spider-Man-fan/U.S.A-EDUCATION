#!/usr/bin/env python3
"""
Anti-ComputerVIRUS v7.3  -  Settings + Auto-Delete + Real-Time File Monitoring + AI + GUI
Python Protection Framework
Based on the original rules by Adam and the antivirus team

SAFETY: Auto-delete is OFF by default. Enable it only if you understand the risk.
Every deleted file is first copied to quarantine.
"""

import os
import sys
import time
import hashlib
import subprocess
import threading
import re
import shutil
import math
from datetime import datetime
from pathlib import Path
from collections import deque, Counter

# ===================== Try GUI =====================
try:
    import tkinter as tk
    from tkinter import scrolledtext, messagebox
    HAS_GUI = True
except ImportError:
    HAS_GUI = False

# ===================== Config =====================
VERSION = "10.3"
LOG_FILE = Path.home() / ".anti-computer-virus.log"
QUARANTINE_DIR = Path.home() / ".anti-computer-virus-quarantine"
BACKUP_DIR = Path.home() / ".anti-computer-virus-backups"
MAX_LOG_LINES = 1500
MONITOR_INTERVAL = 3.0
FILE_WATCH_INTERVAL = 2.0
FILE_WATCH_DEPTH = 2
STATUS_REPORT_INTERVAL = 30  # seconds between status reports when enabled

# Global settings
AUTO_DELETE_ENABLED = False
AUTO_DELETE_THRESHOLD = 60
STATUS_REPORT_ENABLED = False
LOCKDOWN_MODE = False
BLACK_MODE = False
USE_GROK = False
GROK_API_KEY = "A45Aihel1rtp"
LOCKDOWN_FREEZE_SEC = 1.0

# Local account (username + password hash stored under home)
ACCOUNT_FILE = Path.home() / ".anti-computer-virus-account.json"

SUSPICIOUS_PROCESS_PATTERNS = [
    r"nc\s+-", r"ncat\s+", r"socat\s+", r"bash\s+-i", r"sh\s+-i",
    r"python.*-c\s+['\"]", r"perl\s+-e", r"ruby\s+-e", r"php\s+-r",
    r"/dev/tcp/", r"base64\s+-d", r"wget\s+.*\|", r"curl\s+.*\|",
]

RISKY_PORTS = {"4444", "5555", "6666", "1234", "31337", "4445", "1337", "8888", "9999", "4443"}

WEIGHTS = {
    "suspicious_name": 25, "high_entropy": 20, "executable_in_tmp": 18,
    "world_writable": 15, "suid": 30, "risky_port": 35,
    "reverse_shell_pattern": 40, "recent_modify": 10, "hidden_file": 12,
    "known_bad_ext": 22, "network_listen": 15, "multiple_identical": 28,
}

WATCH_DIRS = [
    "/tmp",
    "/var/tmp",
    str(Path.home()),
    str(Path.home() / "Downloads"),
    str(Path.home() / "Desktop"),
]

NEVER_DELETE = {
    "/", "/home", "/etc", "/usr", "/bin", "/sbin", "/lib", "/lib64",
    "/boot", "/dev", "/proc", "/sys", "/run", "/var", "/opt",
    str(Path.home()),
}

# ===================== Helpers =====================

def log(msg: str, level: str = "INFO"):
    try:
        with open(LOG_FILE, "a") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] [{level}] {msg}\n")
        if LOG_FILE.exists():
            lines = LOG_FILE.read_text().splitlines()
            if len(lines) > MAX_LOG_LINES:
                LOG_FILE.write_text("\n".join(lines[-MAX_LOG_LINES:]) + "\n")
    except Exception:
        pass

def run_cmd(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip()
    except Exception:
        return ""

def file_hash(path: Path) -> str:
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return "ERROR"

def ensure_quarantine():
    QUARANTINE_DIR.mkdir(mode=0o700, exist_ok=True)

def _hash_password(password: str, salt: str = "") -> str:
    raw = (salt + password).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def load_account() -> dict:
    """Return account dict or empty dict if none."""
    try:
        if ACCOUNT_FILE.exists():
            import json
            return json.loads(ACCOUNT_FILE.read_text())
    except Exception:
        pass
    return {}

def save_account(username: str, password: str) -> bool:
    try:
        import json
        salt = hashlib.sha256(os.urandom(16)).hexdigest()[:16]
        data = {
            "username": username.strip(),
            "salt": salt,
            "password_hash": _hash_password(password, salt),
            "created": datetime.now().isoformat(),
        }
        ACCOUNT_FILE.write_text(json.dumps(data, indent=2))
        try:
            os.chmod(ACCOUNT_FILE, 0o600)
        except Exception:
            pass
        log(f"Account created for user={username}")
        return True
    except Exception as e:
        log(f"save_account failed: {e}", "ERROR")
        return False

def verify_account(username: str, password: str) -> bool:
    acc = load_account()
    if not acc:
        return False
    if acc.get("username") != username.strip():
        return False
    return acc.get("password_hash") == _hash_password(password, acc.get("salt", ""))


def chatgpt_reply(user_text: str, api_key: str) -> str:
    """Call xAI Grok API. Returns reply or error message."""
    try:
        import urllib.request
        import json
        url = "https://api.x.ai/v1/chat/completions"
        data = json.dumps({
            "model": "grok-2-latest",
            "messages": [
                {"role": "system", "content": "You are a helpful antivirus and computer security assistant. Keep answers concise and practical."},
                {"role": "user", "content": user_text}
            ],
            "max_tokens": 400,
            "temperature": 0.7
        }).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        })
        with urllib.request.urlopen(req, timeout=20) as resp:
            result = json.loads(resp.read().decode())
            return result["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"Grok error: {e}\nFalling back to local helper.\n\n" + ai_helper_reply(user_text)


def ai_helper_reply(user_text: str) -> str:

    """Built-in helper: more accurate intent matching + file scoring."""
    raw = (user_text or "").strip()
    t = raw.lower()
    if not t:
        return "Ask about a threat type, a feature, or paste a file path to analyze."

    # --- File path detection (most specific first) ---
    path_candidate = None
    # quoted path
    m = re.search(r'["\']([^"\']+)["\']', raw)
    if m and ("/" in m.group(1) or "\\" in m.group(1)):
        path_candidate = m.group(1)
    else:
        # bare path-looking token
        for tok in raw.replace(",", " ").split():
            tok = tok.strip().strip('"').strip("'")
            if tok.startswith("/") or (len(tok) > 3 and ("/" in tok or tok.endswith((".exe", ".bat", ".sh", ".py", ".js", ".dll", ".scr")))):
                path_candidate = tok
                break
    if path_candidate:
        p = Path(path_candidate)
        if p.exists() and p.is_file():
            try:
                score, reasons = ai_score_file(p)
                level = "HIGH RISK" if score >= 60 else ("MEDIUM" if score >= 40 else "LOW")
                tips = []
                if score >= 60:
                    tips.append("Treat as high risk: quarantine is recommended.")
                    if AUTO_DELETE_ENABLED:
                        tips.append("Auto-Delete is ON - originals at this score may be removed after quarantine.")
                    else:
                        tips.append("Auto-Delete is OFF - file will not be auto-removed.")
                elif score >= 40:
                    tips.append("Worth reviewing; not automatically treated as critical.")
                else:
                    tips.append("No strong malware signals from heuristics alone.")
                reason_txt = "; ".join(reasons) if reasons else "no strong heuristic signals"
                return (
                    f"Analysis of: {p}\n"
                    f"AI score: {score}/100 → {level}\n"
                    f"Signals: {reason_txt}\n"
                    f"Size: {p.stat().st_size} bytes\n"
                    + "\n".join(f"• {x}" for x in tips)
                )
            except Exception as e:
                return f"Could not analyze that file: {e}"
        return (
            f"No readable file at: {path_candidate}\n"
            "Check the path exists, or ask a general question (e.g. what is a trojan?)."
        )

    # --- Intent keywords (order matters) ---
    def has(*words):
        return any(w in t for w in words)

    if has("hello", "hi ", "hey", "good morning", "good evening") and len(t) < 40:
        return (
            "Hello - AI Helper ready.\n"
            "Try:\n"
            "• what is malware / trojan / worm / ransomware?\n"
            "• how does quarantine / auto-delete / monitor work?\n"
            "• paste a full file path to score it"
        )

    if has("thank"):
        return "You're welcome. Ask anytime about threats or this app's features."

    if has("ransomware"):
        return (
            "Ransomware encrypts files and demands payment.\n"
            "Prevention: backups, avoid unknown attachments, don't run random .exe from /tmp or Downloads.\n"
            "This app flags suspicious names, high entropy (packed/encrypted-looking data), and temp executables."
        )

    if has("phishing", "scam email"):
        return (
            "Phishing tricks you into giving passwords or running malware via fake messages.\n"
            "This antivirus focuses on files/processes on the PC, not email content.\n"
            "Don't open unexpected links or attachments; verify senders out-of-band."
        )

    if has("false positive", "false alarm"):
        return (
            "False positives can happen with heuristics (e.g. installers in /tmp, high-entropy packs).\n"
            "Keep Auto-Delete OFF unless you trust the score.\n"
            "Check quarantine notes and the listed reasons before deleting anything important."
        )

    if has("quarantine"):
        return (
            f"Quarantine folder: {QUARANTINE_DIR}\n"
            "Suspicious files are *copied* here first. Originals stay unless Auto-Delete is ON and score ≥ 60.\n"
            "Open View Quarantine on the main panel to list items."
        )

    if has("auto-delete", "autodelete", "auto delete", "delete malware"):
        return (
            "Auto-Delete flow:\n"
            "1) Copy to quarantine\n"
            "2) If enabled and AI score ≥ 60 → delete original\n"
            "Protected system paths are never deleted.\n"
            "Toggle Auto-Delete on the main left panel (confirmation required)."
        )

    if has("real-time", "realtime", "monitor", "live protection"):
        return (
            "Real-time monitor watches: /tmp, /var/tmp, home, Downloads, Desktop.\n"
            "It scores new/modified files and can alert on risky processes/ports.\n"
            "Click Start File + AI Monitor. Status Report (Settings) posts summaries every 30s."
        )

    if has("trojan"):
        return (
            "Trojan: malware disguised as useful software; may install backdoors or steal data.\n"
            "This app's Anti-Trojan checks names (*trojan*, *backdoor*, *keylog*), crontab, and SUID in temp areas.\n"
            "Run Anti-Trojan or AI Threat Scan from the main menu."
        )

    if has("worm"):
        return (
            "Worm: self-replicating malware (often many identical scripts/processes).\n"
            "Anti-Worm compares hashes of .sh files and process name frequency.\n"
            "Use the Anti-Worm module for a dedicated pass."
        )

    if has("rootkit"):
        return (
            "Rootkits hide malware from normal tools.\n"
            "This educational scanner does not do deep kernel rootkit detection.\n"
            "Use integrity checks, watch unexpected SUID files, and keep the OS updated."
        )

    if has("malware", "virus", "threat"):
        return (
            "Malware = software designed to harm or abuse a system.\n"
            "Scoring uses: suspicious names, extensions (.exe/.bat), /tmp executables, world-writable/SUID, "
            "recent changes, and high entropy (often packing/encryption).\n"
            "≥40 medium interest · ≥60 high risk."
        )

    if has("entropy"):
        return (
            "Entropy measures how random file bytes look.\n"
            "Very high entropy can mean compression, encryption, or packed malware - a signal, not proof.\n"
            "Combined with location and name it raises the AI score."
        )

    if has("vpn"):
        return (
            "Anti-VPN module lists tunnel interfaces (tun/tap/wg) and known VPN processes.\n"
            "It reports; it does not disconnect your VPN automatically."
        )

    if has("lockdown"):
        return (
            "Lockdown Mode: optional 1-second UI freeze when an error occurs, or when you trigger it in Settings.\n"
            "Use it as a short pause if the app feels stuck - not a system-wide lock."
        )

    if has("account", "login", "password", "sign up", "create account"):
        return (
            "Local account (hashed password) is stored in ~/.anti-computer-virus-account.json.\n"
            "Create/login at startup, or Settings → userAccount → Create an Account.\n"
            "Logout returns to the account screen."
        )

    if has("configment"):
        return (
            "Configment runs diagnostics: Python/tkinter, script path, log/quarantine writable, "
            "watch dirs, and tools like ss/ps/find.\n"
            "Open Settings → Configment."
        )

    if has("troubleshoot", "not working", "broken", "error"):
        return (
            "Try Settings → Troubleshoot (re-index watcher, clear alert cache, test log/quarantine).\n"
            "Then Configment for a full checklist.\n"
            "If scans fail, enable Lockdown only if you want a 1s freeze on errors."
        )

    if has("filesprotection", "file protection", "watched"):
        return (
            "Watched folders: /tmp, /var/tmp, home, Downloads, Desktop.\n"
            "New/changed files get AI scores; high scores go to quarantine (and optional delete).\n"
            "See Settings → FilesProtectionInformation."
        )

    if has("score", "heuristic", "ai scan", "threat scan"):
        return (
            "AI Threat Scan scores files/processes with weighted heuristics (not a cloud ML model).\n"
            "Weights include name, extension, temp path, permissions, entropy, reverse-shell patterns.\n"
            "Run AI Threat Scan or FULL SCAN + AI from the main menu."
        )

    if has("disk check", "disk repair", "fsck", "smart"):
        return (
            "Disk Check (Settings): read-only scan of filesystem, SMART health, and kernel messages.\n"
            "Disk Repair: syncs filesystems, optional cache drop (root), and fsck dry-run.\n"
            "Full repair of a mounted root filesystem usually needs a live boot."
        )

    if has("disk", "backup", "restore", "free space"):
        return (
            "Disk Protection & Backup (Settings):\n"
            "• Disk Protection Scan - checks free space, mounts, large files\n"
            "• Create Backup - copies Documents, Desktop, Downloads, .ssh to ~/.anti-computer-virus-backups\n"
            "• List Backups / Restore Latest - restores to a new folder (does not overwrite originals)"
        )

    if has("codespace", "create your own", "my antivirus", "write code"):
        return (
            "Create Your Own Anti-Virus (main menu):\n"
            "Opens a built-in code editor where you can write Python detection logic,\n"
            "run it with the Run button, and save it as ~/my_antivirus.py."
        )

    if has("firewall", "ufw", "iptables"):
        return (
            "Create Firewall (main menu):\n"
            "• Prefers UFW: enables it, denies incoming, allows outgoing + SSH.\n"
            "• Falls back to basic iptables rules if UFW is missing (needs root).\n"
            "Rules may not persist across reboot unless saved separately."
        )

    if has("how to", "how do i", "where is", "what does"):
        # generic guidance
        return (
            "Main controls are on the left: scan modules, Auto-Delete, Start/Stop Monitor, Settings, AI Helper.\n"
            "Settings has Configment, Troubleshoot, UserLogs, Lockdown, account tools.\n"
            "Ask a more specific question (e.g. how does quarantine work?)."
        )

    # fallback with keyword hint
    return (
        "I didn't match a specific topic. More accurate asks:\n"
        "• Threats: malware, trojan, worm, ransomware, phishing\n"
        "• Features: quarantine, auto-delete, monitor, lockdown, score\n"
        "• Or paste an absolute file path to analyze"
    )



def is_safe_to_delete(path: Path) -> bool:
    try:
        resolved = path.resolve()
        if resolved.is_dir():
            return False
        for forbidden in NEVER_DELETE:
            if str(resolved) == forbidden or str(resolved).startswith(forbidden + os.sep):
                if forbidden in ("/tmp", "/var/tmp") or str(resolved).startswith(str(Path.home())):
                    if str(resolved) == str(Path.home()):
                        return False
                    continue
                return False
        if "anti_computer_virus" in str(resolved).lower():
            return False
        if str(resolved).startswith(str(QUARANTINE_DIR)):
            return False
        if str(resolved) == str(LOG_FILE):
            return False
        return True
    except Exception:
        return False

def quarantine_and_maybe_delete(path: Path, score: int = 0) -> str:
    global AUTO_DELETE_ENABLED
    try:
        ensure_quarantine()
        if not path.exists() or not path.is_file():
            return "File no longer exists"
        target = QUARANTINE_DIR / f"{path.name}.{int(time.time())}"
        shutil.copy2(path, target)
        note = target.with_suffix(target.suffix + ".note")
        note.write_text(
            f"Original: {path}\nDetected: {datetime.now()}\nSHA256: {file_hash(path)}\n"
            f"AI Score: {score}\nAuto-delete was: {'ON' if AUTO_DELETE_ENABLED else 'OFF'}\n"
        )
        log(f"Quarantined: {path} -> {target} (score={score})", "WARN")
        if AUTO_DELETE_ENABLED and score >= AUTO_DELETE_THRESHOLD:
            if is_safe_to_delete(path):
                try:
                    path.unlink()
                    msg = f"DELETED original after quarantine: {path}"
                    log(msg, "ALERT")
                    return msg
                except Exception as e:
                    log(f"Delete failed for {path}: {e}", "ERROR")
                    return f"Quarantined but delete failed: {e}"
            else:
                log(f"Refused to delete protected path: {path}", "WARN")
                return f"Quarantined (delete refused - protected path): {path}"
        else:
            return f"Quarantined (original left intact): {path}"
    except Exception as e:
        log(f"quarantine_and_maybe_delete error: {e}", "ERROR")
        return f"Error: {e}"

# ===================== AI Engine =====================

def shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counter = Counter(data)
    length = len(data)
    entropy = 0.0
    for count in counter.values():
        p = count / length
        entropy -= p * math.log2(p)
    return entropy

def ai_score_file(path: Path) -> tuple:
    score = 0
    reasons = []
    try:
        name = path.name.lower()
        bad_words = ["malware", "virus", "trojan", "backdoor", "keylog", "ransomware",
                     "payload", "shellcode", "exploit", "rootkit", "worm", "rat"]
        for w in bad_words:
            if w in name:
                score += WEIGHTS["suspicious_name"]
                reasons.append(f"Suspicious name contains '{w}'")
                break
        if path.suffix.lower() in {".exe", ".bat", ".cmd", ".scr", ".pif", ".vbs", ".js"}:
            score += WEIGHTS["known_bad_ext"]
            reasons.append(f"Suspicious extension: {path.suffix}")
        if name.startswith("."):
            score += WEIGHTS["hidden_file"]
            reasons.append("Hidden file")
        strpath = str(path).lower()
        if any(t in strpath for t in ["/tmp", "/var/tmp", "/dev/shm"]):
            if path.is_file() and os.access(path, os.X_OK):
                score += WEIGHTS["executable_in_tmp"]
                reasons.append("Executable in temporary directory")
        mode = path.stat().st_mode
        if mode & 0o002:
            score += WEIGHTS["world_writable"]
            reasons.append("World-writable")
        if mode & 0o4000:
            score += WEIGHTS["suid"]
            reasons.append("SUID bit set")
        mtime = path.stat().st_mtime
        if time.time() - mtime < 86400 * 2:
            score += WEIGHTS["recent_modify"]
            reasons.append("Recently modified")
        try:
            with open(path, "rb") as f:
                sample = f.read(65536)
            ent = shannon_entropy(sample)
            if ent > 7.2:
                score += WEIGHTS["high_entropy"]
                reasons.append(f"High entropy ({ent:.2f})")
            elif ent > 6.5:
                score += WEIGHTS["high_entropy"] // 2
                reasons.append(f"Elevated entropy ({ent:.2f})")
        except Exception:
            pass
    except Exception as e:
        reasons.append(f"Analysis error: {e}")
    return min(100, score), reasons

def ai_score_process(cmdline: str, pid: str = "") -> tuple:
    score = 0
    reasons = []
    for pat in SUSPICIOUS_PROCESS_PATTERNS:
        if re.search(pat, cmdline, re.I):
            score += WEIGHTS["reverse_shell_pattern"]
            reasons.append("Matches reverse-shell pattern")
            break
    cmd = cmdline.lower()
    if any(x in cmd for x in ["/tmp/", "/dev/shm/", "base64", "eval(", "exec("]):
        score += 15
        reasons.append("Suspicious path or dynamic execution")
    if "curl" in cmd and "|" in cmd:
        score += 20
        reasons.append("Piped download")
    return min(100, score), reasons

def ai_threat_scan(paths=None) -> str:
    global AUTO_DELETE_ENABLED
    lines = ["=== AI THREAT DETECTION ENGINE ===", ""]
    lines.append(f"Auto-Delete: {'ENABLED' if AUTO_DELETE_ENABLED else 'DISABLED'} (threshold >= {AUTO_DELETE_THRESHOLD})")
    lines.append("Heuristic scoring (0-100) | >=60 High | >=40 Medium")
    lines.append("")
    high_risk, medium_risk = [], []
    home = Path.home()
    search_roots = paths or ["/tmp", "/var/tmp", str(home)]
    files_checked = 0
    for root in search_roots:
        if not Path(root).exists():
            continue
        try:
            for p in Path(root).rglob("*"):
                if files_checked > 130:
                    break
                if not p.is_file():
                    continue
                if p.suffix.lower() in {".sh", ".py", ".exe", ".bat", ".bin", ""} or \
                   any(w in p.name.lower() for w in ["malware", "virus", "trojan", "payload", "shell"]):
                    score, reasons = ai_score_file(p)
                    files_checked += 1
                    if score >= 60:
                        high_risk.append((score, p, reasons))
                    elif score >= 40:
                        medium_risk.append((score, p, reasons))
        except Exception:
            continue
    high_risk.sort(key=lambda x: -x[0])
    medium_risk.sort(key=lambda x: -x[0])
    deleted_count = 0
    if high_risk:
        lines.append("HIGH RISK FILES:")
        for score, p, reasons in high_risk[:15]:
            lines.append(f"  [{score:3d}] {p}")
            for r in reasons:
                lines.append(f"         -> {r}")
            result = quarantine_and_maybe_delete(p, score)
            lines.append(f"         ACTION: {result}")
            if "DELETED" in result:
                deleted_count += 1
            log(f"AI HIGH RISK ({score}): {p}", "ALERT")
        lines.append("")
    if medium_risk:
        lines.append("MEDIUM RISK FILES (quarantine only, no auto-delete):")
        for score, p, reasons in medium_risk[:10]:
            lines.append(f"  [{score:3d}] {p}")
            for r in reasons[:2]:
                lines.append(f"         -> {r}")
            quarantine_and_maybe_delete(p, 0)
        lines.append("")
    if not high_risk and not medium_risk:
        lines.append("No high/medium risk files detected.")
        lines.append("")
    lines.append("-- Process Analysis --")
    ps = run_cmd("ps aux 2>/dev/null")
    proc_high = []
    for line in ps.splitlines()[1:]:
        parts = line.split(None, 10)
        if len(parts) < 11:
            continue
        pid, cmd = parts[1], parts[10]
        score, reasons = ai_score_process(cmd, pid)
        if score >= 50:
            proc_high.append((score, pid, cmd, reasons))
    proc_high.sort(key=lambda x: -x[0])
    if proc_high:
        lines.append("HIGH RISK PROCESSES (reported only - processes are not killed):")
        for score, pid, cmd, reasons in proc_high[:8]:
            lines.append(f"  [{score:3d}] PID {pid}: {cmd[:90]}")
            for r in reasons:
                lines.append(f"         -> {r}")
            log(f"AI HIGH RISK PROCESS ({score}): {cmd[:60]}", "ALERT")
    else:
        lines.append("No high-risk processes detected.")
    lines.append("")
    lines.append(f"Files analyzed: {files_checked} | High-risk: {len(high_risk)} | Deleted: {deleted_count}")
    log(f"AI scan finished: files={files_checked} high={len(high_risk)} deleted={deleted_count}")
    return "\n".join(lines)

# ===================== Classic Scanners =====================

def scan_anti_hacker() -> str:
    lines = ["=== ANTI-HACKER SCAN ==="]
    findings = 0
    out = run_cmd("ss -tunap 2>/dev/null") or run_cmd("netstat -tunap 2>/dev/null")
    if out:
        lines.append(out[:1100])
        for port in RISKY_PORTS:
            if f":{port}" in out:
                lines.append(f"WARNING: SUSPICIOUS PORT {port}")
                findings += 1
    ps = run_cmd("ps aux 2>/dev/null")
    for line in ps.splitlines():
        for pat in SUSPICIOUS_PROCESS_PATTERNS:
            if re.search(pat, line, re.I):
                lines.append(f"WARNING: Suspicious process: {line[:100]}")
                findings += 1
                break
    if findings == 0:
        lines.append("No classic reverse-shell patterns found.")
    lines.append(f"Findings: {findings} | Rule: block > Hacker")
    return "\n".join(lines)

def scan_anti_malware() -> str:
    lines = ["=== ANTI-MALWARE SCAN ==="]
    findings = 0
    deleted = 0
    home = Path.home()
    cmd = (
        f'find /tmp "{home}" /var/tmp -maxdepth 3 -type f '
        r'\( -iname "*malware*" -o -iname "*virus*" -o -iname "*trojan*" '
        r'-o -iname "*ransomware*" -o -iname "*payload*" -o -iname "*.exe" '
        r'-o -iname "*.bat" -o -iname "*shellcode*" \) 2>/dev/null | head -25'
    )
    out = run_cmd(cmd)
    if out:
        for f in out.splitlines():
            p = Path(f.strip())
            lines.append(f"WARNING: Found: {p}")
            findings += 1
            result = quarantine_and_maybe_delete(p, 70)
            lines.append(f"  ACTION: {result}")
            if "DELETED" in result:
                deleted += 1
    else:
        lines.append("No malware-like filenames found.")
    out = run_cmd(f'find /tmp "{home}" -maxdepth 2 -type f -perm -o+w 2>/dev/null | head -6')
    if out:
        for f in out.splitlines():
            lines.append(f"WARNING: World-writable: {f}")
            findings += 1
    lines.append(f"Findings: {findings} | Deleted: {deleted} | Rules: antiVirus > malware")
    return "\n".join(lines)

def scan_anti_trojan() -> str:
    lines = ["=== ANTI-TROJAN SCAN ==="]
    findings = 0
    deleted = 0
    home = Path.home()
    cmd = (
        f'find /tmp "{home}" /var/tmp -maxdepth 3 -type f '
        r'\( -iname "*trojan*" -o -iname "*backdoor*" -o -iname "*keylog*" \) 2>/dev/null | head -15'
    )
    out = run_cmd(cmd)
    if out:
        for f in out.splitlines():
            p = Path(f.strip())
            lines.append(f"WARNING: {p}")
            findings += 1
            result = quarantine_and_maybe_delete(p, 75)
            lines.append(f"  ACTION: {result}")
            if "DELETED" in result:
                deleted += 1
    crontab = run_cmd("crontab -l 2>/dev/null")
    if crontab and "no crontab" not in crontab.lower():
        lines.append("Crontab:\n" + crontab[:500])
        if any(x in crontab.lower() for x in ["curl", "wget", "bash -i", "nc ", "/tmp/"]):
            lines.append("WARNING: Suspicious crontab!")
            findings += 1
    out = run_cmd(f'find /tmp "{home}" -maxdepth 2 -type f -perm -4000 2>/dev/null | head -6')
    if out:
        for f in out.splitlines():
            lines.append(f"WARNING: SUID: {f}")
            findings += 1
    lines.append(f"Findings: {findings} | Deleted: {deleted} | Rules: delete/remove/Block > trojan")
    return "\n".join(lines)

def scan_anti_worm() -> str:
    lines = ["=== ANTI-WORM SCAN ==="]
    findings = 0
    home = str(Path.home())
    out = run_cmd(f'find /tmp "{home}" -maxdepth 2 -type f -name "*.sh" 2>/dev/null')
    if out:
        files = out.splitlines()
        lines.append(f"Found {len(files)} .sh files")
        hashes = {}
        for f in files[:35]:
            h = file_hash(Path(f))
            hashes.setdefault(h, []).append(f)
        for h, paths in hashes.items():
            if len(paths) >= 3:
                lines.append(f"WARNING: {len(paths)} identical files: {paths[0]}")
                findings += 1
                for extra in paths[1:]:
                    quarantine_and_maybe_delete(Path(extra), 65)
    out = run_cmd("ps -eo comm --no-headers 2>/dev/null | sort | uniq -c | sort -nr | head -8")
    if out:
        lines.append("Top processes:\n" + out)
    lines.append(f"Findings: {findings} | Rules: antiVirus > wormVirus")
    return "\n".join(lines)

def scan_anti_vpn() -> str:
    lines = ["=== ANTI-VPN / VPN PROTECTION ==="]
    out = run_cmd("ip link show 2>/dev/null | grep -E 'tun|tap|wg|vpn|ppp'") or "No VPN interfaces."
    lines.append(out)
    out = run_cmd("pgrep -a -f 'openvpn|wireguard|nordvpn|expressvpn|protonvpn' 2>/dev/null") or "No common VPN clients."
    lines.append(out)
    lines.append("Rules: antivirus > vpn | Vpn > protection")
    return "\n".join(lines)

def scan_client_protection() -> str:
    lines = ["=== CLIENT PROTECTION ==="]
    findings = 0
    out = run_cmd("ufw status 2>/dev/null") or run_cmd("firewall-cmd --state 2>/dev/null") or "No firewall tool."
    lines.append(f"Firewall:\n{out[:350]}")
    for p in ["/etc/passwd", "/etc/shadow"]:
        path = Path(p)
        if path.exists():
            try:
                mode = oct(path.stat().st_mode)[-3:]
                lines.append(f"{p}: {mode}")
                if p.endswith("shadow") and mode not in ("640", "600"):
                    lines.append("WARNING: Unexpected shadow permissions")
                    findings += 1
            except Exception:
                pass
    content = run_cmd("grep -E '^(PermitRootLogin|PasswordAuthentication)' /etc/ssh/sshd_config 2>/dev/null")
    if content:
        lines.append("SSH:\n" + content)
        if "PermitRootLogin yes" in content:
            lines.append("WARNING: Root login enabled")
            findings += 1
    lines.append(f"Findings: {findings} | Rules: antivirus/antiClient > protection")
    return "\n".join(lines)

def scan_integrity() -> str:
    lines = ["=== INTEGRITY CHECK ==="]
    this = Path(__file__).resolve()
    lines.append(f"This script SHA256:\n  {file_hash(this)}")
    for b in ["/bin/ls", "/bin/bash", "/usr/bin/sudo"]:
        p = Path(b)
        if p.exists():
            mode = oct(p.stat().st_mode)[-4:]
            lines.append(f"{b}: {mode}  {file_hash(p)[:18]}...")
    return "\n".join(lines)

def full_scan_report() -> str:
    parts = [
        ai_threat_scan(),
        scan_anti_hacker(),
        scan_anti_malware(),
        scan_anti_trojan(),
        scan_anti_worm(),
        scan_anti_vpn(),
        scan_client_protection(),
        scan_integrity(),
    ]
    return "\n\n".join(parts)

# ===================== Real-Time File Watcher =====================

class FileSystemWatcher:
    def __init__(self, dirs, depth=2, callback=None):
        self.dirs = [Path(d) for d in dirs if Path(d).exists()]
        self.depth = depth
        self.callback = callback
        self.known = {}
        self.running = False
        self.thread = None
        self._bootstrap()

    def _bootstrap(self):
        for d in self.dirs:
            for p in self._walk(d):
                try:
                    st = p.stat()
                    self.known[str(p)] = (st.st_mtime, st.st_size)
                except Exception:
                    pass
        log(f"File watcher bootstrap: {len(self.known)} files indexed")

    def _walk(self, root: Path):
        try:
            for entry in root.iterdir():
                try:
                    if entry.is_file():
                        yield entry
                    elif entry.is_dir() and not entry.name.startswith("."):
                        yield from self._walk_limited(entry, self.depth - 1)
                except PermissionError:
                    continue
        except Exception:
            pass

    def _walk_limited(self, root: Path, remaining: int):
        if remaining < 0:
            return
        try:
            for entry in root.iterdir():
                try:
                    if entry.is_file():
                        yield entry
                    elif entry.is_dir() and remaining > 0 and not entry.name.startswith("."):
                        yield from self._walk_limited(entry, remaining - 1)
                except PermissionError:
                    continue
        except Exception:
            pass

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        log("FileSystemWatcher STARTED")

    def stop(self):
        self.running = False
        log("FileSystemWatcher STOPPED")

    def _loop(self):
        while self.running:
            try:
                current = {}
                for d in self.dirs:
                    for p in self._walk(d):
                        try:
                            st = p.stat()
                            key = str(p)
                            current[key] = (st.st_mtime, st.st_size)
                            old = self.known.get(key)
                            if old is None:
                                score, reasons = ai_score_file(p)
                                if self.callback:
                                    self.callback(p, "NEW", score, reasons)
                                if score >= 40:
                                    quarantine_and_maybe_delete(p, score)
                            elif old != current[key]:
                                score, reasons = ai_score_file(p)
                                if self.callback:
                                    self.callback(p, "MODIFIED", score, reasons)
                                if score >= 50:
                                    quarantine_and_maybe_delete(p, score)
                        except Exception:
                            continue
                self.known = current
            except Exception as e:
                log(f"File watcher error: {e}", "ERROR")
            time.sleep(FILE_WATCH_INTERVAL)

# ===================== Combined Monitor =====================

class RealTimeMonitor:
    def __init__(self, alert_callback=None, status_callback=None):
        self.running = False
        self.proc_thread = None
        self.status_thread = None
        self.alert_callback = alert_callback
        self.status_callback = status_callback
        self.seen = set()
        self.alert_history = deque(maxlen=100)
        self.file_watcher = FileSystemWatcher(
            WATCH_DIRS, depth=FILE_WATCH_DEPTH, callback=self._on_file_event
        )
        self.files_watched = 0
        self.alerts_count = 0
        self.start_time = None

    def start(self):
        if self.running:
            return
        self.running = True
        self.start_time = time.time()
        self.alerts_count = 0
        self.file_watcher.start()
        self.proc_thread = threading.Thread(target=self._proc_loop, daemon=True)
        self.proc_thread.start()
        self.status_thread = threading.Thread(target=self._status_loop, daemon=True)
        self.status_thread.start()
        log("Full Real-Time Monitor STARTED")

    def stop(self):
        self.running = False
        self.file_watcher.stop()
        log("Full Real-Time Monitor STOPPED")

    def _alert(self, msg: str, score: int = 0):
        self.alert_history.append(f"[{datetime.now():%H:%M:%S}] {msg}")
        self.alerts_count += 1
        log(msg, "ALERT")
        if self.alert_callback:
            try:
                self.alert_callback(msg, score)
            except Exception:
                pass

    def _on_file_event(self, path: Path, event: str, score: int, reasons: list):
        if score < 25 and event == "MODIFIED":
            return
        reason_txt = "; ".join(reasons[:2]) if reasons else "heuristic"
        msg = f"FILE {event} [{score}]: {path} ({reason_txt})"
        key = f"file:{event}:{path}"
        if key not in self.seen:
            self.seen.add(key)
            self._alert(msg, score)

    def _proc_loop(self):
        while self.running:
            try:
                ps = run_cmd("ps aux 2>/dev/null")
                for line in ps.splitlines()[1:]:
                    parts = line.split(None, 10)
                    if len(parts) < 11:
                        continue
                    pid, cmd = parts[1], parts[10]
                    score, reasons = ai_score_process(cmd, pid)
                    if score >= 50:
                        key = f"proc:{pid}:{cmd[:50]}"
                        if key not in self.seen:
                            self.seen.add(key)
                            self._alert(f"PROCESS RISK [{score}]: {cmd[:85]}", score)
                net = run_cmd("ss -tlnp 2>/dev/null") or run_cmd("netstat -tlnp 2>/dev/null")
                for port in RISKY_PORTS:
                    if f":{port}" in net:
                        key = f"port:{port}"
                        if key not in self.seen:
                            self.seen.add(key)
                            self._alert(f"RISKY PORT OPEN: {port}", 70)
            except Exception as e:
                log(f"Proc monitor error: {e}", "ERROR")
            time.sleep(MONITOR_INTERVAL)

    def _status_loop(self):
        """Periodic status report when STATUS_REPORT_ENABLED is True."""
        while self.running:
            time.sleep(STATUS_REPORT_INTERVAL)
            if not self.running:
                break
            if STATUS_REPORT_ENABLED and self.status_callback:
                uptime = int(time.time() - (self.start_time or time.time()))
                mins, secs = divmod(uptime, 60)
                watched = len(self.file_watcher.known)
                report = (
                    f"STATUS REPORT: Monitor running {mins}m {secs}s | "
                    f"Files indexed: {watched} | Alerts so far: {self.alerts_count} | "
                    f"Auto-Delete: {'ON' if AUTO_DELETE_ENABLED else 'OFF'}"
                )
                try:
                    self.status_callback(report)
                except Exception:
                    pass

# ===================== GUI =====================


# ===================== Boot + Account screens =====================

class BootScreen:
    """Short loading / boot screen, then opens Account or Main."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title(f"Anti-ComputerVIRUS v{VERSION}")
        self.root.geometry("420x260")
        self.root.configure(bg="#1e1e2e")
        self.root.resizable(False, False)

        tk.Label(
            self.root, text="Anti-ComputerVIRUS",
            font=("Segoe UI", 18, "bold"), bg="#1e1e2e", fg="#89b4fa"
        ).pack(pady=(40, 8))
        tk.Label(
            self.root, text=f"v{VERSION}  •  Booting...",
            font=("Segoe UI", 10), bg="#1e1e2e", fg="#a6adc8"
        ).pack()

        self.status = tk.Label(
            self.root, text="Loading modules...",
            font=("Segoe UI", 9), bg="#1e1e2e", fg="#cba6f7"
        )
        self.status.pack(pady=20)

        self.bar = tk.Frame(self.root, bg="#313244", height=8, width=300)
        self.bar.pack(pady=10)
        self.fill = tk.Frame(self.bar, bg="#89b4fa", height=8, width=10)
        self.fill.place(x=0, y=0, height=8)

        self.progress = 0
        self.root.after(200, self._tick)

    def _tick(self):
        self.progress += 8
        w = min(300, int(300 * self.progress / 100))
        self.fill.place(x=0, y=0, width=w, height=8)
        msgs = {
            16: "Loading AI engine...",
            32: "Loading file watcher...",
            48: "Loading protection modules...",
            64: "Checking account data...",
            80: "Almost ready...",
            96: "Starting...",
        }
        if self.progress in msgs:
            self.status.config(text=msgs[self.progress])
        if self.progress >= 100:
            self.root.after(300, self._done)
        else:
            self.root.after(120, self._tick)

    def _done(self):
        self.root.destroy()
        # After boot → account screen if no account, else login / main choice
        AccountScreen()

    def run(self):
        self.root.mainloop()


class AccountScreen:
    """Create account or log in, then open main antivirus GUI."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title(f"Anti-ComputerVIRUS v{VERSION} - Account")
        self.root.geometry("440x420")
        self.root.configure(bg="#1e1e2e")
        self.root.resizable(False, False)

        acc = load_account()
        self.has_account = bool(acc.get("username"))

        tk.Label(
            self.root, text="Anti-ComputerVIRUS",
            font=("Segoe UI", 16, "bold"), bg="#1e1e2e", fg="#89b4fa"
        ).pack(pady=(24, 4))
        tk.Label(
            self.root, text="Account",
            font=("Segoe UI", 11), bg="#1e1e2e", fg="#a6adc8"
        ).pack()

        form = tk.Frame(self.root, bg="#313244", padx=20, pady=16)
        form.pack(padx=30, pady=16, fill=tk.X)

        tk.Label(form, text="Username", bg="#313244", fg="#cdd6f4",
                 font=("Segoe UI", 9)).pack(anchor="w")
        self.user_entry = tk.Entry(form, font=("Segoe UI", 11), bg="#11111b", fg="#cdd6f4",
                                   insertbackground="#cdd6f4", relief=tk.FLAT)
        self.user_entry.pack(fill=tk.X, pady=(2, 10), ipady=4)
        if self.has_account:
            self.user_entry.insert(0, acc.get("username", ""))

        tk.Label(form, text="Password", bg="#313244", fg="#cdd6f4",
                 font=("Segoe UI", 9)).pack(anchor="w")
        self.pass_entry = tk.Entry(form, font=("Segoe UI", 11), bg="#11111b", fg="#cdd6f4",
                                   insertbackground="#cdd6f4", relief=tk.FLAT, show="*")
        self.pass_entry.pack(fill=tk.X, pady=(2, 10), ipady=4)

        tk.Label(form, text="Confirm password (create only)", bg="#313244", fg="#cdd6f4",
                 font=("Segoe UI", 9)).pack(anchor="w")
        self.confirm_entry = tk.Entry(form, font=("Segoe UI", 11), bg="#11111b", fg="#cdd6f4",
                                      insertbackground="#cdd6f4", relief=tk.FLAT, show="*")
        self.confirm_entry.pack(fill=tk.X, pady=(2, 6), ipady=4)

        self.msg = tk.Label(self.root, text="", bg="#1e1e2e", fg="#f38ba8",
                            font=("Segoe UI", 9), wraplength=380)
        self.msg.pack(pady=4)

        btn_frame = tk.Frame(self.root, bg="#1e1e2e")
        btn_frame.pack(pady=8)

        # Create Account button (always available)
        tk.Button(
            btn_frame, text="Create an Account",
            command=self._create_account,
            bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 10, "bold"), cursor="hand2", padx=12, pady=6
        ).pack(side=tk.LEFT, padx=6)

        tk.Button(
            btn_frame, text="Forgot Password",
            command=self._forgot_password,
            bg="#fab387", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 10, "bold"), cursor="hand2", padx=12, pady=6
        ).pack(side=tk.LEFT, padx=6)

        tk.Button(
            btn_frame, text="Password Reset Email",
            command=self._password_reset_email,
            bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 10, "bold"), cursor="hand2", padx=12, pady=6
        ).pack(side=tk.LEFT, padx=6)

        if self.has_account:
            tk.Button(
                btn_frame, text="Log In",
                command=self._login,
                bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
                font=("Segoe UI", 10, "bold"), cursor="hand2", padx=12, pady=6
            ).pack(side=tk.LEFT, padx=6)
            self.msg.config(
                text=f"Account found for: {acc.get('username')}. Log in or create a new one (overwrites).",
                fg="#a6adc8"
            )
        else:
            self.msg.config(text="No account yet - create one to continue.", fg="#a6adc8")

        self.root.protocol("WM_DELETE_WINDOW", self.root.destroy)
        self.root.mainloop()

    def _create_account(self):
        user = self.user_entry.get().strip()
        pw = self.pass_entry.get()
        conf = self.confirm_entry.get()
        if not user or not pw:
            self.msg.config(text="Username and password are required.", fg="#f38ba8")
            return
        if len(user) < 2:
            self.msg.config(text="Username must be at least 2 characters.", fg="#f38ba8")
            return
        if len(pw) < 4:
            self.msg.config(text="Password must be at least 4 characters.", fg="#f38ba8")
            return
        if pw != conf:
            self.msg.config(text="Passwords do not match.", fg="#f38ba8")
            return
        if save_account(user, pw):
            self.msg.config(text="Account created! Opening antivirus...", fg="#a6e3a1")
            self.root.after(600, self._open_main)
        else:
            self.msg.config(text="Failed to save account.", fg="#f38ba8")

    def _login(self):
        user = self.user_entry.get().strip()
        pw = self.pass_entry.get()
        if verify_account(user, pw):
            self.msg.config(text="Login OK - opening antivirus...", fg="#a6e3a1")
            log(f"User logged in: {user}")
            self.root.after(400, self._open_main)
        else:
            self.msg.config(text="Invalid username or password.", fg="#f38ba8")

    def _password_reset_email(self):
        """Open mail client with password reset request to support email."""
        import webbrowser
        import urllib.parse
        subject = urllib.parse.quote("Anti-ComputerVIRUS Password Reset Request")
        body = urllib.parse.quote(
            "Hello,\n\nI need to reset my Anti-ComputerVIRUS password.\n\nUsername: \n\nThank you."
        )
        url = f"mailto:adamaryaan001@gmail.com?subject={subject}&body={body}"
        try:
            webbrowser.open(url)
            self.msg.config(text="Password reset email opened in your mail client.", fg="#a6e3a1")
            log("Password reset email requested")
        except Exception as e:
            self.msg.config(text=f"Could not open email: {e}", fg="#f38ba8")

    def _forgot_password(self):

        """Reset password locally so user can set a new one."""
        acc = load_account()
        if not acc.get("username"):
            self.msg.config(text="No account exists yet. Create one first.", fg="#f38ba8")
            return
        # Confirm
        if not messagebox.askyesno(
            "Forgot Password",
            "This will clear the current password so you can set a new one.\n\nContinue?"
        ):
            return
        # Clear password by saving with a temporary reset flag
        try:
            import json
            acc["password_hash"] = ""
            acc["reset_required"] = True
            ACCOUNT_FILE.write_text(json.dumps(acc, indent=2))
            self.msg.config(
                text="Password cleared. Enter a new password and confirm, then click Create an Account.",
                fg="#a6e3a1"
            )
            log(f"Password reset requested for {acc.get('username')}")
        except Exception as e:
            self.msg.config(text=f"Reset failed: {e}", fg="#f38ba8")

    def _open_main(self):

        self.root.destroy()
        # Booting-up loading screen after login / account create
        PostLoginBootScreen().run()




class PostLoginBootScreen:
    """Booting-up loading screen shown after successful login or account creation."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title(f"Anti-ComputerVIRUS v{VERSION}")
        self.root.geometry("440x280")
        self.root.configure(bg="#1e1e2e")
        self.root.resizable(False, False)

        acc = load_account()
        uname = acc.get("username", "User")

        tk.Label(
            self.root, text="Anti-ComputerVIRUS",
            font=("Segoe UI", 18, "bold"), bg="#1e1e2e", fg="#89b4fa"
        ).pack(pady=(36, 6))
        tk.Label(
            self.root, text=f"Welcome, {uname}",
            font=("Segoe UI", 11), bg="#1e1e2e", fg="#a6e3a1"
        ).pack()
        tk.Label(
            self.root, text="Booting up protection modules...",
            font=("Segoe UI", 10), bg="#1e1e2e", fg="#a6adc8"
        ).pack(pady=(12, 4))

        self.status = tk.Label(
            self.root, text="Initializing...",
            font=("Segoe UI", 9), bg="#1e1e2e", fg="#cba6f7"
        )
        self.status.pack(pady=8)

        self.bar = tk.Frame(self.root, bg="#313244", height=10, width=320)
        self.bar.pack(pady=12)
        self.fill = tk.Frame(self.bar, bg="#a6e3a1", height=10, width=8)
        self.fill.place(x=0, y=0, height=10)

        self.progress = 0
        self.root.after(180, self._tick)

    def _tick(self):
        self.progress += 7
        w = min(320, int(320 * self.progress / 100))
        self.fill.place(x=0, y=0, width=w, height=10)
        msgs = {
            14: "Loading AI threat engine...",
            28: "Starting file protection...",
            42: "Loading scan modules...",
            56: "Preparing real-time monitor...",
            70: "Checking quarantine...",
            84: "Finalizing...",
            98: "Ready!",
        }
        if self.progress in msgs:
            self.status.config(text=msgs[self.progress])
        if self.progress >= 100:
            self.root.after(350, self._done)
        else:
            self.root.after(110, self._tick)

    def _done(self):
        self.root.destroy()
        app = AntivirusGUI()
        app.run()

    def run(self):
        self.root.mainloop()


class AntivirusGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title(f"Anti-ComputerVIRUS v{VERSION} - Settings + Auto-Delete + Real-Time + AI")
        self.root.geometry("1020x740")
        self.root.minsize(860, 600)

        self.bg = "#1e1e2e"
        self.fg = "#cdd6f4"
        self.accent = "#89b4fa"
        self.warn = "#f38ba8"
        self.ok = "#a6e3a1"
        self.panel = "#313244"
        self.ai_color = "#cba6f7"
        self.file_color = "#94e2d5"
        self.delete_color = "#eba0ac"
        self.settings_color = "#f9e2af"

        self.root.configure(bg=self.bg)
        self.monitor = RealTimeMonitor(
            alert_callback=self._on_alert,
            status_callback=self._on_status_report
        )
        self.settings_window = None
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        # Top bar with title and user button
        topbar = tk.Frame(self.root, bg=self.bg)
        topbar.pack(fill=tk.X, padx=10, pady=(8, 2))

        title = tk.Label(
            topbar, text=f"Anti-ComputerVIRUS  v{VERSION}",
            font=("Segoe UI", 13, "bold"), bg=self.bg, fg=self.accent
        )
        title.pack(side=tk.LEFT)

        # User button - top right
        acc = load_account()
        uname = acc.get("username", "User")
        self.user_btn = tk.Button(
            topbar, text=f"👤 {uname}",
            command=self._show_user_menu,
            bg=self.panel, fg=self.fg, relief=tk.FLAT,
            font=("Segoe UI", 9), cursor="hand2", padx=10, pady=2
        )
        self.user_btn.pack(side=tk.RIGHT)

        tk.Label(
            self.root, text="Quarantine first  •  Optional auto-delete  •  by Adam & Team",
            font=("Segoe UI", 9), bg=self.bg, fg="#a6adc8"
        ).pack()

        main = tk.Frame(self.root, bg=self.bg)
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=6)

        left = tk.Frame(main, bg=self.panel, width=225)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 8))
        left.pack_propagate(False)

        tk.Label(left, text="SCAN MODULES", font=("Segoe UI", 9, "bold"),
                 bg=self.panel, fg=self.accent).pack(pady=(8, 4))

        # Scrollable scan modules
        mod_outer = tk.Frame(left, bg=self.panel)
        mod_outer.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)

        mod_canvas = tk.Canvas(mod_outer, bg=self.panel, highlightthickness=0, height=220)
        mod_scroll = tk.Scrollbar(mod_outer, orient=tk.VERTICAL, command=mod_canvas.yview)
        mod_frame = tk.Frame(mod_canvas, bg=self.panel)

        mod_frame.bind(
            "<Configure>",
            lambda e: mod_canvas.configure(scrollregion=mod_canvas.bbox("all"))
        )
        mod_win = mod_canvas.create_window((0, 0), window=mod_frame, anchor="nw")
        mod_canvas.configure(yscrollcommand=mod_scroll.set)

        def _mod_canvas_cfg(event):
            mod_canvas.itemconfig(mod_win, width=event.width)
        mod_canvas.bind("<Configure>", _mod_canvas_cfg)

        mod_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        mod_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        def _mod_wheel(event):
            mod_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        mod_canvas.bind("<MouseWheel>", _mod_wheel)
        mod_canvas.bind("<Button-4>", lambda e: mod_canvas.yview_scroll(-1, "units"))
        mod_canvas.bind("<Button-5>", lambda e: mod_canvas.yview_scroll(1, "units"))

        modules = [
            ("AI Threat Scan", lambda: self._run_scan(ai_threat_scan), self.ai_color),
            ("Anti-Hacker", lambda: self._run_scan(scan_anti_hacker), None),
            ("Anti-Malware", lambda: self._run_scan(scan_anti_malware), None),
            ("Anti-Trojan", lambda: self._run_scan(scan_anti_trojan), None),
            ("Anti-Worm", lambda: self._run_scan(scan_anti_worm), None),
            ("Anti-VPN", lambda: self._run_scan(scan_anti_vpn), None),
            ("Client Protection", lambda: self._run_scan(scan_client_protection), None),
            ("Integrity Check", lambda: self._run_scan(scan_integrity), None),
            ("FULL SCAN + AI", lambda: self._run_scan(full_scan_report), self.ok),
        ]
        for text, cmd, color in modules:
            bg = color if color else "#45475a"
            fg = "#1e1e2e" if color else self.fg
            b = tk.Button(mod_frame, text=text, command=cmd, bg=bg, fg=fg,
                          activebackground=self.accent, relief=tk.FLAT,
                          font=("Segoe UI", 9), cursor="hand2", pady=3)
            b.pack(fill=tk.X, padx=4, pady=2)

        # Auto-Delete
        tk.Label(left, text="AUTO-DELETE", font=("Segoe UI", 9, "bold"),
                 bg=self.panel, fg=self.delete_color).pack(pady=(10, 4))

        self.delete_var = tk.BooleanVar(value=False)
        self.delete_check = tk.Checkbutton(
            left, text="Enable Auto-Delete",
            variable=self.delete_var, command=self._toggle_auto_delete,
            bg=self.panel, fg=self.fg, selectcolor="#45475a",
            activebackground=self.panel, activeforeground=self.fg,
            font=("Segoe UI", 9), cursor="hand2"
        )
        self.delete_check.pack(anchor="w", padx=12)

        self.delete_status = tk.Label(
            left, text="OFF (safe mode)", bg=self.panel, fg=self.ok, font=("Segoe UI", 8)
        )
        self.delete_status.pack(anchor="w", padx=12, pady=(0, 2))

        # Real-time
        tk.Label(left, text="REAL-TIME PROTECTION", font=("Segoe UI", 9, "bold"),
                 bg=self.panel, fg=self.file_color).pack(pady=(8, 4))

        self.mon_status = tk.Label(left, text="Stopped", bg=self.panel, fg=self.warn, font=("Segoe UI", 9))
        self.mon_status.pack()

        self.btn_start = tk.Button(
            left, text="Start File + AI Monitor", command=self._start_monitor,
            bg=self.ok, fg="#1e1e2e", relief=tk.FLAT, font=("Segoe UI", 9, "bold"),
            cursor="hand2", pady=5
        )
        self.btn_start.pack(fill=tk.X, padx=8, pady=3)

        self.btn_stop = tk.Button(
            left, text="Stop Monitor", command=self._stop_monitor,
            bg=self.warn, fg="#1e1e2e", relief=tk.FLAT, font=("Segoe UI", 9, "bold"),
            cursor="hand2", pady=4, state=tk.DISABLED
        )
        self.btn_stop.pack(fill=tk.X, padx=8, pady=2)

        # Settings button
        tk.Label(left, text="QUICK START", font=("Segoe UI", 9, "bold"),
                 bg=self.panel, fg="#a6e3a1").pack(pady=(10, 4))

        tk.Button(
            left, text="Create Anti-Virus",
            command=self._create_antivirus,
            bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, padx=8, pady=2)

        tk.Button(
            left, text="Create Firewall",
            command=self._create_firewall,
            bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, padx=8, pady=2)

        tk.Button(
            left, text="Create Your Own Anti-Virus",
            command=self._open_codespace,
            bg="#cba6f7", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, padx=8, pady=2)

        tk.Label(left, text="SETTINGS", font=("Segoe UI", 9, "bold"),
                 bg=self.panel, fg=self.settings_color).pack(pady=(10, 4))

        tk.Button(
            left, text="⚙  Open Settings", command=self._open_settings,
            bg=self.settings_color, fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5
        ).pack(fill=tk.X, padx=8, pady=2)

        tk.Button(
            left, text="AI Helper Chat", command=self._open_ai_helper,
            bg=self.ai_color, fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5
        ).pack(fill=tk.X, padx=8, pady=2)

        tk.Button(left, text="View Log", command=self._show_log,
                  bg="#45475a", fg=self.fg, relief=tk.FLAT, font=("Segoe UI", 9),
                  cursor="hand2", pady=3).pack(fill=tk.X, padx=8, pady=(8, 2))
        tk.Button(left, text="View Quarantine", command=self._show_quarantine,
                  bg="#45475a", fg=self.fg, relief=tk.FLAT, font=("Segoe UI", 9),
                  cursor="hand2", pady=3).pack(fill=tk.X, padx=8, pady=2)

        tk.Button(
            left, text="← Back (Account)",
            command=self._back_to_account,
            bg="#585b70", fg=self.fg, relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5
        ).pack(fill=tk.X, padx=8, pady=(12, 2))

        tk.Button(
            left, text="Logout",
            command=self._logout,
            bg="#f38ba8", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5
        ).pack(fill=tk.X, padx=8, pady=2)

        # Output
        right = tk.Frame(main, bg=self.bg)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        tk.Label(right, text="Live Output / Alerts / Status Reports", font=("Segoe UI", 9, "bold"),
                 bg=self.bg, fg=self.fg).pack(anchor="w")

        self.output = scrolledtext.ScrolledText(
            right, wrap=tk.WORD, bg="#11111b", fg=self.fg,
            insertbackground=self.fg, font=("Consolas", 10), relief=tk.FLAT
        )
        self.output.pack(fill=tk.BOTH, expand=True, pady=(3, 0))
        self.output.tag_configure("warn", foreground="#f38ba8")
        self.output.tag_configure("ok", foreground="#a6e3a1")
        self.output.tag_configure("info", foreground="#89b4fa")
        self.output.tag_configure("alert", foreground="#fab387", font=("Consolas", 10, "bold"))
        self.output.tag_configure("ai", foreground="#cba6f7", font=("Consolas", 10, "bold"))
        self.output.tag_configure("file", foreground="#94e2d5", font=("Consolas", 10, "bold"))
        self.output.tag_configure("delete", foreground="#eba0ac", font=("Consolas", 10, "bold"))
        self.output.tag_configure("status", foreground="#f9e2af", font=("Consolas", 10, "bold"))

        self.status = tk.Label(
            self.root, text="Ready  |  Auto-Delete OFF  |  Status Report OFF  |  Monitor OFF",
            bg="#181825", fg="#a6adc8", font=("Segoe UI", 9), anchor="w", padx=10
        )
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

        self._write("Welcome to Anti-ComputerVIRUS v7.3\n", "info")
        self._write("New: Settings button - enable Status Reports or Uninstall the app.\n", "ok")
        self._write("Auto-Delete is OFF by default (safe mode).\n\n", "ok")

    # ---------- Settings Window ----------
    def _open_codespace(self):
        """Open a built-in code editor to write and run your own anti-virus."""
        if getattr(self, "_codespace_win", None) and self._codespace_win.winfo_exists():
            self._codespace_win.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("Codespace - Create Your Own Anti-Virus")
        win.geometry("720x520")
        win.configure(bg=self.panel)
        win.minsize(500, 360)
        self._codespace_win = win

        tk.Label(
            win, text="Create Your Own Anti-Virus",
            font=("Segoe UI", 13, "bold"), bg=self.panel, fg="#cba6f7"
        ).pack(pady=(10, 2))
        tk.Label(
            win, text="Write Python code below. Use print() to show results. Click Run to execute.",
            bg=self.panel, fg="#a6adc8", font=("Segoe UI", 8)
        ).pack()

        editor = scrolledtext.ScrolledText(
            win, wrap=tk.NONE, bg="#11111b", fg="#cdd6f4",
            insertbackground="#cdd6f4", font=("Consolas", 10), relief=tk.FLAT
        )
        editor.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)
        starter = (
            "# My Anti-Virus\n"
            "# Write your own detection logic here\n"
            "import os\n"
            "from pathlib import Path\n\n"
            "print('Scanning...')\n"
            "home = Path.home()\n"
            "for p in home.glob('*.txt'):\n"
            "    print('Found:', p.name)\n"
            "print('Done.')\n"
        )
        editor.insert("1.0", starter)

        out = scrolledtext.ScrolledText(
            win, wrap=tk.WORD, bg="#181825", fg="#a6e3a1",
            font=("Consolas", 9), relief=tk.FLAT, height=8
        )
        out.pack(fill=tk.X, padx=12, pady=(0, 8))
        out.insert("1.0", "Output will appear here...\n")
        out.config(state=tk.DISABLED)

        btn_row = tk.Frame(win, bg=self.panel)
        btn_row.pack(fill=tk.X, padx=12, pady=(0, 10))

        def run_code():
            code = editor.get("1.0", tk.END)
            out.config(state=tk.NORMAL)
            out.delete("1.0", tk.END)
            out.insert("1.0", "Running...\n")
            out.config(state=tk.DISABLED)
            win.update()

            import io, contextlib
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                    exec(code, {"__name__": "__main__"})
                result = buf.getvalue() or "(no output)"
            except Exception as e:
                result = f"Error: {e}"
            out.config(state=tk.NORMAL)
            out.delete("1.0", tk.END)
            out.insert("1.0", result)
            out.config(state=tk.DISABLED)
            log("User ran custom anti-virus code")

        def save_code():
            code = editor.get("1.0", tk.END)
            dest = Path.home() / "my_antivirus.py"
            try:
                dest.write_text(code)
                out.config(state=tk.NORMAL)
                out.insert(tk.END, f"\nSaved to {dest}\n")
                out.config(state=tk.DISABLED)
                log(f"Saved custom antivirus to {dest}")
            except Exception as e:
                out.config(state=tk.NORMAL)
                out.insert(tk.END, f"\nSave failed: {e}\n")
                out.config(state=tk.DISABLED)

        tk.Button(
            btn_row, text="Run", command=run_code,
            bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", padx=16, pady=4
        ).pack(side=tk.LEFT, padx=(0, 8))

        tk.Button(
            btn_row, text="Save as my_antivirus.py", command=save_code,
            bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", padx=12, pady=4
        ).pack(side=tk.LEFT)

    def _create_firewall(self):

        """Create / enable a basic firewall (ufw preferred, iptables fallback)."""
        self._write("\n=== CREATE FIREWALL ===\n", "info")
        log("Create Firewall started")
        is_root = hasattr(os, "geteuid") and os.geteuid() == 0

        if not is_root:
            self._write("Not running as root - firewall changes may be limited.\n", "warn")
            self._write("Re-run with sudo for full firewall setup.\n", "info")

        # Prefer ufw
        ufw = run_cmd("which ufw 2>/dev/null")
        if ufw:
            status = run_cmd("ufw status 2>/dev/null")
            self._write("UFW detected.\n", "info")
            if "inactive" in status.lower() or not status:
                enable = run_cmd("ufw --force enable 2>&1")
                self._write(enable + "\n", "ok" if "enabled" in enable.lower() else "warn")
            else:
                self._write("UFW is already active.\n", "ok")
            # Default deny incoming, allow outgoing
            run_cmd("ufw default deny incoming 2>&1")
            run_cmd("ufw default allow outgoing 2>&1")
            # Allow SSH so user isn't locked out
            run_cmd("ufw allow OpenSSH 2>&1 || ufw allow 22/tcp 2>&1")
            final = run_cmd("ufw status verbose 2>/dev/null")
            self._write("Firewall status:\n" + (final or "Could not read status") + "\n", "info")
            log("Firewall created via ufw")
        else:
            # Fallback: iptables basic rules
            self._write("UFW not found - attempting basic iptables rules.\n", "info")
            if is_root:
                cmds = [
                    "iptables -P INPUT DROP",
                    "iptables -P FORWARD DROP",
                    "iptables -P OUTPUT ACCEPT",
                    "iptables -A INPUT -i lo -j ACCEPT",
                    "iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT",
                    "iptables -A INPUT -p tcp --dport 22 -j ACCEPT",
                ]
                for c in cmds:
                    run_cmd(c + " 2>&1")
                self._write("Basic iptables rules applied (deny incoming, allow established + SSH).\n", "ok")
                self._write("Note: rules are not persistent across reboot unless saved.\n", "info")
                log("Firewall created via iptables")
            else:
                self._write("Cannot apply iptables without root.\n", "warn")
                self._write("Install ufw or re-run as root.\n", "info")

        self._write("\nFirewall setup finished.\n", "ok")
        log("Create Firewall finished")

    def _show_user_menu(self):
        """Show a small user menu from the top-right button."""
        menu = tk.Menu(self.root, tearoff=0, bg=self.panel, fg=self.fg)
        acc = load_account()
        uname = acc.get("username", "No account")
        menu.add_command(label=f"Signed in as: {uname}", state=tk.DISABLED)
        menu.add_separator()
        menu.add_command(label="userAccount", command=self._show_user_account)
        menu.add_command(label="Authentication Settings", command=self._open_settings)
        menu.add_command(label="Logout", command=self._logout)
        # Position near the button
        try:
            x = self.user_btn.winfo_rootx()
            y = self.user_btn.winfo_rooty() + self.user_btn.winfo_height()
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()

    def _create_antivirus(self):


        """Create / activate full anti-virus protection: full scan + start monitor."""
        self._write("\n=== CREATING ANTI-VIRUS PROTECTION ===\n", "info")
        log("Create Anti-Virus activated")
        self.status.config(text="Creating anti-virus protection...")
        self.root.update()

        def worker():
            try:
                report = full_scan_report()
                self.root.after(0, lambda: self._scan_done(report))
                # Start monitor after scan
                self.root.after(500, self._start_monitor)
                self.root.after(600, lambda: self._write("\nAnti-Virus protection is now active.\n", "ok"))
                log("Anti-Virus protection created and monitor started")
            except Exception as e:
                self.root.after(0, lambda: self._scan_done(f"Error creating anti-virus: {e}"))

        threading.Thread(target=worker, daemon=True).start()

    def _open_ai_helper(self):

        """Open AI Helper chatbox window."""
        if getattr(self, "_ai_helper_win", None) and self._ai_helper_win.winfo_exists():
            self._ai_helper_win.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("AI Helper - Anti-ComputerVIRUS")
        win.geometry("520x440")
        win.configure(bg=self.panel)
        win.minsize(400, 320)
        self._ai_helper_win = win

        tk.Label(
            win, text="AI Helper", font=("Segoe UI", 13, "bold"),
            bg=self.panel, fg=self.ai_color
        ).pack(pady=(10, 2))
        tk.Label(
            win, text="Ask about files, malware, quarantine, or how to use the app",
            bg=self.panel, fg="#a6adc8", font=("Segoe UI", 8)
        ).pack()

        chat = scrolledtext.ScrolledText(
            win, wrap=tk.WORD, bg="#11111b", fg=self.fg,
            insertbackground=self.fg, font=("Consolas", 10), relief=tk.FLAT, height=16
        )
        chat.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)
        chat.tag_configure("user", foreground="#89b4fa")
        chat.tag_configure("bot", foreground="#a6e3a1")
        chat.tag_configure("sys", foreground="#a6adc8")
        chat.insert(tk.END, "AI Helper online. Type a question below.\n\n", "sys")
        chat.config(state=tk.DISABLED)

        row = tk.Frame(win, bg=self.panel)
        row.pack(fill=tk.X, padx=12, pady=(0, 12))
        entry = tk.Entry(row, bg="#11111b", fg=self.fg, insertbackground=self.fg,
                         relief=tk.FLAT, font=("Segoe UI", 10))
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=5, padx=(0, 8))

        def send(_event=None):
            msg = entry.get().strip()
            if not msg:
                return
            entry.delete(0, tk.END)
            entry.config(state=tk.DISABLED)
            chat.config(state=tk.NORMAL)
            chat.insert(tk.END, f"You: {msg}\n", "user")
            chat.insert(tk.END, "AI: Thinking...\n", "sys")
            chat.config(state=tk.DISABLED)
            chat.see(tk.END)
            win.update_idletasks()

            def respond():
                try:
                    if USE_GROK and GROK_API_KEY:
                        reply = chatgpt_reply(msg, GROK_API_KEY)
                    else:
                        reply = ai_helper_reply(msg)
                except Exception as e:
                    reply = f"Helper error: {e}"
                chat.config(state=tk.NORMAL)
                # remove trailing "Thinking..." line
                try:
                    content = chat.get("1.0", tk.END)
                    if content.rstrip().endswith("Thinking..."):
                        idx = chat.search("AI: Thinking...", "end-5l", tk.END)
                        if idx:
                            chat.delete(idx, tk.END)
                except Exception:
                    pass
                chat.insert(tk.END, f"AI: {reply}\n\n", "bot")
                chat.config(state=tk.DISABLED)
                chat.see(tk.END)
                entry.config(state=tk.NORMAL)
                entry.focus_set()
                log(f"AI Helper Q: {msg[:80]}")

            win.after(10, respond)

        tk.Button(
            row, text="Send", command=send,
            bg=self.ai_color, fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", padx=12, pady=4
        ).pack(side=tk.RIGHT)
        entry.bind("<Return>", send)
        entry.focus_set()

    def _open_settings(self):

        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("Settings - Anti-ComputerVIRUS")
        win.geometry("500x560")
        win.configure(bg=self.panel)
        win.resizable(True, True)
        win.minsize(420, 400)
        self.settings_window = win

        tk.Label(win, text="⚙  Settings", font=("Segoe UI", 14, "bold"),
                 bg=self.panel, fg=self.settings_color).pack(pady=(12, 6))

        # Scrollable area
        outer = tk.Frame(win, bg=self.panel)
        outer.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

        canvas = tk.Canvas(outer, bg=self.panel, highlightthickness=0)
        scrollbar = tk.Scrollbar(outer, orient=tk.VERTICAL, command=canvas.yview, width=18)
        scroll_frame = tk.Frame(canvas, bg=self.panel)

        scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")

        def _on_canvas_configure(event):
            canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind("<Configure>", _on_canvas_configure)
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        def _on_linux_scroll_up(event):
            canvas.yview_scroll(-1, "units")
        def _on_linux_scroll_down(event):
            canvas.yview_scroll(1, "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        canvas.bind_all("<Button-4>", _on_linux_scroll_up)
        canvas.bind_all("<Button-5>", _on_linux_scroll_down)

        def _unbind_scroll(_event=None):
            try:
                canvas.unbind_all("<MouseWheel>")
                canvas.unbind_all("<Button-4>")
                canvas.unbind_all("<Button-5>")
            except Exception:
                pass
        win.protocol("WM_DELETE_WINDOW", lambda: (_unbind_scroll(), win.destroy()))

        # ---- content inside scroll_frame ----
        def section(parent, title, color, desc):
            f = tk.Frame(parent, bg="#45475a", padx=12, pady=10)
            f.pack(fill=tk.X, padx=12, pady=6)
            tk.Label(f, text=title, font=("Segoe UI", 10, "bold"),
                     bg="#45475a", fg=color).pack(anchor="w")
            tk.Label(f, text=desc, bg="#45475a", fg="#a6adc8",
                     font=("Segoe UI", 8), justify="left").pack(anchor="w", pady=(2, 6))
            return f

        # Status Report
        frame1 = section(scroll_frame, "Monitor Status Report", self.fg,
                         "When enabled, the monitor posts a status summary\nevery 30 seconds while it is running.")
        self.status_report_var = tk.BooleanVar(value=STATUS_REPORT_ENABLED)
        tk.Checkbutton(
            frame1, text="Turn ON Status Report for Monitor",
            variable=self.status_report_var, command=self._toggle_status_report,
            bg="#45475a", fg=self.fg, selectcolor="#313244",
            activebackground="#45475a", activeforeground=self.fg,
            font=("Segoe UI", 9), cursor="hand2"
        ).pack(anchor="w")

        # UserLogs
        frame_logs = section(scroll_frame, "UserLogs / Coding Information", self.accent,
                             "View app coding info, version, log paths, and recent user logs.")
        tk.Button(
            frame_logs, text="UserLogs Coding Information",
            command=self._show_coding_info,
            bg=self.accent, fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # Configment
        frame_cfg = section(scroll_frame, "Configment", "#f9e2af",
                            "Run diagnostics: check paths, permissions, dependencies, and config.")
        tk.Button(
            frame_cfg, text="Configment",
            command=self._run_configment,
            bg="#f9e2af", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # FilesProtectionInformation
        frame_fpi = section(scroll_frame, "Files Protection Information", "#94e2d5",
                            "Shows watched folders, protection rules, quarantine status, and file safety tips.")
        tk.Button(
            frame_fpi, text="FilesProtectionInformation",
            command=self._show_files_protection_info,
            bg="#94e2d5", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # Troubleshoot
        frame_ts = section(scroll_frame, "Troubleshoot", "#fab387",
                           "Fix common issues: reset monitor, clear seen alerts, test quarantine.")
        tk.Button(
            frame_ts, text="Troubleshoot",
            command=self._run_troubleshoot,
            bg="#fab387", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # Lockdown mode
        frame_ld = section(scroll_frame, "Lockdown Mode", "#f38ba8",
                           "If something is not working, freeze the app for 1 second\nto stabilize, then continue. Toggle ON to enable.")
        self.lockdown_var = tk.BooleanVar(value=LOCKDOWN_MODE)
        tk.Checkbutton(
            frame_ld, text="Enable Lockdown Mode (1s freeze when issues detected)",
            variable=self.lockdown_var, command=self._toggle_lockdown,
            bg="#45475a", fg=self.fg, selectcolor="#313244",
            activebackground="#45475a", activeforeground=self.fg,
            font=("Segoe UI", 9), cursor="hand2"
        ).pack(anchor="w")
        tk.Button(
            frame_ld, text="Trigger Lockdown Now (1s freeze)",
            command=self._trigger_lockdown,
            bg="#f38ba8", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))

        # userAccount
        frame_ua = section(scroll_frame, "userAccount", "#cba6f7",
                           "Show current user account info used by the antivirus.")
        tk.Button(
            frame_ua, text="userAccount",
            command=self._show_user_account,
            bg="#cba6f7", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)
        tk.Button(
            frame_ua, text="Create an Account",
            command=self._open_create_account_from_settings,
            bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))

        # Disk Protection & Backup
        frame_disk = section(scroll_frame, "Disk Protection & Backup", "#74c7ec",
                             "Check disk health, free space, and create/restore safe backups of important folders.")
        tk.Button(
            frame_disk, text="Disk Protection Scan",
            command=self._disk_protection_scan,
            bg="#74c7ec", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)
        tk.Button(
            frame_disk, text="Disk Check",
            command=self._disk_check,
            bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))
        tk.Button(
            frame_disk, text="Disk Repair",
            command=self._disk_repair,
            bg="#f38ba8", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))
        tk.Button(
            frame_disk, text="Create Backup",
            command=self._create_backup,
            bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))
        tk.Button(
            frame_disk, text="List Backups",
            command=self._list_backups,
            bg="#f9e2af", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))
        tk.Button(
            frame_disk, text="Restore Latest Backup",
            command=self._restore_latest_backup,
            bg="#fab387", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))

        # Black Mode
        frame_black = section(scroll_frame, "Black Mode", "#cdd6f4",
                              "Switch the main interface to a darker black theme.")
        self.black_mode_var = tk.BooleanVar(value=BLACK_MODE)
        tk.Checkbutton(
            frame_black, text="Enable Black Mode",
            variable=self.black_mode_var, command=self._toggle_black_mode,
            bg="#45475a", fg=self.fg, selectcolor="#313244",
            activebackground="#45475a", activeforeground=self.fg,
            font=("Segoe UI", 9), cursor="hand2"
        ).pack(anchor="w")

        # Grok integration
        frame_gpt = section(scroll_frame, "Grok Integration", "#a6e3a1",
                            "Optional: use xAI Grok for AI Helper answers. Requires your API key.")
        self.chatgpt_var = tk.BooleanVar(value=USE_GROK)
        tk.Checkbutton(
            frame_gpt, text="Use Grok for AI Helper",
            variable=self.chatgpt_var, command=self._toggle_chatgpt,
            bg="#45475a", fg=self.fg, selectcolor="#313244",
            activebackground="#45475a", activeforeground=self.fg,
            font=("Segoe UI", 9), cursor="hand2"
        ).pack(anchor="w")
        tk.Label(frame_gpt, text="xAI / Grok API Key:", bg="#45475a", fg="#a6adc8",
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(6, 0))
        tk.Label(frame_gpt, text="Current key: A45Aihel1rtp", bg="#45475a", fg="#a6e3a1",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w")
        self.api_key_entry = tk.Entry(frame_gpt, bg="#11111b", fg=self.fg,
                                      insertbackground=self.fg, relief=tk.FLAT)
        self.api_key_entry.pack(fill=tk.X, pady=2, ipady=3)
        if GROK_API_KEY:
            self.api_key_entry.insert(0, GROK_API_KEY)
        tk.Button(
            frame_gpt, text="Save Grok API Key",
            command=self._save_api_key,
            bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 8, "bold"), cursor="hand2", pady=3
        ).pack(anchor="w", pady=(4, 0))

        # AuthenticationSettings
        frame_auth = section(scroll_frame, "AuthenticationSettings", "#f9e2af",
                             "Manage authentication and account security options.")
        tk.Button(
            frame_auth, text="Authentication-management",
            command=self._open_auth_management,
            bg="#f9e2af", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)
        tk.Button(
            frame_auth, text="UserAuthR3",
            command=self._open_user_auth_r3,
            bg="#fab387", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))

        # Full Protection (paid)
        frame_paid = section(scroll_frame, "Full Protection", "#a6e3a1",
                             "Unlock VirusRemoval and VirusBlocker for $1.99.")
        tk.Label(frame_paid, text="VirusRemoval + VirusBlocker",
                 bg="#45475a", fg="#a6e3a1", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        tk.Label(frame_paid, text="Price: $1.99",
                 bg="#45475a", fg="#f9e2af", font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 6))
        tk.Button(
            frame_paid, text="Unlock Full Protection (Free)",
            command=self._unlock_full_protection_free,
            bg="#f9e2af", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))
        tk.Button(
            frame_paid, text="Free Upgrade",
            command=self._free_upgrade,
            bg="#94e2d5", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X, pady=(6, 0))

        # [User]RT1>USERCONFIGURATION
        frame_rt1 = section(scroll_frame, "[User]RT1>USERCONFIGURATION", "#cba6f7",
                            "User configuration and RT1 settings.")
        tk.Button(
            frame_rt1, text="[User]RT1>USERCONFIGURATION",
            command=self._open_user_rt1_config,
            bg="#cba6f7", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # About the app
        frame_about = section(scroll_frame, "About the App", "#89b4fa",
                              "Version, features, and contact information.")
        tk.Button(
            frame_about, text="Info about the App",
            command=self._show_app_info,
            bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # Reload boot screen
        frame_boot = section(scroll_frame, "Reload Booting Up", "#89b4fa",
                             "Replay the post-login booting / loading screen, then return to the main menu.")
        tk.Button(
            frame_boot, text="Reload Booting Up",
            command=self._reload_booting_up,
            bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # Uninstall
        frame2 = section(scroll_frame, "Uninstall / Delete App", self.delete_color,
                         "Removes the antivirus script, log file, and quarantine folder.\nThis cannot be undone.")
        tk.Button(
            frame2, text="Delete / Uninstall Anti-ComputerVIRUS",
            command=self._uninstall_app,
            bg=self.delete_color, fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(fill=tk.X)

        # Close at bottom (outside scroll)
        tk.Button(
            win, text="Close Settings",
            command=lambda: (_unbind_scroll(), win.destroy()),
            bg="#45475a", fg=self.fg, relief=tk.FLAT,
            font=("Segoe UI", 9), cursor="hand2", pady=6
        ).pack(pady=10)

    def _ensure_backup_dir(self):
        BACKUP_DIR.mkdir(mode=0o700, exist_ok=True)
        return BACKUP_DIR

    def _disk_check(self):
        """Run a read-only disk consistency check (fsck dry-run style)."""
        self._write("\n=== DISK CHECK ===\n", "info")
        log("Disk Check started")

        # Check filesystem type and mount status
        out = run_cmd("df -T / 2>/dev/null")
        if out:
            self._write("Root filesystem:\n" + out + "\n", "info")
        else:
            self._write("Could not determine filesystem type.\n", "warn")

        # Try smartctl if available (read-only health)
        smart = run_cmd("smartctl -H /dev/sda 2>/dev/null || smartctl -H /dev/nvme0n1 2>/dev/null")
        if smart and "PASSED" in smart.upper():
            self._write("SMART health: PASSED\n", "ok")
        elif smart:
            self._write("SMART result:\n" + smart[:400] + "\n", "warn")
        else:
            self._write("SMART tools not available (optional).\n", "info")

        # Basic inode / free space check
        free = run_cmd("df -i / 2>/dev/null | tail -1")
        if free:
            self._write("Inode usage:\n" + free + "\n", "info")

        # Look for common error signs in dmesg (last 20 lines)
        dmesg = run_cmd("dmesg -T 2>/dev/null | tail -15 || dmesg | tail -15")
        if dmesg and any(x in dmesg.lower() for x in ["error", "fail", "i/o", "corrupt"]):
            self._write("Recent kernel messages (possible issues):\n" + dmesg[:600] + "\n", "warn")
            log("Disk Check found possible kernel errors", "WARN")
        else:
            self._write("No obvious disk errors in recent kernel messages.\n", "ok")

        self._write("\nDisk Check complete (read-only).\n", "ok")
        self._write("For full repair, use Disk Repair (may require root).\n", "info")
        log("Disk Check finished")

    def _disk_repair(self):
        """Attempt safe disk repair actions (non-destructive where possible)."""
        self._write("\n=== DISK REPAIR ===\n", "info")
        log("Disk Repair started")

        # Warn if not root
        is_root = hasattr(os, "geteuid") and os.geteuid() == 0
        if not is_root:
            self._write("Not running as root - some repairs will be skipped.\n", "warn")
            self._write("Re-run with sudo for full repair capability.\n", "info")

        actions = []

        # 1. Sync filesystems
        sync = run_cmd("sync")
        actions.append("Filesystem sync completed")
        self._write("  [OK] Filesystems synced\n", "ok")

        # 2. Drop caches (if root)
        if is_root:
            drop = run_cmd("echo 3 > /proc/sys/vm/drop_caches 2>/dev/null && echo OK")
            if "OK" in drop:
                actions.append("Dropped page caches")
                self._write("  [OK] Page caches dropped\n", "ok")
            else:
                self._write("  [SKIP] Could not drop caches\n", "warn")

        # 3. Try fsck dry-run on root (if available and not mounted read-write issues)
        fsck = run_cmd("fsck -n / 2>&1 | head -20")
        if fsck and "clean" in fsck.lower():
            actions.append("fsck dry-run: filesystem clean")
            self._write("  [OK] fsck dry-run: filesystem appears clean\n", "ok")
        elif fsck:
            self._write("  fsck output (excerpt):\n" + fsck[:500] + "\n", "info")
            actions.append("fsck dry-run completed")
        else:
            self._write("  [SKIP] fsck not available or permission denied\n", "warn")

        # 4. Check and remount if needed (read-only suggestion)
        mounts = run_cmd("mount | grep ' / '")
        if mounts and "ro," in mounts:
            self._write("  Root is mounted read-only - consider remounting read-write if needed.\n", "warn")
        else:
            self._write("  Root mount looks normal.\n", "ok")

        self._write(f"\nDisk Repair finished ({len(actions)} action(s)).\n", "ok")
        self._write("Note: Full fsck repair usually requires unmounting or booting from live media.\n", "info")
        log(f"Disk Repair finished: {actions}")

    def _disk_protection_scan(self):

        """Scan disk usage, mounts, and large/suspicious files."""
        self._write("\n=== DISK PROTECTION SCAN ===\n", "info")
        log("Disk Protection Scan started")
        findings = []

        # Disk usage
        out = run_cmd("df -h 2>/dev/null | head -15")
        if out:
            self._write("Disk usage:\n" + out + "\n", "info")
            for line in out.splitlines()[1:]:
                parts = line.split()
                if len(parts) >= 5 and parts[4].endswith("%"):
                    try:
                        pct = int(parts[4].rstrip("%"))
                        if pct >= 90:
                            findings.append(f"High disk usage on {parts[0]}: {parts[4]}")
                    except Exception:
                        pass
        else:
            self._write("Could not read disk usage.\n", "warn")

        # Mount options (look for noexec, nosuid on /tmp)
        mounts = run_cmd("mount 2>/dev/null | head -20")
        if mounts:
            self._write("Mounts (excerpt):\n" + mounts[:800] + "\n", "info")
            if "noexec" not in mounts and "/tmp" in mounts:
                findings.append("/tmp may lack noexec mount option (executables can run)")

        # Large files in watched areas
        home = str(Path.home())
        large = run_cmd(f'find /tmp "{home}/Downloads" "{home}/Desktop" -type f -size +100M 2>/dev/null | head -10')
        if large:
            self._write("Large files (>100MB):\n" + large + "\n", "warn")
            findings.append("Large files detected in temp/user folders")
        else:
            self._write("No large files (>100MB) in scanned locations.\n", "ok")

        # Free space warning
        free = run_cmd("df -h / | tail -1")
        if free:
            self._write(f"Root filesystem: {free}\n", "info")

        if findings:
            self._write("\nFindings:\n", "warn")
            for f in findings:
                self._write(f"  • {f}\n", "warn")
                log(f"Disk finding: {f}", "WARN")
        else:
            self._write("\nDisk protection scan: no major issues found.\n", "ok")
        self._write("Disk Protection Scan complete.\n", "ok")
        log("Disk Protection Scan finished")

    def _create_backup(self):
        """Create a timestamped backup of important user folders."""
        self._ensure_backup_dir()
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = BACKUP_DIR / f"backup_{stamp}"
        dest.mkdir(parents=True, exist_ok=True)
        self._write(f"\n=== CREATING BACKUP ===\nDestination: {dest}\n", "info")
        log(f"Backup started: {dest}")

        home = Path.home()
        targets = [
            home / "Documents",
            home / "Desktop",
            home / "Downloads",
            home / ".ssh",
        ]
        copied = 0
        for t in targets:
            if not t.exists():
                continue
            try:
                import shutil
                target_dest = dest / t.name
                if t.is_dir():
                    shutil.copytree(t, target_dest, dirs_exist_ok=True, ignore=shutil.ignore_patterns("*.tmp", "*.log"))
                else:
                    shutil.copy2(t, target_dest)
                self._write(f"  Backed up: {t}\n", "ok")
                copied += 1
            except Exception as e:
                self._write(f"  Skip {t}: {e}\n", "warn")
                log(f"Backup skip {t}: {e}", "WARN")

        # Also backup account and log
        for f in [ACCOUNT_FILE, LOG_FILE]:
            if f.exists():
                try:
                    import shutil
                    shutil.copy2(f, dest / f.name)
                    self._write(f"  Backed up: {f.name}\n", "ok")
                    copied += 1
                except Exception:
                    pass

        note = dest / "BACKUP_INFO.txt"
        note.write_text(
            f"Created: {datetime.now()}\n"
            f"Items: {copied}\n"
            f"Source home: {home}\n"
        )
        self._write(f"\nBackup complete: {copied} item(s) saved to {dest}\n", "ok")
        log(f"Backup finished: {dest} ({copied} items)")

    def _list_backups(self):
        """List available backups."""
        self._ensure_backup_dir()
        backups = sorted(BACKUP_DIR.glob("backup_*"), reverse=True)
        self._write("\n=== AVAILABLE BACKUPS ===\n", "info")
        if not backups:
            self._write("No backups found.\n", "warn")
            return
        for b in backups[:10]:
            size = sum(f.stat().st_size for f in b.rglob("*") if f.is_file()) if b.exists() else 0
            self._write(f"  {b.name}  ({size // 1024} KB)\n", "info")
        if len(backups) > 10:
            self._write(f"  ... and {len(backups) - 10} more\n", "info")
        log(f"Listed {len(backups)} backups")

    def _restore_latest_backup(self):
        """Restore the most recent backup to a restore folder (safe, non-destructive)."""
        self._ensure_backup_dir()
        backups = sorted(BACKUP_DIR.glob("backup_*"), reverse=True)
        if not backups:
            self._write("\nNo backups available to restore.\n", "warn")
            return
        latest = backups[0]
        restore_to = Path.home() / f"restored_from_{latest.name}"
        try:
            import shutil
            if restore_to.exists():
                shutil.rmtree(restore_to)
            shutil.copytree(latest, restore_to)
            self._write(f"\n=== RESTORE COMPLETE ===\n", "ok")
            self._write(f"Restored latest backup to:\n  {restore_to}\n", "ok")
            self._write("Original files were NOT overwritten.\n", "info")
            log(f"Restored backup {latest} -> {restore_to}")
        except Exception as e:
            self._write(f"\nRestore failed: {e}\n", "warn")
            log(f"Restore failed: {e}", "ERROR")

    def _toggle_chatgpt(self):
        global USE_GROK
        USE_GROK = self.chatgpt_var.get()
        if USE_GROK:
            self._write("\n*** Grok mode ENABLED for AI Helper ***\n", "ok")
            log("Grok mode ENABLED")
        else:
            self._write("\n*** Grok mode DISABLED - using local helper ***\n", "info")
            log("Grok mode DISABLED")

    def _save_api_key(self):
        global GROK_API_KEY
        key = self.api_key_entry.get().strip()
        GROK_API_KEY = key
        if key:
            self._write("\nAPI key saved (session only).\n", "ok")
            log("Grok API key saved")
        else:
            self._write("\nAPI key cleared.\n", "warn")

    def _toggle_black_mode(self):

        """Toggle black/dark theme on the main window."""
        global BLACK_MODE
        BLACK_MODE = self.black_mode_var.get()
        if BLACK_MODE:
            # Darker blacks
            self.bg = "#0d0d0d"
            self.panel = "#1a1a1a"
            self.fg = "#e0e0e0"
            self.root.configure(bg=self.bg)
            self.status.configure(bg="#0a0a0a", fg="#aaaaaa")
            self._write("\n*** Black Mode ENABLED ***\n", "info")
            log("Black Mode ENABLED")
        else:
            # Restore original dark-but-not-black theme
            self.bg = "#1e1e2e"
            self.panel = "#313244"
            self.fg = "#cdd6f4"
            self.root.configure(bg=self.bg)
            self.status.configure(bg="#181825", fg="#a6adc8")
            self._write("\n*** Black Mode DISABLED ***\n", "ok")
            log("Black Mode DISABLED")
        # Note: full theme refresh would require rebuilding widgets;
        # this updates the main window background and status bar.

    def _open_user_auth_r3(self):
        """UserAuthR3 - additional authentication tools."""
        if getattr(self, "_auth_r3_win", None) and self._auth_r3_win.winfo_exists():
            self._auth_r3_win.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("UserAuthR3")
        win.geometry("400x280")
        win.configure(bg=self.panel)
        win.resizable(False, False)
        self._auth_r3_win = win

        tk.Label(win, text="UserAuthR3",
                 font=("Segoe UI", 13, "bold"), bg=self.panel, fg="#fab387").pack(pady=(16, 8))

        acc = load_account()
        status = "Account exists" if acc.get("username") else "No account"
        tk.Label(
            win,
            text=f"Status: {status}\nUsername: {acc.get('username', '-')}\n\nUserAuthR3 tools",
            bg=self.panel, fg=self.fg, font=("Segoe UI", 9), justify="left"
        ).pack(padx=20, pady=8)

        def reset_session():
            global USE_GROK
            USE_GROK = False
            self._write("\nUserAuthR3: Session flags reset.\n", "info")
            log("UserAuthR3 session reset")
            messagebox.showinfo("UserAuthR3", "Session flags reset.")

        tk.Button(
            win, text="Reset Session Flags",
            command=reset_session,
            bg="#fab387", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5
        ).pack(pady=6)

        def app_intel_restart():
            """AppIntel-i17coreRestart - restart the app core."""
            if messagebox.askyesno(
                "AppIntel-i17coreRestart",
                "This will restart the anti-virus core (reload booting screen).\nContinue?"
            ):
                log("AppIntel-i17coreRestart triggered")
                win.destroy()
                self._reload_booting_up()

        tk.Button(
            win, text="AppIntel-i17coreRestart",
            command=app_intel_restart,
            bg="#cba6f7", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5
        ).pack(pady=4)

        def cyber_alert():
            """Show a cybersecurity alert summary."""
            alerts = [
                "High-risk files are quarantined first.",
                "Auto-Delete is OFF by default.",
                "Monitor watches /tmp, home, Downloads, Desktop.",
                "Enable Lockdown in Settings if the app feels stuck.",
                "Contact: adamaryaan001@gmail.com"
            ]
            msg = "CYBERSECURITY ALERT\n\n" + "\n".join(f"• {a}" for a in alerts)
            messagebox.showinfo("CyberSecurityAlert", msg)
            self._write("\n=== CYBERSECURITY ALERT ===\n" + "\n".join(alerts) + "\n", "warn")
            log("CyberSecurityAlert displayed")

        tk.Button(
            win, text="CyberSecurityAlert",
            command=cyber_alert,
            bg="#f38ba8", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5
        ).pack(pady=4)

        tk.Button(
            win, text="Close",
            command=win.destroy,
            bg="#45475a", fg=self.fg, relief=tk.FLAT,
            font=("Segoe UI", 9), cursor="hand2", pady=4
        ).pack(pady=4)

        log("UserAuthR3 opened")

    def _open_auth_management(self):

        """Open Authentication-management window."""
        if getattr(self, "_auth_win", None) and self._auth_win.winfo_exists():
            self._auth_win.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("Authentication-management")
        win.geometry("420x320")
        win.configure(bg=self.panel)
        win.resizable(False, False)
        self._auth_win = win

        tk.Label(win, text="Authentication-management",
                 font=("Segoe UI", 13, "bold"), bg=self.panel, fg="#f9e2af").pack(pady=(16, 8))

        info = tk.Label(
            win,
            text="Manage your account authentication.\n\n"
                 "• Change password (requires current password)\n"
                 "• View account status\n"
                 "• Local account stored in ~/.anti-computer-virus-account.json",
            bg=self.panel, fg=self.fg, font=("Segoe UI", 9), justify="left"
        )
        info.pack(padx=20, pady=10)

        def change_pw():
            # Simple dialog-style prompt via messagebox + entries
            from tkinter import simpledialog
            old = simpledialog.askstring("Current Password", "Enter current password:", show="*")
            if not old:
                return
            acc = load_account()
            if not acc or not verify_account(acc.get("username", ""), old):
                messagebox.showerror("Error", "Current password incorrect.")
                return
            new = simpledialog.askstring("New Password", "Enter new password:", show="*")
            if not new or len(new) < 4:
                messagebox.showerror("Error", "New password must be at least 4 characters.")
                return
            if save_account(acc.get("username", ""), new):
                messagebox.showinfo("Success", "Password updated.")
                log("Password changed via Authentication-management")
            else:
                messagebox.showerror("Error", "Failed to update password.")

        tk.Button(
            win, text="Change Password",
            command=change_pw,
            bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(pady=8)

        def forgot():
            if messagebox.askyesno("Forgot Password", "Clear password so a new one can be set?"):
                acc = load_account()
                if acc.get("username"):
                    import json
                    acc["password_hash"] = ""
                    acc["reset_required"] = True
                    ACCOUNT_FILE.write_text(json.dumps(acc, indent=2))
                    messagebox.showinfo("Done", "Password cleared. Log out and set a new password on the account screen.")
                    log("Password reset from Authentication-management")
                else:
                    messagebox.showwarning("No account", "No account to reset.")

        tk.Button(
            win, text="Forgot Password",
            command=forgot,
            bg="#fab387", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(pady=4)

        def send_reset_email():
            import webbrowser, urllib.parse
            subject = urllib.parse.quote("Anti-ComputerVIRUS Password Reset Request")
            body = urllib.parse.quote("Hello,\n\nI need to reset my Anti-ComputerVIRUS password.\n\nThank you.")
            webbrowser.open(f"mailto:adamaryaan001@gmail.com?subject={subject}&body={body}")
            log("Password reset email opened from Authentication-management")

        tk.Button(
            win, text="Password Reset Email",
            command=send_reset_email,
            bg="#89b4fa", fg="#1e1e2e", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), cursor="hand2", pady=6
        ).pack(pady=4)

        tk.Button(
            win, text="Close",
            command=win.destroy,
            bg="#45475a", fg=self.fg, relief=tk.FLAT,
            font=("Segoe UI", 9), cursor="hand2", pady=4
        ).pack(pady=4)

        log("Authentication-management opened")

    def _free_upgrade(self):
        """Free upgrade - unlocks all premium features at no cost."""
        self._write("\n*** FREE UPGRADE applied - all premium features unlocked ***\n", "ok")
        log("Free Upgrade applied")
        messagebox.showinfo(
            "Free Upgrade",
            "Upgrade complete!\n\n"
            "You now have:\n"
            "• VirusRemoval\n"
            "• VirusBlocker\n"
            "• Full Protection features\n\n"
            "No payment required."
        )

    def _unlock_full_protection_free(self):

        """Unlock VirusRemoval and VirusBlocker without payment."""
        self._write("\n*** Full Protection unlocked (free) - VirusRemoval + VirusBlocker ***\n", "ok")
        log("Full Protection unlocked for free")
        messagebox.showinfo(
            "Full Protection",
            "VirusRemoval and VirusBlocker are now unlocked.\n\nNo payment required."
        )

    def _show_app_info(self):




        """Show information about the app."""
        info = (
            "\n=== ABOUT ANTI-COMPUTERVIRUS ===\n"
            f"Version: {VERSION}\n"
            "Author: Adam and the antivirus team\n"
            "Contact: adamaryaan001@gmail.com\n\n"
            "Features:\n"
            "• AI Threat Detection (heuristic scoring)\n"
            "• Real-time file + process monitoring\n"
            "• Auto-Delete (optional, quarantine first)\n"
            "• Disk Protection, Check, Repair, Backup\n"
            "• Create Firewall, Create Your Own Anti-Virus (codespace)\n"
            "• Account system, Lockdown Mode, AI Helper Chat\n"
            "• Settings: Configment, Troubleshoot, UserLogs, and more\n"
        )
        self._write(info, "info")
        log("App info viewed")

    def _reload_booting_up(self):


        """Close main UI and replay the post-login booting loading screen."""
        if self.monitor.running:
            self.monitor.stop()
        log("Reload Booting Up requested from Settings")
        try:
            if self.settings_window and self.settings_window.winfo_exists():
                self.settings_window.destroy()
        except Exception:
            pass
        self.root.destroy()
        PostLoginBootScreen().run()

    def _toggle_lockdown(self):

        global LOCKDOWN_MODE
        LOCKDOWN_MODE = self.lockdown_var.get()
        if LOCKDOWN_MODE:
            self._write("\n*** Lockdown Mode ENABLED - will freeze 1s when issues are handled ***\n", "warn")
            log("Lockdown Mode ENABLED")
        else:
            self._write("\n*** Lockdown Mode DISABLED ***\n", "ok")
            log("Lockdown Mode DISABLED")
        self._update_status_bar()

    def _trigger_lockdown(self):
        """Freeze UI for LOCKDOWN_FREEZE_SEC seconds (recovery pause)."""
        self._write("\n*** LOCKDOWN: freezing for 1 second... ***\n", "warn")
        log("Lockdown freeze triggered")
        self.status.config(text="LOCKDOWN - frozen 1s...")
        self.root.update_idletasks()
        self.root.config(cursor="watch")
        try:
            # Brief freeze so user sees lockdown / recovery pause
            time.sleep(LOCKDOWN_FREEZE_SEC)
        finally:
            self.root.config(cursor="")
        self._write("*** LOCKDOWN complete - continuing ***\n", "ok")
        self._update_status_bar()
        log("Lockdown freeze finished")

    def _maybe_lockdown_on_error(self, context: str = ""):
        """Call when something is not working; freezes for 1 second if Lockdown Mode is ON."""
        global LOCKDOWN_MODE
        if not LOCKDOWN_MODE:
            return
        try:
            self._write(f"\n*** Lockdown (issue: {context or 'unknown'}) - freezing 1s ***\n", "warn")
            self.root.update_idletasks()
            self.root.config(cursor="watch")
            time.sleep(LOCKDOWN_FREEZE_SEC)
            self.root.config(cursor="")
            self._write("*** Lockdown released ***\n", "ok")
            log(f"Lockdown auto-freeze after issue: {context}")
        except Exception:
            pass

    def _toggle_status_report(self):
        global STATUS_REPORT_ENABLED
        STATUS_REPORT_ENABLED = self.status_report_var.get()
        if STATUS_REPORT_ENABLED:
            self._write("\n*** Status Report ENABLED - monitor will post summaries every 30s ***\n", "status")
            log("Status Report ENABLED")
            self._update_status_bar()
        else:
            self._write("\n*** Status Report DISABLED ***\n", "ok")
            log("Status Report DISABLED")
            self._update_status_bar()

    def _show_coding_info(self):
        """Show UserLogs + coding / app information in the main output."""
        this = Path(__file__).resolve()
        lines = [
            "",
            "=" * 52,
            "  USERLOGS / CODING INFORMATION",
            "=" * 52,
            "",
            f"  App name       : Anti-ComputerVIRUS",
            f"  Version        : {VERSION}",
            f"  Language       : Python 3",
            f"  Framework      : tkinter GUI + pure-Python AI heuristics",
            f"  Author credit  : Adam and the antivirus team",
            "",
            "  --- File paths ---",
            f"  Script path    : {this}",
            f"  Script SHA256  : {file_hash(this)[:40]}...",
            f"  Log file       : {LOG_FILE}",
            f"  Quarantine dir : {QUARANTINE_DIR}",
            "",
            "  --- Current settings ---",
            f"  Auto-Delete    : {'ON' if AUTO_DELETE_ENABLED else 'OFF'} (threshold >= {AUTO_DELETE_THRESHOLD})",
            f"  Status Report  : {'ON' if STATUS_REPORT_ENABLED else 'OFF'}",
            f"  Monitor        : {'RUNNING' if self.monitor.running else 'STOPPED'}",
            "",
            "  --- Coding modules ---",
            "  • AI Threat Engine (entropy, name, location, permissions)",
            "  • Real-time FileSystemWatcher",
            "  • Process & port monitor",
            "  • Classic scanners (Hacker/Malware/Trojan/Worm/VPN/Client)",
            "  • Quarantine + optional auto-delete",
            "  • Settings: Status Report, UserLogs, Uninstall",
            "",
            "  --- Recent user log (last 25 lines) ---",
            "",
        ]
        self._write("\n".join(lines) + "\n", "info")
        if LOG_FILE.exists():
            for line in LOG_FILE.read_text().splitlines()[-25:]:
                tag = "delete" if "DELETED" in line else ("warn" if any(x in line for x in ["WARN", "ALERT", "ERROR"]) else "status")
                self._write(line + "\n", tag)
        else:
            self._write("  (no log file yet)\n", "ok")
        self._write("\n" + "=" * 52 + "\n", "info")
        log("UserLogs Coding Information viewed")
        # bring main window to front so user sees the output
        self.root.lift()

    def _run_configment(self):
        """Configment = troubleshooting / diagnostics for the app."""
        lines = [
            "",
            "=" * 52,
            "  CONFIGMENT (Diagnostics)",
            "=" * 52,
            "",
        ]
        ok_count = 0
        warn_count = 0

        # Python version
        import platform as _plat
        pyver = _plat.python_version()
        lines.append(f"  [OK] Python version: {pyver}")
        ok_count += 1

        # tkinter
        try:
            import tkinter
            lines.append("  [OK] tkinter available (GUI OK)")
            ok_count += 1
        except ImportError:
            lines.append("  [WARN] tkinter missing - GUI will not work")
            warn_count += 1

        # Script path & readable
        this = Path(__file__).resolve()
        if this.exists():
            lines.append(f"  [OK] Script exists: {this}")
            ok_count += 1
            try:
                mode = oct(this.stat().st_mode)[-3:]
                lines.append(f"  [OK] Script permissions: {mode}")
                ok_count += 1
            except Exception as e:
                lines.append(f"  [WARN] Cannot read script perms: {e}")
                warn_count += 1
        else:
            lines.append("  [WARN] Script path not found")
            warn_count += 1

        # Log file
        try:
            LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(LOG_FILE, "a") as f:
                f.write("")
            lines.append(f"  [OK] Log writable: {LOG_FILE}")
            ok_count += 1
        except Exception as e:
            lines.append(f"  [WARN] Log not writable: {e}")
            warn_count += 1

        # Quarantine
        try:
            ensure_quarantine()
            test = QUARANTINE_DIR / ".configment_test"
            test.write_text("ok")
            test.unlink()
            lines.append(f"  [OK] Quarantine writable: {QUARANTINE_DIR}")
            ok_count += 1
        except Exception as e:
            lines.append(f"  [WARN] Quarantine issue: {e}")
            warn_count += 1

        # Watch dirs
        lines.append("")
        lines.append("  --- Watch directories ---")
        for d in WATCH_DIRS:
            p = Path(d)
            if p.exists():
                lines.append(f"  [OK] Exists: {d}")
                ok_count += 1
            else:
                lines.append(f"  [WARN] Missing: {d}")
                warn_count += 1

        # Basic commands used by scanners
        lines.append("")
        lines.append("  --- System tools ---")
        for cmd, label in [("ss -h", "ss"), ("ps aux", "ps"), ("find --version", "find")]:
            out = run_cmd(cmd + " 2>&1 | head -1")
            if out or run_cmd(f"which {label}"):
                lines.append(f"  [OK] {label} available")
                ok_count += 1
            else:
                lines.append(f"  [WARN] {label} may be missing (some scans limited)")
                warn_count += 1

        # Settings summary
        lines.append("")
        lines.append("  --- Current config ---")
        lines.append(f"  Version          : {VERSION}")
        lines.append(f"  Auto-Delete      : {'ON' if AUTO_DELETE_ENABLED else 'OFF'}")
        lines.append(f"  Status Report    : {'ON' if STATUS_REPORT_ENABLED else 'OFF'}")
        lines.append(f"  Monitor running  : {self.monitor.running}")
        lines.append(f"  Delete threshold : {AUTO_DELETE_THRESHOLD}")

        lines.append("")
        lines.append(f"  Summary: {ok_count} OK, {warn_count} warnings")
        if warn_count == 0:
            lines.append("  Configment result: All checks passed.")
        else:
            lines.append("  Configment result: Some issues found - see warnings above.")
        lines.append("=" * 52)

        self._write("\n".join(lines) + "\n", "status")
        log(f"Configment run: {ok_count} OK, {warn_count} warnings")
        self.root.lift()

    def _show_files_protection_info(self):
        """FilesProtectionInformation - watched paths, rules, quarantine, safety tips."""
        ensure_quarantine()
        q_files = list(QUARANTINE_DIR.glob("*")) if QUARANTINE_DIR.exists() else []
        q_count = len([f for f in q_files if not f.name.endswith(".note")])

        lines = [
            "",
            "=" * 52,
            "  FILESPROTECTIONINFORMATION",
            "=" * 52,
            "",
            "  --- Protected / watched folders ---",
        ]
        for d in WATCH_DIRS:
            p = Path(d)
            status = "ACTIVE" if p.exists() else "NOT FOUND"
            lines.append(f"  [{status}] {d}")

        lines.extend([
            "",
            "  --- Protection rules (from original project) ---",
            "  block > Hacker",
            "  antiVirus > malware | block > malware | remove > malware",
            "  delete > trojan | remove > trojan | Block > trojan",
            "  antiVirus > wormVirus | Block > wormVirus | Kill > wormVirus",
            "  antivirus > vpn | Vpn > protection",
            "  antivirus > protection | antiClient > protection",
            "",
            "  --- How files are protected ---",
            "  1. Real-time watcher indexes files in the folders above",
            "  2. New or modified files are scored by the AI engine",
            "  3. Score >= 40  -> quarantined (safe copy)",
            "  4. Score >= 60  -> if Auto-Delete ON, original is deleted",
            "  5. Critical system paths are never deleted",
            "",
            "  --- Quarantine status ---",
            f"  Location : {QUARANTINE_DIR}",
            f"  Items    : {q_count} quarantined file(s)",
            f"  Auto-Delete : {'ON' if AUTO_DELETE_ENABLED else 'OFF'} (threshold >= {AUTO_DELETE_THRESHOLD})",
            "",
            "  --- Safety tips ---",
            "  • Keep Auto-Delete OFF unless you understand false positives",
            "  • Review quarantine before permanently removing copies",
            "  • Do not run untrusted scripts from /tmp or Downloads",
            "  • Use Configment if scans or the monitor misbehave",
            "",
            "=" * 52,
        ])
        self._write("\n".join(lines) + "\n", "file")
        log("FilesProtectionInformation viewed")
        self.root.lift()

    def _run_troubleshoot(self):
        """Open a white troubleshoot page with contact info and lockdown option."""
        if getattr(self, "_ts_win", None) and self._ts_win.winfo_exists():
            self._ts_win.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("Troubleshoot - Anti-ComputerVIRUS")
        win.geometry("520x380")
        win.configure(bg="white")
        win.resizable(False, False)
        self._ts_win = win

        # Top right: Go back button
        top = tk.Frame(win, bg="white")
        top.pack(fill=tk.X, padx=10, pady=8)
        tk.Button(
            top, text="Go back to the main menu",
            command=win.destroy,
            bg="#e0e0e0", fg="#333", relief=tk.FLAT,
            font=("Segoe UI", 9), cursor="hand2", padx=10, pady=4
        ).pack(side=tk.RIGHT)

        # Center content
        center = tk.Frame(win, bg="white")
        center.pack(expand=True, fill=tk.BOTH, padx=30, pady=20)

        tk.Label(
            center, text="Troubleshoot",
            font=("Segoe UI", 18, "bold"), bg="white", fg="#333"
        ).pack(pady=(10, 16))

        tk.Label(
            center, text="Need help?",
            font=("Segoe UI", 12), bg="white", fg="#555"
        ).pack(pady=(0, 8))

        def open_email():
            import webbrowser
            webbrowser.open("mailto:adamaryaan001@gmail.com")

        email_btn = tk.Button(
            center, text="Email: adamaryaan001@gmail.com",
            command=open_email,
            font=("Segoe UI", 11, "underline"), bg="white", fg="#0066cc",
            relief=tk.FLAT, cursor="hand2", activebackground="white",
            activeforeground="#004499"
        )
        email_btn.pack(pady=4)

        tk.Label(
            center, text="or",
            font=("Segoe UI", 10), bg="white", fg="#888"
        ).pack(pady=6)

        def enable_lockdown():
            global LOCKDOWN_MODE
            LOCKDOWN_MODE = True
            if hasattr(self, "lockdown_var"):
                self.lockdown_var.set(True)
            self._write("\n*** Lockdown Mode ENABLED from Troubleshoot page ***\n", "warn")
            log("Lockdown enabled from Troubleshoot page")
            tk.Label(center, text="Lockdown is now ON.", bg="white", fg="#cc0000",
                     font=("Segoe UI", 10, "bold")).pack(pady=6)

        tk.Button(
            center, text="Turn on Lockdown",
            command=enable_lockdown,
            bg="#ff6666", fg="white", relief=tk.FLAT,
            font=("Segoe UI", 10, "bold"), cursor="hand2", padx=16, pady=6
        ).pack(pady=10)

        tk.Label(
            center, text="Lockdown freezes the app for 1 second when issues occur.",
            font=("Segoe UI", 8), bg="white", fg="#666", wraplength=400
        ).pack(pady=(8, 0))

        log("Troubleshoot page opened")


    def _show_user_account(self):
        """userAccount - show current user / account context for the app."""
        import getpass
        import pwd

        user = getpass.getuser()
        home = str(Path.home())
        uid = os.getuid() if hasattr(os, "getuid") else "N/A"
        euid = os.geteuid() if hasattr(os, "geteuid") else "N/A"
        try:
            pw = pwd.getpwuid(os.getuid())
            shell = pw.pw_shell
            gecos = pw.pw_gecos
        except Exception:
            shell = "N/A"
            gecos = "N/A"

        is_root = (euid == 0) if isinstance(euid, int) else False

        lines = [
            "",
            "=" * 52,
            "  userAccount",
            "=" * 52,
            "",
            f"  Username     : {user}",
            f"  Home         : {home}",
            f"  UID          : {uid}",
            f"  Effective UID: {euid}",
            f"  Shell        : {shell}",
            f"  GECOS        : {gecos}",
            f"  Running as root: {'YES (be careful)' if is_root else 'No'}",
            "",
            "  --- App data for this account ---",
            f"  Log file     : {LOG_FILE}",
            f"  Quarantine   : {QUARANTINE_DIR}",
            f"  Log exists   : {LOG_FILE.exists()}",
            f"  Quarantine exists: {QUARANTINE_DIR.exists()}",
            "",
            "  --- Session settings ---",
            f"  Auto-Delete  : {'ON' if AUTO_DELETE_ENABLED else 'OFF'}",
            f"  Status Report: {'ON' if STATUS_REPORT_ENABLED else 'OFF'}",
            f"  Monitor      : {'RUNNING' if self.monitor.running else 'STOPPED'}",
            "",
            "=" * 52,
        ]
        self._write("\n".join(lines) + "\n", "ai")
        log(f"userAccount viewed for user={user}")
        self.root.lift()

    def _open_create_account_from_settings(self):
        """Open a small create-account dialog from Settings."""
        win = tk.Toplevel(self.root)
        win.title("Create an Account")
        win.geometry("360x280")
        win.configure(bg="#313244")
        win.resizable(False, False)

        tk.Label(win, text="Create an Account", font=("Segoe UI", 12, "bold"),
                 bg="#313244", fg="#a6e3a1").pack(pady=(14, 8))

        tk.Label(win, text="Username", bg="#313244", fg="#cdd6f4").pack(anchor="w", padx=24)
        u = tk.Entry(win, bg="#11111b", fg="#cdd6f4", insertbackground="#cdd6f4", relief=tk.FLAT)
        u.pack(fill=tk.X, padx=24, pady=4, ipady=3)

        tk.Label(win, text="Password", bg="#313244", fg="#cdd6f4").pack(anchor="w", padx=24)
        p = tk.Entry(win, bg="#11111b", fg="#cdd6f4", insertbackground="#cdd6f4", relief=tk.FLAT, show="*")
        p.pack(fill=tk.X, padx=24, pady=4, ipady=3)

        tk.Label(win, text="Confirm password", bg="#313244", fg="#cdd6f4").pack(anchor="w", padx=24)
        c = tk.Entry(win, bg="#11111b", fg="#cdd6f4", insertbackground="#cdd6f4", relief=tk.FLAT, show="*")
        c.pack(fill=tk.X, padx=24, pady=4, ipady=3)

        err = tk.Label(win, text="", bg="#313244", fg="#f38ba8", font=("Segoe UI", 8))
        err.pack()

        def do_create():
            user, pw, conf = u.get().strip(), p.get(), c.get()
            if not user or not pw:
                err.config(text="Username and password required")
                return
            if len(pw) < 4:
                err.config(text="Password min 4 characters")
                return
            if pw != conf:
                err.config(text="Passwords do not match")
                return
            if save_account(user, pw):
                err.config(text="Account saved!", fg="#a6e3a1")
                self._write(f"\nAccount created/updated for: {user}\n", "ok")
                win.after(700, win.destroy)
            else:
                err.config(text="Failed to save account")

        tk.Button(win, text="Create an Account", command=do_create,
                  bg="#a6e3a1", fg="#1e1e2e", relief=tk.FLAT,
                  font=("Segoe UI", 9, "bold"), cursor="hand2", pady=5).pack(pady=10)





    def _uninstall_app(self):
        ok = messagebox.askyesno(
            "Uninstall Anti-ComputerVIRUS?",
            "This will permanently delete:\n\n"
            "• The antivirus script\n"
            "• Log file (~/.anti-computer-virus.log)\n"
            "• Quarantine folder (~/.anti-computer-virus-quarantine)\n\n"
            "The app will close after deletion.\n\n"
            "Are you sure?"
        )
        if not ok:
            return
        ok2 = messagebox.askyesno(
            "Final confirmation",
            "Really delete everything? This cannot be undone."
        )
        if not ok2:
            return

        self.monitor.stop()
        log("User requested uninstall - deleting app files")

        deleted = []
        errors = []

        # Delete log
        try:
            if LOG_FILE.exists():
                LOG_FILE.unlink()
                deleted.append(str(LOG_FILE))
        except Exception as e:
            errors.append(f"Log: {e}")

        # Delete quarantine
        try:
            if QUARANTINE_DIR.exists():
                shutil.rmtree(QUARANTINE_DIR)
                deleted.append(str(QUARANTINE_DIR))
        except Exception as e:
            errors.append(f"Quarantine: {e}")

        # Delete this script
        try:
            this = Path(__file__).resolve()
            if this.exists():
                this.unlink()
                deleted.append(str(this))
        except Exception as e:
            errors.append(f"Script: {e}")

        msg = "Uninstall complete.\n\nDeleted:\n" + "\n".join(deleted)
        if errors:
            msg += "\n\nErrors:\n" + "\n".join(errors)
        messagebox.showinfo("Uninstall", msg)
        self.root.destroy()
        sys.exit(0)

    def _update_status_bar(self):
        ad = "ON" if AUTO_DELETE_ENABLED else "OFF"
        sr = "ON" if STATUS_REPORT_ENABLED else "OFF"
        mon = "ON" if self.monitor.running else "OFF"
        ld = "ON" if LOCKDOWN_MODE else "OFF"
        self.status.config(text=f"Auto-Delete {ad}  |  Status Report {sr}  |  Lockdown {ld}  |  Monitor {mon}")

    def _toggle_auto_delete(self):
        global AUTO_DELETE_ENABLED
        AUTO_DELETE_ENABLED = self.delete_var.get()
        if AUTO_DELETE_ENABLED:
            ok = messagebox.askyesno(
                "Enable Auto-Delete?",
                "This will permanently delete high-risk files AFTER making a quarantine copy.\n\n"
                "Only files with AI score >= 60 are deleted.\n"
                "System-critical paths are never touched.\n\n"
                "Are you sure you want to enable Auto-Delete?"
            )
            if not ok:
                self.delete_var.set(False)
                AUTO_DELETE_ENABLED = False
                return
            self.delete_status.config(text="ON - will delete high-risk", fg=self.delete_color)
            self._write("\n*** AUTO-DELETE ENABLED - high-risk files will be removed after quarantine ***\n", "delete")
            log("Auto-Delete ENABLED by user")
        else:
            self.delete_status.config(text="OFF (safe mode)", fg=self.ok)
            self._write("\n*** AUTO-DELETE DISABLED - safe mode ***\n", "ok")
            log("Auto-Delete DISABLED by user")
        self._update_status_bar()

    def _write(self, text, tag=None):
        self.output.insert(tk.END, text, tag)
        self.output.see(tk.END)

    def _run_scan(self, func):
        self.status.config(text="Scanning...")
        self._write(f"\n{'='*48}\n", "info")
        self.root.update()

        def worker():
            try:
                report = func()
                self.root.after(0, lambda: self._scan_done(report))
            except Exception as e:
                self.root.after(0, lambda: (self._maybe_lockdown_on_error(str(e)), self._scan_done(f"Error: {e}")))

        threading.Thread(target=worker, daemon=True).start()

    def _scan_done(self, report: str):
        for line in report.splitlines():
            if "DELETED" in line:
                self._write(line + "\n", "delete")
            elif "HIGH RISK" in line or "WARNING" in line or "SUSPICIOUS" in line or "RISKY" in line:
                self._write(line + "\n", "warn")
            elif "AI " in line or "=== AI" in line or (line.strip().startswith("[") and "]" in line):
                self._write(line + "\n", "ai")
            elif "No " in line or "Findings: 0" in line:
                self._write(line + "\n", "ok")
            else:
                self._write(line + "\n")
        self._write("\nDone.\n", "ok")
        self._update_status_bar()

    def _start_monitor(self):
        self.monitor.start()
        self.mon_status.config(text="Running (files + AI)", fg=self.ok)
        self.btn_start.config(state=tk.DISABLED)
        self.btn_stop.config(state=tk.NORMAL)
        self._update_status_bar()
        self._write("\n>>> Real-time File + AI monitoring STARTED\n", "ok")
        if AUTO_DELETE_ENABLED:
            self._write("Auto-Delete is ON - high-risk files will be removed.\n", "delete")
        if STATUS_REPORT_ENABLED:
            self._write("Status Report is ON - summaries every 30 seconds.\n", "status")

    def _stop_monitor(self):
        self.monitor.stop()
        self.mon_status.config(text="Stopped", fg=self.warn)
        self.btn_start.config(state=tk.NORMAL)
        self.btn_stop.config(state=tk.DISABLED)
        self._update_status_bar()
        self._write("\n>>> Real-time monitoring STOPPED\n", "warn")

    def _on_alert(self, msg: str, score: int = 0):
        if "DELETED" in msg:
            tag = "delete"
        elif "FILE " in msg:
            tag = "file"
        elif score >= 60:
            tag = "alert"
        else:
            tag = "ai"
        self.root.after(0, lambda: self._write(f"ALERT: {msg}\n", tag))
        self.root.after(0, lambda: self.status.config(text=f"ALERT [{score}]: {msg[:55]}..."))

    def _on_status_report(self, report: str):
        self.root.after(0, lambda: self._write(f"\n{report}\n", "status"))

    def _show_log(self):
        self._write("\n=== LOG (last 50 lines) ===\n", "info")
        if LOG_FILE.exists():
            for line in LOG_FILE.read_text().splitlines()[-50:]:
                tag = "delete" if "DELETED" in line else ("warn" if any(x in line for x in ["WARN", "ALERT", "ERROR"]) else None)
                self._write(line + "\n", tag)
        else:
            self._write("No log yet.\n")

    def _show_quarantine(self):
        ensure_quarantine()
        files = list(QUARANTINE_DIR.glob("*"))
        self._write("\n=== QUARANTINE ===\n", "info")
        if not files:
            self._write("Empty.\n", "ok")
        else:
            for f in sorted(files)[-50:]:
                self._write(f"  {f.name}\n")

    def _back_to_account(self):
        """Return to the account screen from the main antivirus menu."""
        if self.monitor.running:
            self.monitor.stop()
        log("Back to account screen")
        self.root.destroy()
        AccountScreen()

    def _logout(self):
        """Log out and return to the account login screen."""
        if self.monitor.running:
            self.monitor.stop()
        log("User logged out")
        self.root.destroy()
        # Show account screen (login / create)
        AccountScreen()

    def _on_close(self):
        self.monitor.stop()
        log("GUI closed")
        self.root.destroy()

    def run(self):
        self.root.mainloop()

# ===================== CLI =====================

def cli_menu():
    global AUTO_DELETE_ENABLED, STATUS_REPORT_ENABLED
    print(f"\nAnti-ComputerVIRUS v{VERSION} (CLI)")
    print(f"Auto-Delete: {'ON' if AUTO_DELETE_ENABLED else 'OFF'}  |  Status Report: {'ON' if STATUS_REPORT_ENABLED else 'OFF'}")
    print("1) AI Threat Scan")
    print("2) Full Scan")
    print("3) Start Real-Time File + AI Monitor")
    print("4) Toggle Auto-Delete")
    print("5) Toggle Status Report")
    print("6) Uninstall / Delete App")
    print("0) Exit")
    while True:
        try:
            c = input("Choice: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if c == "1":
            print(ai_threat_scan())
        elif c == "2":
            print(full_scan_report())
        elif c == "3":
            mon = RealTimeMonitor(
                alert_callback=lambda m, s=0: print(f"ALERT [{s}] {m}"),
                status_callback=lambda r: print(r) if STATUS_REPORT_ENABLED else None
            )
            mon.start()
            print("Real-time Monitor running... Ctrl+C to stop")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                mon.stop()
                print("Stopped.")
        elif c == "4":
            AUTO_DELETE_ENABLED = not AUTO_DELETE_ENABLED
            print(f"Auto-Delete is now: {'ON' if AUTO_DELETE_ENABLED else 'OFF'}")
            if AUTO_DELETE_ENABLED:
                print("WARNING: High-risk files (score >= 60) will be deleted after quarantine.")
            log(f"Auto-Delete toggled to {AUTO_DELETE_ENABLED}")
        elif c == "5":
            STATUS_REPORT_ENABLED = not STATUS_REPORT_ENABLED
            print(f"Status Report is now: {'ON' if STATUS_REPORT_ENABLED else 'OFF'}")
            log(f"Status Report toggled to {STATUS_REPORT_ENABLED}")
        elif c == "6":
            confirm = input("Type YES to permanently delete the app, log and quarantine: ").strip()
            if confirm == "YES":
                print("Uninstalling...")
                try:
                    if LOG_FILE.exists():
                        LOG_FILE.unlink()
                        print(f"Deleted {LOG_FILE}")
                    if QUARANTINE_DIR.exists():
                        shutil.rmtree(QUARANTINE_DIR)
                        print(f"Deleted {QUARANTINE_DIR}")
                    this = Path(__file__).resolve()
                    this.unlink()
                    print(f"Deleted {this}")
                    print("Uninstall complete.")
                    sys.exit(0)
                except Exception as e:
                    print(f"Error during uninstall: {e}")
            else:
                print("Cancelled.")
        elif c == "0":
            break

# ===================== Entry =====================

if __name__ == "__main__":
    ensure_quarantine()
    log(f"Anti-ComputerVIRUS v{VERSION} started")

    if len(sys.argv) > 1 and sys.argv[1] in ("--cli", "-c"):
        cli_menu()
    elif HAS_GUI:
        try:
            # Boot screen → Account (create/login) → Main antivirus menu
            BootScreen().run()
        except Exception as e:
            print(f"GUI failed ({e}), falling back to CLI.")
            cli_menu()
    else:
        print("tkinter not available - CLI mode.")
        cli_menu()
