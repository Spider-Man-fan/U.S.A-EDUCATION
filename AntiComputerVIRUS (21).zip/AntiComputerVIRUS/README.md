# Anti-ComputerVIRUS v8.8

## Optional Grok Integration

In **Settings → Grok Integration**:
1. Check **Use Grok for AI Helper**
2. Paste your xAI API key
3. Click **Save Grok API Key**

The AI Helper chatbox will then use **Grok** (grok-2-latest).  
If no key is set or the call fails, it falls back to the local helper.

Get an API key at: https://console.x.ai

```bash
python3 anti_computer_virus.py
```
