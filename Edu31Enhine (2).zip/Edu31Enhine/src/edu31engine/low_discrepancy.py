"""
Low-discrepancy sequences for Quasi-Monte Carlo.

Low-discrepancy sequences fill the unit interval (or hypercube) more evenly
than pure random points. This leads to faster convergence for integration
in low to moderate dimensions (error often ~ 1/N instead of 1/√N).

Implemented sequences:
- Van der Corput / Halton (radical inverse)
- Sobol' (simplified 1D direction numbers)
- Additive recurrence (Kronecker sequence)
"""

import numpy as np
from typing import Optional


def radical_inverse(n: int, base: int = 2) -> float:
    """
    Radical inverse function φ_b(n).
    
    Writes n in base b, then reflects the digits after the radix point.
    Example (base 2): n=6 (110₂) → 0.011₂ = 0.375
    """
    result = 0.0
    f = 1.0 / base
    while n > 0:
        result += f * (n % base)
        n //= base
        f /= base
    return result


def halton_sequence(n: int, base: int = 2, start: int = 1) -> np.ndarray:
    """
    Generate n points of the Halton sequence in base `base`.
    
    In 1D, Halton = Van der Corput sequence.
    In higher dimensions, use different prime bases per dimension.
    """
    return np.array([radical_inverse(i, base) for i in range(start, start + n)])


def kronecker_sequence(n: int, alpha: float = None, start: float = 0.0) -> np.ndarray:
    """
    Kronecker (additive recurrence) sequence: {x + i*α} mod 1.
    
    Best when α is irrational (e.g. golden ratio conjugate).
    Extremely simple and effective in 1D.
    """
    if alpha is None:
        # Golden ratio conjugate: (√5 - 1)/2 ≈ 0.618
        alpha = (np.sqrt(5) - 1) / 2
    
    indices = np.arange(n)
    return (start + indices * alpha) % 1.0


def sobol_1d(n: int) -> np.ndarray:
    """
    Simplified 1D Sobol' sequence using direction numbers.
    
    This is a basic implementation for educational purposes.
    For production high-dimensional work, use scipy.stats.qmc.Sobol.
    """
    # Direction numbers for 1D (powers of 1/2)
    # v_i = 2^{-i}
    points = np.zeros(n)
    for i in range(n):
        # Gray code index
        gray = i ^ (i >> 1)
        # Convert Gray code bits to Sobol point
        val = 0.0
        bit = 0
        while gray:
            if gray & 1:
                val += 0.5 ** (bit + 1)
            gray >>= 1
            bit += 1
        points[i] = val
    return points


def hammersley_sequence(n: int, dim: int = 2) -> np.ndarray:
    """
    Hammersley set: first coordinate is i/n, remaining are Halton.
    
    Useful for finite point sets (not infinite sequences).
    Returns shape (n, dim).
    """
    points = np.zeros((n, dim))
    points[:, 0] = np.arange(n) / n
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    for d in range(1, dim):
        base = primes[d - 1] if d - 1 < len(primes) else primes[-1]
        points[:, d] = halton_sequence(n, base=base)
    return points


def discrepancy_estimate(points: np.ndarray) -> float:
    """
    Rough 1D star-discrepancy estimate (educational approximation).
    
    Lower is better. Pure random ~ O(√(log log N / N)),
    low-discrepancy sequences aim for O((log N)/N).
    """
    points = np.sort(np.asarray(points).ravel())
    n = len(points)
    # Compare empirical CDF to theoretical uniform CDF
    empirical = np.arange(1, n + 1) / n
    theoretical = points
    return float(np.max(np.abs(empirical - theoretical)))


def generate_sequence(name: str, n: int, **kwargs) -> np.ndarray:
    """
    Convenience wrapper to generate a named low-discrepancy sequence.
    
    Supported: 'halton', 'kronecker', 'sobol', 'random'
    """
    name = name.lower()
    if name == "halton":
        return halton_sequence(n, base=kwargs.get("base", 2))
    elif name == "kronecker":
        return kronecker_sequence(n, alpha=kwargs.get("alpha"))
    elif name == "sobol":
        return sobol_1d(n)
    elif name == "random":
        rng = np.random.default_rng(kwargs.get("seed"))
        return rng.random(n)
    else:
        raise ValueError(f"Unknown sequence: {name}")
