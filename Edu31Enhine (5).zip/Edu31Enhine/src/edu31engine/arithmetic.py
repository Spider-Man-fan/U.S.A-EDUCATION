"""
Fraction arithmetic and the four basic operations.

Supports:
- Integer addition, subtraction, multiplication, division
- Fraction addition, subtraction, multiplication, division
- Mixed numbers
- Simplification
"""

import random
import math
from typing import Tuple, Optional
from .question_generators import Question


def gcd(a: int, b: int) -> int:
    """Greatest common divisor."""
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a


def simplify_fraction(num: int, den: int) -> Tuple[int, int]:
    """Return simplified fraction (num, den) with positive denominator."""
    if den == 0:
        raise ZeroDivisionError("Denominator cannot be zero")
    if den < 0:
        num, den = -num, -den
    g = gcd(num, den)
    return num // g, den // g


def fraction_to_str(num: int, den: int) -> str:
    """Format a fraction as a string."""
    num, den = simplify_fraction(num, den)
    if den == 1:
        return str(num)
    return f"{num}/{den}"


# ---------------------------------------------------------------------------
# Integer operations (improved generators)
# ---------------------------------------------------------------------------

def generate_addition(difficulty: str = "medium") -> Question:
    ranges = {"easy": (1, 10), "medium": (5, 50), "hard": (20, 200), "challenge": (100, 999)}
    lo, hi = ranges.get(difficulty, (1, 20))
    a, b = random.randint(lo, hi), random.randint(lo, hi)
    return Question(
        prompt=f"{a} + {b} = ?",
        answer=a + b,
        explanation=f"{a} + {b} = {a + b}",
        difficulty=difficulty,
        metadata={"op": "add", "a": a, "b": b},
    )


def generate_subtraction(difficulty: str = "medium") -> Question:
    ranges = {"easy": (1, 10), "medium": (5, 50), "hard": (20, 200), "challenge": (50, 500)}
    lo, hi = ranges.get(difficulty, (1, 20))
    a = random.randint(lo + 5, hi + 10)
    b = random.randint(lo, a)
    return Question(
        prompt=f"{a} − {b} = ?",
        answer=a - b,
        explanation=f"{a} − {b} = {a - b}",
        difficulty=difficulty,
        metadata={"op": "sub", "a": a, "b": b},
    )


def generate_multiplication(difficulty: str = "medium") -> Question:
    ranges = {"easy": (1, 5), "medium": (2, 12), "hard": (5, 20), "challenge": (10, 30)}
    lo, hi = ranges.get(difficulty, (2, 9))
    a, b = random.randint(lo, hi), random.randint(lo, hi)
    return Question(
        prompt=f"{a} × {b} = ?",
        answer=a * b,
        explanation=f"{a} × {b} = {a * b}",
        difficulty=difficulty,
        metadata={"op": "mul", "a": a, "b": b},
    )


def generate_division(difficulty: str = "medium") -> Question:
    """Clean division (no remainder)."""
    ranges = {"easy": (2, 5), "medium": (2, 10), "hard": (3, 15), "challenge": (5, 25)}
    lo, hi = ranges.get(difficulty, (2, 9))
    b = random.randint(lo, hi)
    q = random.randint(lo, hi)
    a = b * q
    return Question(
        prompt=f"{a} ÷ {b} = ?",
        answer=q,
        explanation=f"{a} ÷ {b} = {q}",
        difficulty=difficulty,
        metadata={"op": "div", "a": a, "b": b},
    )


# ---------------------------------------------------------------------------
# Fraction operations
# ---------------------------------------------------------------------------

def _random_fraction(max_den: int = 12) -> Tuple[int, int]:
    den = random.randint(2, max_den)
    num = random.randint(1, den * 2)
    return simplify_fraction(num, den)


def generate_fraction_add(difficulty: str = "medium") -> Question:
    max_den = {"easy": 6, "medium": 10, "hard": 15, "challenge": 20}.get(difficulty, 10)
    n1, d1 = _random_fraction(max_den)
    n2, d2 = _random_fraction(max_den)
    # a/b + c/d = (a*d + b*c) / (b*d)
    num = n1 * d2 + n2 * d1
    den = d1 * d2
    ans = fraction_to_str(num, den)
    return Question(
        prompt=f"{fraction_to_str(n1, d1)} + {fraction_to_str(n2, d2)} = ?",
        answer=ans,
        explanation=f"Common denominator {den}: {n1*d2}/{den} + {n2*d1}/{den} = {ans}",
        difficulty=difficulty,
        metadata={"op": "frac_add"},
    )


def generate_fraction_sub(difficulty: str = "medium") -> Question:
    max_den = {"easy": 6, "medium": 10, "hard": 15, "challenge": 20}.get(difficulty, 10)
    n1, d1 = _random_fraction(max_den)
    n2, d2 = _random_fraction(max_den)
    # Ensure positive result
    if n1 / d1 < n2 / d2:
        n1, d1, n2, d2 = n2, d2, n1, d1
    num = n1 * d2 - n2 * d1
    den = d1 * d2
    ans = fraction_to_str(num, den)
    return Question(
        prompt=f"{fraction_to_str(n1, d1)} − {fraction_to_str(n2, d2)} = ?",
        answer=ans,
        explanation=f"{fraction_to_str(n1, d1)} − {fraction_to_str(n2, d2)} = {ans}",
        difficulty=difficulty,
        metadata={"op": "frac_sub"},
    )


def generate_fraction_mul(difficulty: str = "medium") -> Question:
    max_den = {"easy": 6, "medium": 8, "hard": 12, "challenge": 16}.get(difficulty, 8)
    n1, d1 = _random_fraction(max_den)
    n2, d2 = _random_fraction(max_den)
    num = n1 * n2
    den = d1 * d2
    ans = fraction_to_str(num, den)
    return Question(
        prompt=f"{fraction_to_str(n1, d1)} × {fraction_to_str(n2, d2)} = ?",
        answer=ans,
        explanation=f"Multiply numerators and denominators, then simplify: {ans}",
        difficulty=difficulty,
        metadata={"op": "frac_mul"},
    )


def generate_fraction_div(difficulty: str = "medium") -> Question:
    max_den = {"easy": 6, "medium": 8, "hard": 12, "challenge": 16}.get(difficulty, 8)
    n1, d1 = _random_fraction(max_den)
    n2, d2 = _random_fraction(max_den)
    # a/b ÷ c/d = a/b × d/c
    num = n1 * d2
    den = d1 * n2
    ans = fraction_to_str(num, den)
    return Question(
        prompt=f"{fraction_to_str(n1, d1)} ÷ {fraction_to_str(n2, d2)} = ?",
        answer=ans,
        explanation=f"Multiply by the reciprocal: {fraction_to_str(n1, d1)} × {fraction_to_str(d2, n2)} = {ans}",
        difficulty=difficulty,
        metadata={"op": "frac_div"},
    )


def generate_simplify_fraction(difficulty: str = "medium") -> Question:
    max_val = {"easy": 12, "medium": 24, "hard": 48, "challenge": 100}.get(difficulty, 24)
    den = random.randint(2, max_val)
    num = random.randint(2, max_val)
    # Force a non-trivial common factor sometimes
    if random.random() < 0.7:
        g = random.randint(2, 6)
        num *= g
        den *= g
    ans = fraction_to_str(num, den)
    return Question(
        prompt=f"Simplify {num}/{den}",
        answer=ans,
        explanation=f"{num}/{den} = {ans}",
        difficulty=difficulty,
        metadata={"op": "simplify"},
    )


# Registry of all generators
FRACTION_GENERATORS = {
    "add": generate_addition,
    "sub": generate_subtraction,
    "mul": generate_multiplication,
    "div": generate_division,
    "frac_add": generate_fraction_add,
    "frac_sub": generate_fraction_sub,
    "frac_mul": generate_fraction_mul,
    "frac_div": generate_fraction_div,
    "simplify": generate_simplify_fraction,
}


def generate_arithmetic(topic: str, difficulty: str = "medium") -> Question:
    """Generate a question for a given arithmetic topic."""
    if topic not in FRACTION_GENERATORS:
        raise ValueError(f"Unknown topic '{topic}'. Available: {list(FRACTION_GENERATORS.keys())}")
    return FRACTION_GENERATORS[topic](difficulty)
