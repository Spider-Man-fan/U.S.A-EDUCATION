"""
Explore fractions and the four basic operations.

Demonstrates addition, subtraction, multiplication, and division
for both integers and fractions, plus simplification.
"""

import random
from edu31engine.arithmetic import (
    generate_arithmetic,
    FRACTION_GENERATORS,
    simplify_fraction,
    fraction_to_str,
)


def show_integer_operations():
    print("\n=== Integer Operations ===")
    topics = ["add", "sub", "mul", "div"]
    for topic in topics:
        print(f"\n{topic.upper()}:")
        for diff in ["easy", "medium", "hard"]:
            q = generate_arithmetic(topic, diff)
            print(f"  [{diff:8}] {q.prompt:20} → {q.answer}")


def show_fraction_operations():
    print("\n=== Fraction Operations ===")
    topics = ["frac_add", "frac_sub", "frac_mul", "frac_div", "simplify"]
    for topic in topics:
        print(f"\n{topic.upper()}:")
        for diff in ["easy", "medium"]:
            q = generate_arithmetic(topic, diff)
            print(f"  [{diff:8}] {q.prompt:30} → {q.answer}")
            print(f"             {q.explanation}")


def worked_examples():
    print("\n=== Worked Examples ===")
    
    examples = [
        ("3/4 + 1/6", "Find common denominator 12: 9/12 + 2/12 = 11/12"),
        ("5/6 − 1/3", "1/3 = 2/6, so 5/6 − 2/6 = 3/6 = 1/2"),
        ("2/3 × 3/4", "Multiply: 6/12 = 1/2"),
        ("3/5 ÷ 2/7", "Multiply by reciprocal: 3/5 × 7/2 = 21/10"),
        ("18/24", "Divide by 6: 3/4"),
    ]
    
    for problem, explanation in examples:
        print(f"  {problem}")
        print(f"    → {explanation}")


def main():
    print("=" * 60)
    print("Fractions & Basic Operations")
    print("=" * 60)
    
    show_integer_operations()
    show_fraction_operations()
    worked_examples()
    
    print("\n" + "=" * 60)
    print("Available topics:", list(FRACTION_GENERATORS.keys()))
    print("=" * 60)


if __name__ == "__main__":
    main()
