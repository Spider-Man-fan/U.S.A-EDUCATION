# Computational Math Toolkit

A collection of Python tools and examples for applied and computational mathematics.  
Topics include numerical integration, linear algebra, optimization, differential equations, statistics, and symbolic computation.

## Features

- Clean, modular code for common computational math tasks
- Examples that can be run standalone
- Built with NumPy, SciPy, SymPy, and Matplotlib
- Suitable as a starting point for research, teaching, or personal projects

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/math-computational-toolkit.git
cd math-computational-toolkit
pip install -r requirements.txt
```

## Quick Examples

### Numerical Integration

```python
from src.numerical_integration import integrate_simpson

def f(x):
    return x**2

result = integrate_simpson(f, 0, 1, n=100)
print(result)  # ≈ 0.3333
```

### Linear Algebra

```python
from src.linear_algebra import solve_system

A = [[2, 1], [1, 3]]
b = [5, 7]
solution = solve_system(A, b)
print(solution)
```

### Optimization

```python
from src.optimization import gradient_descent

def f(x):
    return x[0]**2 + x[1]**2

result = gradient_descent(f, [1.0, 1.0])
print(result)
```

## Project Structure

```
math-computational-toolkit/
├── src/                  # Core modules
├── examples/             # Runnable example scripts
├── tests/                # Unit tests
├── notebooks/            # Jupyter notebooks (add your own)
├── requirements.txt
├── README.md
└── LICENSE
```

## Contributing

Feel free to open issues or submit pull requests. See the examples for coding style.

## License

MIT License — see [LICENSE](LICENSE)
