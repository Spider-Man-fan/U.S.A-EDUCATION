"""
Optimization methods.
"""

import numpy as np
from scipy.optimize import minimize, minimize_scalar


def gradient_descent(f, x0, learning_rate=0.1, max_iter=1000, tol=1e-6):
    """
    Simple gradient descent using numerical gradients.
    
    Parameters
    ----------
    f : callable
        Objective function f(x) where x is array-like
    x0 : array_like
        Initial point
    learning_rate : float
        Step size
    max_iter : int
        Maximum iterations
    tol : float
        Convergence tolerance
        
    Returns
    -------
    dict
        Results with 'x', 'fun', 'n_iter'
    """
    x = np.asarray(x0, dtype=float)
    
    for i in range(max_iter):
        # Numerical gradient
        grad = numerical_gradient(f, x)
        
        # Update
        x_new = x - learning_rate * grad
        
        if np.linalg.norm(x_new - x) < tol:
            return {"x": x_new, "fun": f(x_new), "n_iter": i + 1}
            
        x = x_new
        
    return {"x": x, "fun": f(x), "n_iter": max_iter}


def numerical_gradient(f, x, eps=1e-8):
    """Compute numerical gradient of f at x."""
    x = np.asarray(x, dtype=float)
    grad = np.zeros_like(x)
    
    for i in range(len(x)):
        x_plus = x.copy()
        x_minus = x.copy()
        x_plus[i] += eps
        x_minus[i] -= eps
        grad[i] = (f(x_plus) - f(x_minus)) / (2 * eps)
        
    return grad


def minimize_function(f, x0, method="BFGS"):
    """
    Minimize function using SciPy.
    
    Parameters
    ----------
    f : callable
        Objective function
    x0 : array_like
        Initial guess
    method : str
        Optimization method
        
    Returns
    -------
    OptimizeResult
        SciPy optimization result
    """
    return minimize(f, x0, method=method)


def minimize_1d(f, bounds):
    """
    Minimize a 1D function within bounds.
    """
    return minimize_scalar(f, bounds=bounds, method="bounded")
