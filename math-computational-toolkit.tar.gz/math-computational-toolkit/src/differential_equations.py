"""
Ordinary differential equation solvers.
"""

import numpy as np
from scipy.integrate import solve_ivp


def solve_ode(f, y0, t_span, t_eval=None, method="RK45"):
    """
    Solve an ODE system y' = f(t, y).
    
    Parameters
    ----------
    f : callable
        Right-hand side function f(t, y)
    y0 : array_like
        Initial conditions
    t_span : tuple
        (t_start, t_end)
    t_eval : array_like, optional
        Times at which to store the solution
    method : str
        Integration method
        
    Returns
    -------
    OdeResult
        SciPy solution object
    """
    return solve_ivp(f, t_span, y0, t_eval=t_eval, method=method)


def harmonic_oscillator(omega=1.0):
    """
    Return the RHS for a simple harmonic oscillator: y'' + omega^2 y = 0.
    
    State vector is [y, y'].
    """
    def f(t, y):
        return [y[1], -omega**2 * y[0]]
    return f


def logistic_growth(r=1.0, K=1.0):
    """
    Logistic growth model: y' = r y (1 - y/K)
    """
    def f(t, y):
        return r * y[0] * (1 - y[0] / K)
    return f
