"""
Linear algebra utilities.
"""

import numpy as np
from scipy.linalg import solve, lu, qr, eig


def solve_system(A, b):
    """
    Solve the linear system Ax = b.
    
    Parameters
    ----------
    A : array_like
        Coefficient matrix
    b : array_like
        Right-hand side vector
        
    Returns
    -------
    ndarray
        Solution vector x
    """
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float)
    return solve(A, b)


def matrix_lu(A):
    """
    Compute LU decomposition of matrix A.
    
    Returns
    -------
    P, L, U : ndarrays
        Permutation, lower, and upper triangular matrices
    """
    A = np.asarray(A, dtype=float)
    return lu(A)


def matrix_qr(A):
    """
    Compute QR decomposition of matrix A.
    
    Returns
    -------
    Q, R : ndarrays
        Orthogonal and upper triangular matrices
    """
    A = np.asarray(A, dtype=float)
    return qr(A)


def eigenvalues(A):
    """
    Compute eigenvalues of matrix A.
    
    Returns
    -------
    ndarray
        Eigenvalues
    """
    A = np.asarray(A, dtype=float)
    return eig(A, right=False)


def condition_number(A):
    """
    Compute the condition number of matrix A.
    """
    A = np.asarray(A, dtype=float)
    return np.linalg.cond(A)
