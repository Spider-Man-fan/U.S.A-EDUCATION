"""
Statistical utilities.
"""

import numpy as np
from scipy import stats


def descriptive_stats(data):
    """
    Compute basic descriptive statistics.
    
    Returns
    -------
    dict
        mean, std, median, min, max, quartiles
    """
    data = np.asarray(data)
    return {
        "mean": np.mean(data),
        "std": np.std(data, ddof=1),
        "median": np.median(data),
        "min": np.min(data),
        "max": np.max(data),
        "q25": np.percentile(data, 25),
        "q75": np.percentile(data, 75),
    }


def linear_regression(x, y):
    """
    Simple linear regression y = a + b x.
    
    Returns
    -------
    dict
        slope, intercept, r_value, p_value, stderr
    """
    slope, intercept, r_value, p_value, stderr = stats.linregress(x, y)
    return {
        "slope": slope,
        "intercept": intercept,
        "r_value": r_value,
        "p_value": p_value,
        "stderr": stderr,
    }


def confidence_interval(data, confidence=0.95):
    """
    Compute confidence interval for the mean.
    """
    data = np.asarray(data)
    n = len(data)
    mean = np.mean(data)
    se = stats.sem(data)
    h = se * stats.t.ppf((1 + confidence) / 2, n - 1)
    return mean - h, mean + h
