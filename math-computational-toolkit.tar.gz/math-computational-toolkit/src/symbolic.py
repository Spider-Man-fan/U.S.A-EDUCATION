"""
Symbolic mathematics examples using SymPy.
"""

import sympy as sp


def differentiate(expr_str, var="x"):
    """
    Symbolically differentiate an expression.
    
    Parameters
    ----------
    expr_str : str
        Expression as string, e.g. "x**2 + 3*x"
    var : str
        Variable name
        
    Returns
    -------
    str
        Derivative as string
    """
    x = sp.symbols(var)
    expr = sp.sympify(expr_str)
    return str(sp.diff(expr, x))


def integrate_symbolic(expr_str, var="x"):
    """
    Symbolically integrate an expression.
    """
    x = sp.symbols(var)
    expr = sp.sympify(expr_str)
    return str(sp.integrate(expr, x))


def solve_equation(eq_str, var="x"):
    """
    Solve an equation for the given variable.
    eq_str should be like "x**2 - 4" (equals zero).
    """
    x = sp.symbols(var)
    expr = sp.sympify(eq_str)
    solutions = sp.solve(expr, x)
    return [str(s) for s in solutions]


def limit(expr_str, var="x", point=0):
    """
    Compute a limit.
    """
    x = sp.symbols(var)
    expr = sp.sympify(expr_str)
    return str(sp.limit(expr, x, point))
