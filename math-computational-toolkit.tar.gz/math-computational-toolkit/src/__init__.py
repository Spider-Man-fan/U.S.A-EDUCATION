"""Computational Math Toolkit source modules."""

from .numerical_integration import integrate_trapezoidal, integrate_simpson
from .linear_algebra import solve_system
from .optimization import gradient_descent
from .differential_equations import solve_ode
from .statistics import descriptive_stats
from .symbolic import differentiate, integrate_symbolic
