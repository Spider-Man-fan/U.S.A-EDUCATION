# Contributing

Contributions are welcome! This repository is a starting point for computational math tools.

## Ways to contribute

- Add new numerical methods or algorithms
- Improve existing implementations
- Add more examples and notebooks
- Write additional tests
- Improve documentation

## Development setup

```bash
pip install -e ".[dev]"
pytest
```

Please open an issue before large changes.
