"""
Example: Solving a simple harmonic oscillator ODE.
"""

import numpy as np
import matplotlib.pyplot as plt
import sys
sys.path.insert(0, "..")

from src.differential_equations import solve_ode, harmonic_oscillator


def main():
    # y'' + y = 0, y(0)=1, y'(0)=0  → solution is cos(t)
    f = harmonic_oscillator(omega=1.0)
    sol = solve_ode(f, y0=[1.0, 0.0], t_span=(0, 10), t_eval=np.linspace(0, 10, 200))
    
    print(f"Final position: {sol.y[0, -1]:.4f}")
    print(f"Final velocity: {sol.y[1, -1]:.4f}")
    
    # Uncomment to plot (requires matplotlib)
    # plt.plot(sol.t, sol.y[0], label="position")
    # plt.plot(sol.t, sol.y[1], label="velocity")
    # plt.legend()
    # plt.xlabel("time")
    # plt.title("Simple Harmonic Oscillator")
    # plt.grid(True)
    # plt.show()


if __name__ == "__main__":
    main()
