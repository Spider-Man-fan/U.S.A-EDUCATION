"""
Example: Numerical integration of various functions.
"""

import numpy as np
import sys
sys.path.insert(0, "..")

from src.numerical_integration import integrate_simpson, integrate_trapezoidal


def main():
    # Integrate x^2 from 0 to 1 (exact = 1/3)
    def f(x):
        return x**2
    
    trap = integrate_trapezoidal(f, 0, 1, n=100)
    simp = integrate_simpson(f, 0, 1, n=100)
    
    print(f"Trapezoidal: {trap:.6f}")
    print(f"Simpson:     {simp:.6f}")
    print(f"Exact:       {1/3:.6f}")
    
    # Integrate sin(x) from 0 to pi (exact = 2)
    def g(x):
        return np.sin(x)
    
    result = integrate_simpson(g, 0, np.pi, n=200)
    print(f"\nsin(x) from 0 to π: {result:.6f} (exact: 2.0)")


if __name__ == "__main__":
    main()
