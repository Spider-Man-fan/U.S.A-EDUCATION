"""
Example notebook-style script (run as .py or convert to notebook).
"""

# Run this file or copy into a Jupyter notebook

import numpy as np
import matplotlib.pyplot as plt

# Example: Plotting a function and its derivative approximation
x = np.linspace(-2, 2, 200)
y = np.exp(-x**2)  # Gaussian

# Numerical derivative
dy = np.gradient(y, x)

print("Created arrays for plotting.")
print(f"Max of y: {y.max():.4f}")
print(f"Max of |dy|: {np.abs(dy).max():.4f}")

# Uncomment to visualize
# plt.figure(figsize=(8, 4))
# plt.plot(x, y, label="f(x) = exp(-x²)")
# plt.plot(x, dy, label="f'(x) approx")
# plt.legend()
# plt.grid(True)
# plt.title("Gaussian and its derivative")
# plt.show()
