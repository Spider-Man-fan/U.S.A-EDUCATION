"""
Basic tests for the computational math toolkit.
"""

import numpy as np
import pytest
import sys
sys.path.insert(0, ".")

from src.numerical_integration import integrate_simpson
from src.linear_algebra import solve_system


def test_simpson_polynomial():
    """Simpson's rule should be exact for polynomials of degree ≤ 3."""
    def f(x):
        return x**3 + 2*x**2 - x + 1
    
    result = integrate_simpson(f, 0, 1, n=10)
    # Exact integral of x^3 + 2x^2 - x + 1 from 0 to 1
    exact = 1/4 + 2/3 - 1/2 + 1
    assert abs(result - exact) < 1e-10


def test_solve_system():
    A = [[2, 1], [1, 3]]
    b = [5, 7]
    x = solve_system(A, b)
    # Check residual
    residual = np.dot(A, x) - b
    assert np.allclose(residual, 0)
