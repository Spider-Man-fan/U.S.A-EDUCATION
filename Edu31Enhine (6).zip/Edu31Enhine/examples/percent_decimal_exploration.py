"""
Explore percentages and decimals.
"""

from edu31engine.arithmetic import generate_arithmetic, FRACTION_GENERATORS


def main():
    print("=" * 60)
    print("Percentages & Decimals")
    print("=" * 60)
    
    print("\n=== Percentages ===")
    for topic in ["percent_of", "what_percent", "percent_change"]:
        print(f"\n{topic}:")
        for diff in ["easy", "medium"]:
            q = generate_arithmetic(topic, diff)
            print(f"  [{diff:8}] {q.prompt}")
            print(f"             → {q.answer}")
    
    print("\n=== Decimals ===")
    for topic in ["dec_add", "dec_sub", "dec_mul", "dec_div"]:
        print(f"\n{topic}:")
        q = generate_arithmetic(topic, "medium")
        print(f"  {q.prompt} → {q.answer}")
    
    print("\n=== Conversions ===")
    for topic in ["dec_to_pct", "pct_to_dec"]:
        q = generate_arithmetic(topic, "medium")
        print(f"  {q.prompt} → {q.answer}")
        print(f"    {q.explanation}")
    
    print("\n" + "=" * 60)
    print("New topics added:", [k for k in FRACTION_GENERATORS if k.startswith(("percent", "dec", "pct"))])
    print("=" * 60)


if __name__ == "__main__":
    main()
