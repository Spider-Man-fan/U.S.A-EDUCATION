"""
Basic tests for the computational chemistry toolkit.
"""

import numpy as np
import sys
sys.path.insert(0, ".")

from src.kinetics import half_life_first_order, arrhenius
from src.thermodynamics import gibbs_free_energy, equilibrium_constant
from src.molecular import simple_molecular_weight


def test_half_life():
    k = 0.1
    t_half = half_life_first_order(k)
    assert abs(t_half - np.log(2)/k) < 1e-10


def test_gibbs():
    # Spontaneous reaction
    dG = gibbs_free_energy(dH=-10000, dS=50, T=300)
    assert dG < 0


def test_equilibrium_constant():
    K = equilibrium_constant(dG=-5000, T=298)
    assert K > 1


def test_molecular_weight_glucose():
    # C6H12O6
    mw = simple_molecular_weight({"C": 6, "H": 12, "O": 6})
    assert abs(mw - 180.156) < 0.1
