# Sample data directory

Place experimental data, molecular structures (.xyz, .pdb, .sdf), or parameter files here.

Example files you might add:
- reaction_rates.csv
- spectrum_data.txt
- molecule.xyz
