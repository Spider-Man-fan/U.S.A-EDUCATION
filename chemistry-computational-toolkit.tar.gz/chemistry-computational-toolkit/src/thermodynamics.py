"""
Thermodynamics utilities.
"""

import numpy as np


R = 8.314462618  # J/(mol·K)
R_cal = 1.987204258  # cal/(mol·K)


def gibbs_free_energy(dH, dS, T):
    """
    Compute Gibbs free energy change: ΔG = ΔH - TΔS
    
    Parameters
    ----------
    dH : float
        Enthalpy change (J/mol or consistent units)
    dS : float
        Entropy change (J/mol·K)
    T : float
        Temperature (K)
        
    Returns
    -------
    float
        ΔG
    """
    return dH - T * dS


def equilibrium_constant(dG, T, R=R):
    """
    Compute equilibrium constant from ΔG: K = exp(-ΔG / RT)
    
    Parameters
    ----------
    dG : float
        Gibbs free energy change (J/mol)
    T : float
        Temperature (K)
        
    Returns
    -------
    float
        Equilibrium constant K
    """
    return np.exp(-dG / (R * T))


def van_t_hoff(K1, T1, K2, T2):
    """
    Estimate ΔH from two K values using van 't Hoff equation
    (assuming ΔH constant).
    
    Returns
    -------
    float
        Estimated ΔH (J/mol)
    """
    return -R * np.log(K2 / K1) / (1/T2 - 1/T1)


def heat_capacity_temperature_dependence(Cp_a, Cp_b, Cp_c, T):
    """
    Simple polynomial heat capacity: Cp = a + bT + cT²
    Returns Cp at temperature T.
    """
    return Cp_a + Cp_b * T + Cp_c * T**2
