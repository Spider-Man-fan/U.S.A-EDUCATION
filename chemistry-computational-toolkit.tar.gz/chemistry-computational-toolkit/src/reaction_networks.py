"""
Reaction network and simple stoichiometric utilities.
"""

import numpy as np


def stoichiometric_matrix_example():
    """
    Example stoichiometric matrix for a simple reaction network.
    Reactions: A → B, B → C, A + B → D
    Species order: [A, B, C, D]
    """
    # Columns are reactions, rows are species
    S = np.array([
        [-1,  0, -1],  # A
        [ 1, -1, -1],  # B
        [ 0,  1,  0],  # C
        [ 0,  0,  1],  # D
    ])
    return S


def mass_balance_check(S, rates):
    """
    Check if mass is conserved for given rates (sum of stoichiometric coefficients weighted).
    Simple diagnostic.
    """
    # For each reaction, sum of stoich coeffs should be zero for atom balance
    # This is a placeholder — real systems need element-specific matrices
    return np.sum(S, axis=0)


def simple_rate_law(concentrations, rate_constants, orders):
    """
    Compute rates for elementary reactions: rate = k * prod(c_i ** order_i)
    
    Parameters
    ----------
    concentrations : array_like
    rate_constants : array_like
    orders : list of arrays
        Reaction orders for each species in each reaction
    """
    rates = []
    for k, order in zip(rate_constants, orders):
        rate = k
        for c, o in zip(concentrations, order):
            rate *= c ** o
        rates.append(rate)
    return np.array(rates)
