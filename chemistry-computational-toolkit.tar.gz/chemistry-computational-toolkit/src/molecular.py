"""
Simple molecular models and property estimators.
"""

import numpy as np


def ideal_gas_pressure(n, V, T, R=8.314):
    """
    Ideal gas law: P = nRT / V
    
    Parameters
    ----------
    n : float
        Moles
    V : float
        Volume (m³)
    T : float
        Temperature (K)
        
    Returns
    -------
    float
        Pressure (Pa)
    """
    return n * R * T / V


def reduced_mass(m1, m2):
    """
    Reduced mass for a diatomic molecule: μ = m1*m2 / (m1 + m2)
    
    Parameters
    ----------
    m1, m2 : float
        Masses of the two atoms
        
    Returns
    -------
    float
        Reduced mass
    """
    return (m1 * m2) / (m1 + m2)


def harmonic_oscillator_frequency(k, mu):
    """
    Vibrational frequency of a harmonic oscillator: ν = (1/(2π)) √(k/μ)
    
    Parameters
    ----------
    k : float
        Force constant
    mu : float
        Reduced mass
        
    Returns
    -------
    float
        Frequency
    """
    return (1 / (2 * np.pi)) * np.sqrt(k / mu)


def boltzmann_distribution(energies, T, kB=1.380649e-23):
    """
    Boltzmann population distribution.
    
    Parameters
    ----------
    energies : array_like
        Energy levels (J)
    T : float
        Temperature (K)
        
    Returns
    -------
    ndarray
        Normalized populations
    """
    energies = np.asarray(energies)
    beta = 1 / (kB * T)
    weights = np.exp(-beta * energies)
    return weights / np.sum(weights)


def simple_molecular_weight(formula_dict):
    """
    Approximate molecular weight from element counts.
    Uses common atomic weights.
    
    Parameters
    ----------
    formula_dict : dict
        e.g. {'C': 6, 'H': 12, 'O': 6}
        
    Returns
    -------
    float
        Molecular weight (g/mol)
    """
    atomic_weights = {
        'H': 1.008, 'C': 12.011, 'N': 14.007, 'O': 15.999,
        'F': 18.998, 'P': 30.974, 'S': 32.06, 'Cl': 35.45,
        'Br': 79.904, 'I': 126.90
    }
    return sum(atomic_weights.get(el, 0) * count for el, count in formula_dict.items())
