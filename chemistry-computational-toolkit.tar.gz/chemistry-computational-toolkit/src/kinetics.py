"""
Chemical kinetics utilities.
"""

import numpy as np
from scipy.integrate import solve_ivp


def solve_first_order(k, A0, t_span, t_eval=None):
    """
    Solve first-order kinetics: d[A]/dt = -k [A]
    
    Parameters
    ----------
    k : float
        Rate constant
    A0 : float
        Initial concentration
    t_span : tuple
        (t_start, t_end)
    t_eval : array_like, optional
        Times to evaluate
        
    Returns
    -------
    t, conc : ndarrays
        Time points and concentration of A
    """
    def rate(t, y):
        return -k * y[0]
    
    sol = solve_ivp(rate, t_span, [A0], t_eval=t_eval, dense_output=False)
    return sol.t, sol.y[0]


def solve_second_order(k, A0, B0, t_span, t_eval=None):
    """
    Solve second-order kinetics: A + B → products, d[A]/dt = -k [A][B]
    Assumes equal stoichiometry.
    """
    def rate(t, y):
        A, B = y
        rate_val = -k * A * B
        return [rate_val, rate_val]
    
    sol = solve_ivp(rate, t_span, [A0, B0], t_eval=t_eval)
    return sol.t, sol.y[0], sol.y[1]


def arrhenius(A, Ea, T, R=8.314):
    """
    Compute rate constant from Arrhenius equation: k = A exp(-Ea / RT)
    
    Parameters
    ----------
    A : float
        Pre-exponential factor
    Ea : float
        Activation energy (J/mol)
    T : float
        Temperature (K)
    R : float
        Gas constant (J/mol·K)
        
    Returns
    -------
    float
        Rate constant k
    """
    return A * np.exp(-Ea / (R * T))


def half_life_first_order(k):
    """Half-life for first-order reaction: t½ = ln(2)/k"""
    return np.log(2) / k
