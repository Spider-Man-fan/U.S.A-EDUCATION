"""
Spectroscopy simulation utilities.
"""

import numpy as np


def gaussian_lineshape(x, center, width, amplitude=1.0):
    """
    Gaussian line shape for spectral peaks.
    
    Parameters
    ----------
    x : array_like
        Frequency or wavelength axis
    center : float
        Peak center
    width : float
        Full width at half maximum (FWHM) related parameter
        (sigma = width / (2√(2ln2)))
    amplitude : float
        Peak height
        
    Returns
    -------
    ndarray
        Lineshape values
    """
    sigma = width / (2 * np.sqrt(2 * np.log(2)))
    return amplitude * np.exp(-0.5 * ((x - center) / sigma)**2)


def lorentzian_lineshape(x, center, width, amplitude=1.0):
    """
    Lorentzian line shape.
    
    Parameters
    ----------
    width : float
        Full width at half maximum (FWHM)
    """
    gamma = width / 2
    return amplitude * (gamma**2) / ((x - center)**2 + gamma**2)


def simulate_spectrum(x, peaks, lineshape="gaussian"):
    """
    Simulate a spectrum from multiple peaks.
    
    Parameters
    ----------
    x : array_like
        Axis values
    peaks : list of dict
        Each dict: {'center': ..., 'width': ..., 'amplitude': ...}
    lineshape : str
        'gaussian' or 'lorentzian'
        
    Returns
    -------
    ndarray
        Simulated spectrum
    """
    spectrum = np.zeros_like(x, dtype=float)
    func = gaussian_lineshape if lineshape == "gaussian" else lorentzian_lineshape
    
    for peak in peaks:
        spectrum += func(x, peak["center"], peak["width"], peak.get("amplitude", 1.0))
    
    return spectrum


def beer_lambert(absorbance, epsilon, path_length):
    """
    Concentration from Beer-Lambert law: A = ε c l → c = A / (ε l)
    
    Parameters
    ----------
    absorbance : float
    epsilon : float
        Molar absorptivity
    path_length : float
        Path length
        
    Returns
    -------
    float
        Concentration
    """
    return absorbance / (epsilon * path_length)
