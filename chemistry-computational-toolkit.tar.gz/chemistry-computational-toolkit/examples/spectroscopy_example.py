"""
Example: Simulating a simple IR-like spectrum with Gaussian peaks.
"""

import numpy as np
import sys
sys.path.insert(0, "..")

from src.spectroscopy import simulate_spectrum


def main():
    # Frequency axis (cm⁻¹)
    x = np.linspace(500, 4000, 1000)
    
    peaks = [
        {"center": 2900, "width": 50, "amplitude": 0.8},   # C-H stretch
        {"center": 1700, "width": 30, "amplitude": 1.0},   # C=O stretch
        {"center": 1450, "width": 40, "amplitude": 0.4},   # C-H bend
    ]
    
    spectrum = simulate_spectrum(x, peaks, lineshape="gaussian")
    
    print(f"Spectrum max absorbance: {spectrum.max():.3f}")
    print(f"Peak near 1700 cm⁻¹: {spectrum[np.argmin(np.abs(x - 1700))]:.3f}")
    
    # Uncomment to plot
    # import matplotlib.pyplot as plt
    # plt.plot(x, spectrum)
    # plt.xlabel("Wavenumber (cm⁻¹)")
    # plt.ylabel("Absorbance")
    # plt.title("Simulated Spectrum")
    # plt.gca().invert_xaxis()
    # plt.show()


if __name__ == "__main__":
    main()
