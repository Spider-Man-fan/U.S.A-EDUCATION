"""
Example: First-order chemical kinetics and half-life.
"""

import numpy as np
import sys
sys.path.insert(0, "..")

from src.kinetics import solve_first_order, half_life_first_order, arrhenius


def main():
    k = 0.05  # s⁻¹
    A0 = 2.0  # mol/L
    t, conc = solve_first_order(k, A0, t_span=(0, 100), t_eval=np.linspace(0, 100, 21))
    
    print("Time (s) | Concentration")
    for ti, ci in zip(t[::5], conc[::5]):
        print(f"{ti:6.1f}   | {ci:.4f}")
    
    t_half = half_life_first_order(k)
    print(f"\nHalf-life: {t_half:.2f} s")
    
    # Arrhenius example
    k_298 = arrhenius(A=1e13, Ea=80000, T=298)
    k_350 = arrhenius(A=1e13, Ea=80000, T=350)
    print(f"\nk(298 K) ≈ {k_298:.2e}")
    print(f"k(350 K) ≈ {k_350:.2e}")


if __name__ == "__main__":
    main()
