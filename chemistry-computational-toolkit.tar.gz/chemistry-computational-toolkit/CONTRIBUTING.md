# Contributing

Contributions are welcome! This repository is a starting point for computational chemistry tools.

## Ways to contribute

- Add new kinetic models or thermodynamic calculators
- Implement simple molecular dynamics or Monte Carlo routines
- Add cheminformatics helpers (with optional RDKit)
- Expand spectroscopy or spectroscopy fitting tools
- Add more examples and tests
- Improve documentation

## Development setup

```bash
pip install -e ".[dev]"
pytest
```

Please open an issue before large changes.

## Note

For production-grade computational chemistry, consider established libraries such as:
- RDKit (cheminformatics)
- ASE (atomic simulation environment)
- Psi4 / PySCF (quantum chemistry)
- OpenMM / MDAnalysis (molecular dynamics)
