# Contributing

Contributions are welcome! This repository is a starting point for computational physics tools.

## Ways to contribute

- Add more classical mechanics examples (rigid body, Lagrange mechanics, etc.)
- Expand quantum methods (time-dependent Schrödinger, scattering, etc.)
- Add fluid dynamics or plasma physics modules
- Implement Monte Carlo methods for statistical mechanics
- Add visualization helpers
- Write more tests and examples

## Development setup

```bash
pip install -e ".[dev]"
pytest
```

Please open an issue before large changes.
