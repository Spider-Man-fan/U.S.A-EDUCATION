"""
Basic tests for the computational physics toolkit.
"""

import numpy as np
import sys
sys.path.insert(0, ".")

from src.classical_mechanics import projectile_motion
from src.quantum import finite_difference_schrodinger, harmonic_oscillator_potential
from src.electromagnetism import coulomb_force


def test_projectile_symmetry():
    t, x, y = projectile_motion(20, 45, t_span=(0, 4), t_eval=np.linspace(0, 4, 200))
    # At 45 degrees, range should be roughly v²/g
    # Just check it goes up and comes down
    assert y.max() > 0
    assert y[-1] < y.max()


def test_harmonic_oscillator_energies():
    energies, _, _ = finite_difference_schrodinger(
        harmonic_oscillator_potential, -5, 5, n_points=150
    )
    # Ground state should be near 0.5
    assert abs(energies[0] - 0.5) < 0.05
    # First excited near 1.5
    assert abs(energies[1] - 1.5) < 0.1


def test_coulomb_force():
    F = coulomb_force(1e-6, 1e-6, 0.1)
    # Rough order of magnitude check
    assert F > 0
    assert F < 1e6
