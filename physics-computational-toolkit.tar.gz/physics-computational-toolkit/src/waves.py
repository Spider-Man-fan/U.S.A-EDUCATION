"""
Wave and Fourier analysis utilities.
"""

import numpy as np
from scipy.fft import fft, fftfreq, ifft


def wave_packet(x, x0, k0, sigma):
    """
    Gaussian wave packet.
    
    ψ(x) = exp(i k0 (x-x0)) * exp(-(x-x0)²/(2σ²))
    """
    return np.exp(1j * k0 * (x - x0)) * np.exp(-(x - x0)**2 / (2 * sigma**2))


def standing_wave(x, n, L, amplitude=1.0):
    """
    Standing wave on a string: y = A sin(n π x / L)
    """
    return amplitude * np.sin(n * np.pi * x / L)


def fourier_transform(signal, dt):
    """
    Compute the FFT of a signal and corresponding frequencies.
    
    Returns
    -------
    freqs, spectrum
    """
    n = len(signal)
    spectrum = fft(signal)
    freqs = fftfreq(n, dt)
    return freqs, spectrum


def power_spectrum(signal, dt):
    """
    Power spectral density (simple version).
    """
    freqs, spectrum = fourier_transform(signal, dt)
    power = np.abs(spectrum)**2
    # Return only positive frequencies
    pos = freqs > 0
    return freqs[pos], power[pos]
