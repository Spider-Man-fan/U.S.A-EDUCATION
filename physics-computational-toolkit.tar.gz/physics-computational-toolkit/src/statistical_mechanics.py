"""
Statistical mechanics utilities.
"""

import numpy as np


kB = 1.380649e-23  # J/K


def maxwell_boltzmann_speed(v, T, m):
    """
    Maxwell-Boltzmann speed distribution.
    
    f(v) = √(2/π) (m/(kT))^(3/2) v² exp(-m v² / (2 kT))
    
    Parameters
    ----------
    v : array_like
        Speeds
    T : float
        Temperature (K)
    m : float
        Particle mass (kg)
        
    Returns
    -------
    ndarray
        Probability density
    """
    v = np.asarray(v)
    a = m / (2 * kB * T)
    prefactor = np.sqrt(2/np.pi) * (m / (kB * T))**1.5
    return prefactor * v**2 * np.exp(-a * v**2)


def average_kinetic_energy(T, dof=3):
    """
    Average kinetic energy: (dof/2) kT
    """
    return (dof / 2) * kB * T


def partition_function_2level(E0, E1, T, g0=1, g1=1):
    """
    Partition function for a simple two-level system.
    Z = g0 exp(-β E0) + g1 exp(-β E1)
    """
    beta = 1 / (kB * T)
    return g0 * np.exp(-beta * E0) + g1 * np.exp(-beta * E1)


def fermi_dirac(E, mu, T):
    """
    Fermi-Dirac distribution: 1 / (exp((E-μ)/kT) + 1)
    """
    beta = 1 / (kB * T)
    return 1 / (np.exp(beta * (E - mu)) + 1)


def bose_einstein(E, mu, T):
    """
    Bose-Einstein distribution: 1 / (exp((E-μ)/kT) - 1)
    """
    beta = 1 / (kB * T)
    return 1 / (np.exp(beta * (E - mu)) - 1)
