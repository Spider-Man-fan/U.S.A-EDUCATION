"""
Basic quantum mechanics numerical methods.
"""

import numpy as np
from scipy.linalg import eigh


def finite_difference_schrodinger(potential, x_min, x_max, n_points=200, hbar=1.0, m=1.0):
    """
    Solve the 1D time-independent Schrödinger equation using finite differences.
    
    -ℏ²/2m ψ'' + V(x) ψ = E ψ
    
    Parameters
    ----------
    potential : callable
        V(x) function
    x_min, x_max : float
        Spatial domain
    n_points : int
        Number of grid points
    hbar, m : float
        Constants (set to 1 for atomic units style)
        
    Returns
    -------
    energies : ndarray
        Eigenvalues (energy levels)
    wavefunctions : ndarray
        Eigenvectors (columns are wavefunctions)
    x : ndarray
        Grid points
    """
    x = np.linspace(x_min, x_max, n_points)
    dx = x[1] - x[0]
    
    # Kinetic energy matrix (second derivative finite difference)
    # -ℏ²/(2m) * d²/dx²
    diag = np.ones(n_points) * 2
    off = np.ones(n_points - 1) * -1
    laplacian = (np.diag(diag) + np.diag(off, 1) + np.diag(off, -1)) / dx**2
    
    kinetic = (hbar**2 / (2 * m)) * laplacian
    
    # Potential matrix
    V = np.diag(potential(x))
    
    # Hamiltonian
    H = kinetic + V
    
    # Solve eigenvalue problem
    energies, wavefunctions = eigh(H)
    
    # Normalize wavefunctions
    for i in range(n_points):
        norm = np.sqrt(np.sum(wavefunctions[:, i]**2) * dx)
        if norm > 0:
            wavefunctions[:, i] /= norm
    
    return energies, wavefunctions, x


def harmonic_oscillator_potential(x, omega=1.0, m=1.0):
    """V(x) = (1/2) m ω² x²"""
    return 0.5 * m * omega**2 * x**2


def infinite_well_potential(x, L=1.0, height=1e6):
    """Approximate infinite well (high walls outside [0, L])"""
    return np.where((x >= 0) & (x <= L), 0.0, height)
