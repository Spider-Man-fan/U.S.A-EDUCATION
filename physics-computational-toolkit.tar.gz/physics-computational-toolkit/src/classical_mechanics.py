"""
Classical mechanics utilities.
"""

import numpy as np
from scipy.integrate import solve_ivp


def projectile_motion(v0, angle_deg, g=9.81, t_span=(0, 10), t_eval=None, y0=0):
    """
    2D projectile motion under constant gravity (no air resistance).
    
    Parameters
    ----------
    v0 : float
        Initial speed
    angle_deg : float
        Launch angle in degrees
    g : float
        Gravitational acceleration
    t_span : tuple
        Time span
    t_eval : array_like, optional
    y0 : float
        Initial height
        
    Returns
    -------
    t, x, y : ndarrays
    """
    angle = np.deg2rad(angle_deg)
    vx0 = v0 * np.cos(angle)
    vy0 = v0 * np.sin(angle)
    
    def equations(t, state):
        x, y, vx, vy = state
        return [vx, vy, 0, -g]
    
    sol = solve_ivp(equations, t_span, [0, y0, vx0, vy0], t_eval=t_eval)
    return sol.t, sol.y[0], sol.y[1]


def simple_harmonic_motion(omega, x0, v0, t_span, t_eval=None):
    """
    Simple harmonic oscillator: x'' + ω² x = 0
    """
    def equations(t, state):
        x, v = state
        return [v, -omega**2 * x]
    
    sol = solve_ivp(equations, t_span, [x0, v0], t_eval=t_eval)
    return sol.t, sol.y[0], sol.y[1]


def central_force_orbit(mu, r0, v_perp, t_span, t_eval=None):
    """
    Basic central force (inverse square) orbit integration in polar-like Cartesian form.
    For two-body reduced mass problem (μ = G(M+m) or k/m for Coulomb, etc.).
    """
    def equations(t, state):
        x, y, vx, vy = state
        r = np.sqrt(x**2 + y**2)
        ax = -mu * x / r**3
        ay = -mu * y / r**3
        return [vx, vy, ax, ay]
    
    # Initial conditions: start at (r0, 0) with perpendicular velocity
    sol = solve_ivp(equations, t_span, [r0, 0, 0, v_perp], t_eval=t_eval, rtol=1e-6)
    return sol.t, sol.y[0], sol.y[1]
