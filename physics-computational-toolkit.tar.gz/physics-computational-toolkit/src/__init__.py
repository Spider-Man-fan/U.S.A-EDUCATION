"""Computational Physics Toolkit source modules."""

from .classical_mechanics import projectile_motion, simple_harmonic_motion
from .quantum import finite_difference_schrodinger, harmonic_oscillator_potential
from .electromagnetism import coulomb_force, electric_field_point_charge
from .statistical_mechanics import maxwell_boltzmann_speed, fermi_dirac
from .waves import wave_packet, power_spectrum
