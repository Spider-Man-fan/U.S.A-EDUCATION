"""
Electromagnetism utilities.
"""

import numpy as np


def coulomb_force(q1, q2, r):
    """
    Coulomb force magnitude between two point charges.
    F = k |q1 q2| / r²  (sign determined separately)
    
    Parameters
    ----------
    q1, q2 : float
        Charges (Coulombs)
    r : float
        Separation (meters)
        
    Returns
    -------
    float
        Force magnitude (Newtons)
    """
    k = 8.9875517923e9  # N·m²/C²
    return k * abs(q1 * q2) / r**2


def electric_field_point_charge(q, r_vec, k=8.9875517923e9):
    """
    Electric field vector at position r_vec due to a point charge at origin.
    
    Parameters
    ----------
    q : float
        Charge
    r_vec : array_like
        Position vector
        
    Returns
    -------
    ndarray
        Electric field vector
    """
    r_vec = np.asarray(r_vec, dtype=float)
    r = np.linalg.norm(r_vec)
    if r == 0:
        return np.zeros_like(r_vec)
    return k * q * r_vec / r**3


def magnetic_field_wire(I, r, mu0=4*np.pi*1e-7):
    """
    Magnitude of magnetic field around a long straight wire.
    B = μ₀ I / (2π r)
    """
    return mu0 * I / (2 * np.pi * r)


def capacitor_energy(C, V):
    """Energy stored in a capacitor: (1/2) C V²"""
    return 0.5 * C * V**2


def inductor_energy(L, I):
    """Energy stored in an inductor: (1/2) L I²"""
    return 0.5 * L * I**2
