"""
Example: Projectile motion under gravity.
"""

import numpy as np
import sys
sys.path.insert(0, "..")

from src.classical_mechanics import projectile_motion


def main():
    v0 = 25.0  # m/s
    angle = 40  # degrees
    
    t, x, y = projectile_motion(v0, angle, t_span=(0, 5), t_eval=np.linspace(0, 5, 100))
    
    # Find approximate landing time and range
    landing_idx = np.where(y < 0)[0]
    if len(landing_idx) > 0:
        range_approx = x[landing_idx[0]]
        print(f"Approximate range: {range_approx:.2f} m")
    
    print(f"Maximum height: {y.max():.2f} m")
    print(f"Time of flight (approx): {t[np.argmax(y)] * 2:.2f} s")


if __name__ == "__main__":
    main()
