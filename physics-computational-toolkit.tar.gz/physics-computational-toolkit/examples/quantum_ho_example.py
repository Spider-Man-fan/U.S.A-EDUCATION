"""
Example: Finite-difference solution of the quantum harmonic oscillator.
"""

import numpy as np
import sys
sys.path.insert(0, "..")

from src.quantum import finite_difference_schrodinger, harmonic_oscillator_potential


def main():
    # Harmonic oscillator in units where ħ = m = ω = 1
    # Exact energies: E_n = n + 1/2
    
    energies, wavefunctions, x = finite_difference_schrodinger(
        potential=harmonic_oscillator_potential,
        x_min=-6,
        x_max=6,
        n_points=300
    )
    
    print("Lowest 5 energy levels (numerical):")
    for i in range(5):
        exact = i + 0.5
        print(f"  n={i}: E = {energies[i]:.4f}  (exact: {exact:.4f})")
    
    print(f"\nGround state peak near x=0: {wavefunctions[len(x)//2, 0]:.4f}")


if __name__ == "__main__":
    main()
