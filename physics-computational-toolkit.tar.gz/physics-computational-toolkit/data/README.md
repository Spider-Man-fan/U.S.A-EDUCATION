# Sample data directory

Place experimental data, simulation outputs, or parameter files here.

Example files you might add:
- trajectory_data.csv
- spectrum.dat
- initial_conditions.json
