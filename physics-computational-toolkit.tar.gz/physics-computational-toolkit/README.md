# Computational Physics Toolkit

A collection of Python tools and examples for applied and computational physics.  
Topics include classical mechanics, electromagnetism, quantum mechanics (basic numerical methods), statistical mechanics, waves, and common numerical techniques used in physics.

## Features

- Modular code for common computational physics tasks
- Numerical integration of equations of motion
- Basic quantum mechanics (finite difference Schrödinger equation, harmonic oscillator)
- Electrostatics and simple field calculations
- Statistical mechanics utilities
- Wave and Fourier analysis helpers
- Built with NumPy and SciPy
- Suitable as a starting point for teaching, research prototyping, or personal projects

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/physics-computational-toolkit.git
cd physics-computational-toolkit
pip install -r requirements.txt
```

## Quick Examples

### Classical Mechanics (Projectile Motion)

```python
from src.classical_mechanics import projectile_motion

t, x, y = projectile_motion(v0=20, angle_deg=45, t_span=(0, 5))
print(y.max())  # maximum height
```

### Quantum Harmonic Oscillator (Finite Difference)

```python
from src.quantum import finite_difference_schrodinger

energies, wavefunctions = finite_difference_schrodinger(
    potential=lambda x: 0.5 * x**2, x_min=-5, x_max=5, n_points=200
)
print(energies[:3])  # first few energy levels
```

## Project Structure

```
physics-computational-toolkit/
├── src/                  # Core modules
├── examples/             # Runnable example scripts
├── tests/                # Unit tests
├── notebooks/            # Jupyter notebooks (add your own)
├── data/                 # Sample data files
├── requirements.txt
├── README.md
└── LICENSE
```

## Contributing

Feel free to open issues or submit pull requests. See the examples for coding style.

## License

MIT License — see [LICENSE](LICENSE)

## Disclaimer

This is an educational/research prototyping toolkit. For production or high-accuracy physics simulations, use established packages and always validate results against analytical solutions or known benchmarks.
