# Edu31Enhine

**Edu31Enhine** is a computational mathematics engine for numerical methods, linear algebra, optimization, differential equations, statistics, symbolic computation, and **procedural question generation** for adaptive learning.

Designed as a clean, modular Python library suitable for education platforms, research prototyping, and application development.

## Features

### Numerical Methods
- Integration: Trapezoidal, Simpson’s, Gaussian, Monte Carlo
- Root finding: Newton-Raphson, Bisection
- ODE: SciPy solvers + classic 4th-order Runge-Kutta

### Linear Algebra
- Solve systems, eigenvalues, LU/QR, condition number
- Matrix inverse, determinant, power iteration, Gram-Schmidt

### Other
- Optimization (gradient descent + SciPy)
- Statistics (descriptive, regression, confidence intervals)
- Symbolic math (SymPy)

### Monte Carlo Integration
- Basic Monte Carlo
- Stratified sampling
- Quasi-Monte Carlo (Halton)
- Importance sampling framework
- Method comparison utilities

### Quasi-Monte Carlo / Low-Discrepancy Sequences
- Halton / Van der Corput (radical inverse)
- Kronecker (additive recurrence with golden ratio)
- Simplified 1D Sobol'
- Discrepancy estimation
- Hammersley point sets

### Question Generators (for adaptive practice)
Procedural generators with difficulty levels (`easy` / `medium` / `hard` / `challenge`):
- Addition, subtraction, multiplication, division
- Fraction simplification
- Linear equations
- Percentages

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/Edu31Enhine.git
cd Edu31Enhine
pip install -e .
```

For development:

```bash
pip install -e ".[dev]"
```

## Quick Examples

### Computational Math

```python
from edu31engine import integrate_simpson, newton_raphson, generate_question

def f(x):
    return x**2

print(integrate_simpson(f, 0, 1))

# Root finding
result = newton_raphson(lambda x: x**2 - 4, lambda x: 2*x, x0=1.0)
print(result["root"])  # ≈ 2.0
```

### Question Generation (adaptive practice)

```python
from edu31engine import generate_question

q = generate_question("equations", difficulty="medium")
print(q.prompt)      # e.g. "Solve for x: 4x = 28"
print(q.answer)      # 7
print(q.explanation)
```

## Project Structure

```
Edu31Enhine/
├── src/edu31engine/
│   ├── numerical.py
│   ├── numerical_extra.py      # Newton, bisection, Monte Carlo, RK4
│   ├── linear_algebra.py
│   ├── linear_algebra_extra.py
│   ├── optimization.py
│   ├── differential_equations.py
│   ├── statistics.py
│   ├── symbolic.py
│   └── question_generators.py  # Adaptive practice questions
├── examples/
├── tests/
├── pyproject.toml
└── README.md
```

## Running Demos

```bash
python examples/demo.py
python examples/question_generator_demo.py
```

## License

MIT License
