"""
Explore Quasi-Monte Carlo low-discrepancy sequences.

Compares how evenly different sequences fill [0,1] and how that
affects integration accuracy.
"""

import numpy as np
from edu31engine.low_discrepancy import (
    halton_sequence,
    kronecker_sequence,
    sobol_1d,
    discrepancy_estimate,
    generate_sequence,
)
from edu31engine.monte_carlo import monte_carlo_basic, monte_carlo_quasi


def integrate_with_points(f, points, a=0.0, b=1.0):
    """Integrate f using pre-generated points in [0,1], mapped to [a,b]."""
    x = a + (b - a) * points
    return (b - a) * np.mean(f(x))


def main():
    print("=" * 65)
    print("Quasi-Monte Carlo: Low-Discrepancy Sequences")
    print("=" * 65)
    
    n = 1000
    
    # ------------------------------------------------------------------
    # 1. Discrepancy comparison
    # ------------------------------------------------------------------
    print("\n1. Star-discrepancy estimate (lower = more uniform)")
    print("-" * 50)
    
    sequences = {
        "Random": generate_sequence("random", n, seed=42),
        "Halton (base 2)": halton_sequence(n, base=2),
        "Halton (base 3)": halton_sequence(n, base=3),
        "Kronecker (φ)": kronecker_sequence(n),
        "Sobol' (1D)": sobol_1d(n),
    }
    
    for name, pts in sequences.items():
        disc = discrepancy_estimate(pts)
        print(f"  {name:20}  discrepancy ≈ {disc:.5f}")
    
    # ------------------------------------------------------------------
    # 2. Integration accuracy: ∫₀¹ x² dx = 1/3
    # ------------------------------------------------------------------
    print("\n2. Integration error for ∫₀¹ x² dx  (exact = 0.333333)")
    print("-" * 50)
    
    def f(x):
        return x**2
    
    exact = 1/3
    ns = [100, 500, 2000, 10000]
    
    print(f"  {'N':>6}  {'Random':>10}  {'Halton':>10}  {'Kronecker':>10}  {'Sobol':>10}")
    
    for n in ns:
        rand_pts = generate_sequence("random", n, seed=42)
        halt_pts = halton_sequence(n)
        kron_pts = kronecker_sequence(n)
        sob_pts = sobol_1d(n)
        
        err_r = abs(integrate_with_points(f, rand_pts) - exact)
        err_h = abs(integrate_with_points(f, halt_pts) - exact)
        err_k = abs(integrate_with_points(f, kron_pts) - exact)
        err_s = abs(integrate_with_points(f, sob_pts) - exact)
        
        print(f"  {n:6d}  {err_r:10.2e}  {err_h:10.2e}  {err_k:10.2e}  {err_s:10.2e}")
    
    # ------------------------------------------------------------------
    # 3. Visual uniformity (first 20 points)
    # ------------------------------------------------------------------
    print("\n3. First 16 points of each sequence (notice clustering)")
    print("-" * 50)
    
    for name in ["Random", "Halton (base 2)", "Kronecker (φ)"]:
        pts = sequences[name][:16]
        formatted = " ".join(f"{p:.3f}" for p in pts)
        print(f"  {name:18}  {formatted}")
    
    # ------------------------------------------------------------------
    # 4. Higher-dimensional note
    # ------------------------------------------------------------------
    print("\n4. Higher dimensions")
    print("-" * 50)
    print("  In d dimensions, use a different prime base per coordinate")
    print("  for Halton, or use Sobol'/Niederreiter sequences.")
    print("  SciPy provides scipy.stats.qmc.Halton and .Sobol for production use.")
    
    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    print("\n" + "=" * 65)
    print("Summary:")
    print("  • Low-discrepancy sequences avoid the clusters and gaps of pure random.")
    print("  • Halton (radical inverse) is simple and effective in low dimensions.")
    print("  • Kronecker sequence with golden ratio is extremely cheap and strong in 1D.")
    print("  • Sobol' sequences are preferred for higher-dimensional QMC.")
    print("  • QMC often converges as O((log N)^d / N) vs O(1/√N) for plain MC.")
    print("=" * 65)


if __name__ == "__main__":
    main()
