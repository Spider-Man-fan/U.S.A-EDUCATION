"""
Explore Sobol' sequences.

Sobol' sequences are low-discrepancy sequences constructed using
direction numbers and Gray codes. They are often preferred over Halton
sequences in higher dimensions because they have better uniformity
properties and avoid the correlation problems that can appear in Halton
when many dimensions are used.
"""

import numpy as np
from edu31engine.low_discrepancy import (
    sobol_1d,
    halton_sequence,
    discrepancy_estimate,
)


def explain_construction():
    """Show how the first few 1D Sobol' points are built."""
    print("\n1D Sobol' construction (Gray code + powers of 1/2)")
    print("-" * 55)
    print(f"{'i':>4}  {'Gray code':>12}  {'point':>10}")
    print("-" * 55)
    
    for i in range(16):
        gray = i ^ (i >> 1)
        # Build the point
        val = 0.0
        bit = 0
        g = gray
        while g:
            if g & 1:
                val += 0.5 ** (bit + 1)
            g >>= 1
            bit += 1
        print(f"{i:4d}  {gray:12b}  {val:10.6f}")


def compare_discrepancy(n: int = 2000):
    """Compare 1D discrepancy of Sobol', Halton, and random."""
    print(f"\n1D discrepancy comparison (N = {n})")
    print("-" * 40)
    
    sob = sobol_1d(n)
    halt = halton_sequence(n, base=2)
    rng = np.random.default_rng(42)
    rand = rng.random(n)
    
    print(f"  Sobol'     {discrepancy_estimate(sob):.5f}")
    print(f"  Halton b2  {discrepancy_estimate(halt):.5f}")
    print(f"  Random     {discrepancy_estimate(rand):.5f}")


def integration_1d(n_values=None):
    """Integration error for ∫₀¹ x² dx = 1/3."""
    if n_values is None:
        n_values = [100, 500, 2000, 10000]
    
    def f(x):
        return x**2
    exact = 1/3
    
    print("\nIntegration error: ∫₀¹ x² dx  (exact = 0.333333)")
    print("-" * 55)
    print(f"{'N':>6}  {'Random':>12}  {'Halton':>12}  {'Sobol':>12}")
    
    rng = np.random.default_rng(42)
    for n in n_values:
        err_r = abs(np.mean(f(rng.random(n))) - exact)
        err_h = abs(np.mean(f(halton_sequence(n))) - exact)
        err_s = abs(np.mean(f(sobol_1d(n))) - exact)
        print(f"{n:6d}  {err_r:12.2e}  {err_h:12.2e}  {err_s:12.2e}")


def first_points():
    """Show the beginning of the sequence."""
    pts = sobol_1d(24)
    print("\nFirst 24 Sobol' points (1D):")
    print(" ".join(f"{p:.3f}" for p in pts))


def higher_dimensions_note():
    print("""
Higher dimensions:
  A full multi-dimensional Sobol' sequence requires a set of
  direction numbers for each dimension. These are carefully chosen
  so that the sequence has excellent uniformity in all projections.

  Production implementations (e.g. scipy.stats.qmc.Sobol) use
  precomputed direction numbers and are recommended for real work.

  Advantages over Halton in high dimensions:
    • Better equidistribution properties
    • Less correlation between coordinates
    • Often faster convergence for integration
""")


def main():
    print("=" * 60)
    print("Sobol' Sequences")
    print("=" * 60)
    print("""
Sobol' sequences are generated using:
  1. Direction numbers (special binary fractions)
  2. Gray code ordering of the index
  3. XOR operations (in the binary representation)

They are among the most widely used low-discrepancy sequences
in quasi-Monte Carlo methods.
""")
    
    explain_construction()
    first_points()
    compare_discrepancy()
    integration_1d()
    higher_dimensions_note()
    
    print("=" * 60)
    print("Summary:")
    print("  • Excellent uniformity (very low discrepancy)")
    print("  • Preferred over Halton in moderate-to-high dimensions")
    print("  • 1D version is simple; multi-D needs direction numbers")
    print("  • Use scipy.stats.qmc.Sobol for production multi-D work")
    print("=" * 60)


if __name__ == "__main__":
    main()
