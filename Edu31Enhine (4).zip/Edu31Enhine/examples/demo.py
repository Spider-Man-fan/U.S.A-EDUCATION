"""
Example usage of Edu31Enhine.
"""

import numpy as np
from edu31engine.numerical import integrate_simpson, integrate_trapezoidal
from edu31engine.linear_algebra import solve_system, eigenvalues
from edu31engine.optimization import gradient_descent
from edu31engine.symbolic import differentiate, solve_equation


def main():
    print("=== Edu31Enhine Demo ===\n")

    # Numerical integration
    def f(x):
        return x**2

    print("Integration of x² from 0 to 1:")
    print(f"  Simpson:     {integrate_simpson(f, 0, 1, n=100):.6f}")
    print(f"  Trapezoidal: {integrate_trapezoidal(f, 0, 1, n=100):.6f}")
    print(f"  Exact:       {1/3:.6f}\n")

    # Linear algebra
    A = [[2, 1], [1, 3]]
    b = [5, 7]
    print("Solving Ax = b:")
    print(f"  Solution: {solve_system(A, b)}\n")

    # Optimization
    def obj(x):
        return x[0]**2 + x[1]**2

    result = gradient_descent(obj, [1.0, 1.0])
    print(f"Gradient descent minimum: {result['x']} (fun={result['fun']:.6f})\n")

    # Symbolic
    print("Symbolic:")
    print(f"  d/dx (x³ + 2x) = {differentiate('x**3 + 2*x')}")
    print(f"  Solutions to x² - 4 = 0: {solve_equation('x**2 - 4')}")


if __name__ == "__main__":
    main()
