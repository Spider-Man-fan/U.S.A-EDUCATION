"""
Explore Halton sequences.

Halton sequences are the multi-dimensional generalization of the
Van der Corput sequence. Each coordinate uses a different prime base
for the radical-inverse function.
"""

import numpy as np
from edu31engine.low_discrepancy import (
    radical_inverse,
    halton_sequence,
    halton_sequence_nd,
    discrepancy_estimate,
)


def show_first_points_2d(n: int = 12):
    """Display the first n points of a 2D Halton sequence."""
    pts = halton_sequence_nd(n, dim=2)
    print(f"\nFirst {n} points of 2D Halton sequence")
    print("(x = base 2, y = base 3)")
    print("-" * 40)
    print(f"{'i':>4}  {'x (base 2)':>12}  {'y (base 3)':>12}")
    for i, (x, y) in enumerate(pts, start=1):
        print(f"{i:4d}  {x:12.6f}  {y:12.6f}")


def compare_uniformity_2d(n: int = 500):
    """Rough comparison of 2D uniformity: Halton vs random."""
    print(f"\n2D uniformity check (N = {n})")
    print("-" * 45)
    
    # Halton
    h = halton_sequence_nd(n, dim=2)
    # Simple grid occupancy (10×10 cells)
    def occupancy(pts):
        grid = np.zeros((10, 10), dtype=int)
        for x, y in pts:
            ix = min(int(x * 10), 9)
            iy = min(int(y * 10), 9)
            grid[iy, ix] += 1
        return grid
    
    h_grid = occupancy(h)
    rng = np.random.default_rng(42)
    r = rng.random((n, 2))
    r_grid = occupancy(r)
    
    print(f"  Halton  — empty cells: {np.sum(h_grid == 0):2d}/100, "
          f"max per cell: {h_grid.max()}")
    print(f"  Random  — empty cells: {np.sum(r_grid == 0):2d}/100, "
          f"max per cell: {r_grid.max()}")


def integration_2d(n_values=None):
    """
    Integrate f(x,y) = x*y over [0,1]².
    Exact value = 1/4.
    """
    if n_values is None:
        n_values = [100, 500, 2000, 8000]
    
    exact = 0.25
    print("\n2D Integration: ∫∫ x·y dx dy over [0,1]²  (exact = 0.25)")
    print("-" * 55)
    print(f"{'N':>6}  {'Random':>12}  {'Halton':>12}")
    
    rng = np.random.default_rng(42)
    for n in n_values:
        # Random
        pts_r = rng.random((n, 2))
        est_r = np.mean(pts_r[:, 0] * pts_r[:, 1])
        err_r = abs(est_r - exact)
        
        # Halton
        pts_h = halton_sequence_nd(n, dim=2)
        est_h = np.mean(pts_h[:, 0] * pts_h[:, 1])
        err_h = abs(est_h - exact)
        
        print(f"{n:6d}  {err_r:12.2e}  {err_h:12.2e}")


def projection_note():
    """Explain the projection property."""
    print("""
Projection property:
  Any lower-dimensional projection of a Halton sequence is itself
  a Halton sequence (in the corresponding bases). This is why Halton
  works well for integration even when only a subset of variables
  are important.
""")


def main():
    print("=" * 60)
    print("Halton Sequences")
    print("=" * 60)
    print("""
A Halton sequence in d dimensions is built by taking the radical
inverse in a different prime base for each coordinate:

  Dimension 1 → base 2
  Dimension 2 → base 3
  Dimension 3 → base 5
  Dimension 4 → base 7
  ...

In 1D, Halton reduces exactly to the Van der Corput sequence.
""")
    
    show_first_points_2d(n=16)
    compare_uniformity_2d(n=1000)
    integration_2d()
    projection_note()
    
    print("=" * 60)
    print("Key points:")
    print("  • Each dimension uses a distinct prime base")
    print("  • Points are more evenly distributed than pure random")
    print("  • Works well up to roughly 10–20 dimensions")
    print("  • In very high dimensions, Sobol' sequences are often preferred")
    print("  • SciPy: scipy.stats.qmc.Halton for production use")
    print("=" * 60)


if __name__ == "__main__":
    main()
