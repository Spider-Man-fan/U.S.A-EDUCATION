"""
Explore Monte Carlo integration methods.

Compares basic, stratified, and quasi-Monte Carlo on classic integrals.
"""

import numpy as np
from edu31engine.monte_carlo import (
    monte_carlo_basic,
    monte_carlo_stratified,
    monte_carlo_quasi,
    compare_methods,
)


def main():
    print("=" * 60)
    print("Monte Carlo Integration Exploration")
    print("=" * 60)
    
    # ------------------------------------------------------------------
    # Example 1: ∫₀¹ x² dx = 1/3
    # ------------------------------------------------------------------
    print("\n1. Integral of x² from 0 to 1 (exact = 1/3 ≈ 0.333333)")
    print("-" * 50)
    
    def f1(x):
        return x**2
    
    results = compare_methods(f1, 0, 1, exact=1/3, n=10000, seed=42)
    
    for method, res in results.items():
        err = res.get("error", float("nan"))
        se = res.get("std_error", "—")
        print(f"  {method:12}  estimate={res['estimate']:.6f}  "
              f"error={err:.2e}  std_err={se}")
    
    # ------------------------------------------------------------------
    # Example 2: ∫₀^π sin(x) dx = 2
    # ------------------------------------------------------------------
    print("\n2. Integral of sin(x) from 0 to π (exact = 2)")
    print("-" * 50)
    
    def f2(x):
        return np.sin(x)
    
    results2 = compare_methods(f2, 0, np.pi, exact=2.0, n=20000, seed=123)
    
    for method, res in results2.items():
        err = res.get("error", float("nan"))
        print(f"  {method:12}  estimate={res['estimate']:.6f}  error={err:.2e}")
    
    # ------------------------------------------------------------------
    # Example 3: Convergence study (basic MC)
    # ------------------------------------------------------------------
    print("\n3. Convergence of basic Monte Carlo (∫ x² dx)")
    print("-" * 50)
    print(f"  {'N':>8}  {'Estimate':>12}  {'Error':>12}  {'1/√N rate':>12}")
    
    exact = 1/3
    for n in [100, 1000, 10000, 100000]:
        res = monte_carlo_basic(f1, 0, 1, n=n, seed=42)
        err = abs(res["estimate"] - exact)
        rate = 1 / np.sqrt(n)
        print(f"  {n:8d}  {res['estimate']:12.6f}  {err:12.2e}  {rate:12.2e}")
    
    # ------------------------------------------------------------------
    # Example 4: Importance sampling illustration
    # ------------------------------------------------------------------
    print("\n4. Importance sampling idea")
    print("-" * 50)
    print("  For peaked functions, sampling more where the function is large")
    print("  reduces variance. Example: integrate exp(-x²) near zero.")
    print("  (See monte_carlo_importance in the module for the implementation.)")
    
    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("Key takeaways:")
    print("  • Basic MC error ~ 1/√N")
    print("  • Stratified sampling reduces variance for smooth functions")
    print("  • Quasi-MC (low-discrepancy) can converge faster in low dimensions")
    print("  • Importance sampling helps when the integrand is concentrated")
    print("  • MC shines in high dimensions where grid methods fail")
    print("=" * 60)


if __name__ == "__main__":
    main()
