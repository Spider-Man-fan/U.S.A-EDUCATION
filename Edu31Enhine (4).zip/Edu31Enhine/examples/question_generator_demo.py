"""
Demo of question generators for adaptive practice.
"""

from edu31engine.question_generators import generate_question, GENERATORS


def main():
    print("=== Edu31Enhine Question Generators ===\n")
    
    topics = ["addition", "multiplication", "fractions", "equations", "percentage"]
    difficulties = ["easy", "medium", "hard"]
    
    for topic in topics:
        print(f"--- {topic.upper()} ---")
        for diff in difficulties:
            q = generate_question(topic, diff)
            print(f"  [{diff:8}] {q.prompt}")
            print(f"           Answer: {q.answer}")
        print()
    
    print(f"Available topics: {list(GENERATORS.keys())}")


if __name__ == "__main__":
    main()
