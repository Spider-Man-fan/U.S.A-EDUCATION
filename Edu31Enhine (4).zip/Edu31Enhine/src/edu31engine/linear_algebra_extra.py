"""
Additional linear algebra and matrix algorithms.
"""

import numpy as np


def matrix_multiply(A, B):
    """Matrix multiplication."""
    return np.dot(np.asarray(A, dtype=float), np.asarray(B, dtype=float))


def matrix_inverse(A):
    """Compute matrix inverse. Raises if singular."""
    return np.linalg.inv(np.asarray(A, dtype=float))


def determinant(A):
    """Compute determinant."""
    return float(np.linalg.det(np.asarray(A, dtype=float)))


def power_iteration(A, num_iterations=100, tol=1e-8):
    """
    Power iteration to estimate the dominant eigenvalue and eigenvector.
    """
    A = np.asarray(A, dtype=float)
    n = A.shape[0]
    b = np.random.rand(n)
    b = b / np.linalg.norm(b)
    
    for _ in range(num_iterations):
        b_next = A @ b
        b_next = b_next / np.linalg.norm(b_next)
        if np.linalg.norm(b_next - b) < tol:
            break
        b = b_next
    
    eigenvalue = float(b.T @ A @ b)
    return {"eigenvalue": eigenvalue, "eigenvector": b}


def gram_schmidt(vectors):
    """
    Gram-Schmidt orthogonalization.
    vectors: list of arrays or 2D array (columns are vectors).
    """
    V = np.asarray(vectors, dtype=float).T  # columns are vectors
    n, k = V.shape
    U = np.zeros_like(V)
    
    for i in range(k):
        u = V[:, i].copy()
        for j in range(i):
            u -= np.dot(U[:, j], V[:, i]) * U[:, j]
        norm = np.linalg.norm(u)
        if norm > 1e-10:
            U[:, i] = u / norm
    return U.T  # return as rows for convenience
