"""
Ordinary differential equation solvers.
"""

import numpy as np
from scipy.integrate import solve_ivp


def solve_ode(f, y0, t_span, t_eval=None, method="RK45"):
    """Solve ODE system y' = f(t, y)."""
    return solve_ivp(f, t_span, y0, t_eval=t_eval, method=method)


def harmonic_oscillator(omega=1.0):
    """RHS for y'' + omega² y = 0. State = [y, y']."""
    def f(t, y):
        return [y[1], -omega**2 * y[0]]
    return f


def logistic_growth(r=1.0, K=1.0):
    """Logistic growth: y' = r y (1 - y/K)."""
    def f(t, y):
        return [r * y[0] * (1 - y[0] / K)]
    return f
