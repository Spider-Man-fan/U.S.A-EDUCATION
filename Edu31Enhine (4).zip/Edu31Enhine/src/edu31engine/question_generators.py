"""
Question generators for adaptive math practice.
Produces procedural questions with controlled difficulty.
"""

import random
import math
from typing import Dict, Any, List, Optional


class Question:
    def __init__(self, prompt: str, answer: Any, choices: Optional[List[str]] = None,
                 explanation: str = "", difficulty: str = "medium", metadata: Dict = None):
        self.prompt = prompt
        self.answer = answer
        self.choices = choices
        self.explanation = explanation
        self.difficulty = difficulty
        self.metadata = metadata or {}

    def to_dict(self) -> Dict:
        return {
            "prompt": self.prompt,
            "answer": self.answer,
            "choices": self.choices,
            "explanation": self.explanation,
            "difficulty": self.difficulty,
            "metadata": self.metadata,
        }


def generate_addition(difficulty: str = "medium") -> Question:
    """Generate an addition question."""
    ranges = {
        "easy": (1, 10),
        "medium": (10, 50),
        "hard": (50, 200),
        "challenge": (100, 1000),
    }
    low, high = ranges.get(difficulty, (1, 20))
    a = random.randint(low, high)
    b = random.randint(low, high)
    answer = a + b
    return Question(
        prompt=f"What is {a} + {b}?",
        answer=answer,
        explanation=f"{a} + {b} = {answer}",
        difficulty=difficulty,
        metadata={"operation": "addition", "operands": [a, b]},
    )


def generate_subtraction(difficulty: str = "medium") -> Question:
    ranges = {
        "easy": (1, 10),
        "medium": (10, 50),
        "hard": (50, 200),
        "challenge": (100, 1000),
    }
    low, high = ranges.get(difficulty, (1, 20))
    a = random.randint(low + 5, high + 10)
    b = random.randint(low, a - 1)
    answer = a - b
    return Question(
        prompt=f"What is {a} − {b}?",
        answer=answer,
        explanation=f"{a} − {b} = {answer}",
        difficulty=difficulty,
        metadata={"operation": "subtraction", "operands": [a, b]},
    )


def generate_multiplication(difficulty: str = "medium") -> Question:
    ranges = {
        "easy": (1, 5),
        "medium": (2, 10),
        "hard": (5, 15),
        "challenge": (10, 25),
    }
    low, high = ranges.get(difficulty, (2, 9))
    a = random.randint(low, high)
    b = random.randint(low, high)
    answer = a * b
    return Question(
        prompt=f"What is {a} × {b}?",
        answer=answer,
        explanation=f"{a} × {b} = {answer}",
        difficulty=difficulty,
        metadata={"operation": "multiplication", "operands": [a, b]},
    )


def generate_division(difficulty: str = "medium") -> Question:
    """Generate a clean division problem (no remainder)."""
    ranges = {
        "easy": (2, 5),
        "medium": (2, 10),
        "hard": (3, 12),
        "challenge": (5, 20),
    }
    low, high = ranges.get(difficulty, (2, 9))
    b = random.randint(low, high)
    quotient = random.randint(low, high)
    a = b * quotient
    return Question(
        prompt=f"What is {a} ÷ {b}?",
        answer=quotient,
        explanation=f"{a} ÷ {b} = {quotient}",
        difficulty=difficulty,
        metadata={"operation": "division", "operands": [a, b]},
    )


def generate_fraction_simplify(difficulty: str = "medium") -> Question:
    """Generate a fraction to simplify."""
    def gcd(a, b):
        while b:
            a, b = b, a % b
        return a
    
    ranges = {
        "easy": (2, 6),
        "medium": (3, 12),
        "hard": (5, 20),
        "challenge": (8, 30),
    }
    low, high = ranges.get(difficulty, (2, 10))
    num = random.randint(low, high)
    den = random.randint(low, high)
    g = gcd(num, den)
    simplified_num = num // g
    simplified_den = den // g
    answer = f"{simplified_num}/{simplified_den}" if simplified_den != 1 else str(simplified_num)
    return Question(
        prompt=f"Simplify the fraction {num}/{den}.",
        answer=answer,
        explanation=f"{num}/{den} = {answer} (divided numerator and denominator by {g})",
        difficulty=difficulty,
        metadata={"original": [num, den], "gcd": g},
    )


def generate_linear_equation(difficulty: str = "medium") -> Question:
    """Generate a one-step or two-step linear equation."""
    if difficulty == "easy":
        # x + a = b
        a = random.randint(1, 10)
        x = random.randint(1, 15)
        b = x + a
        prompt = f"Solve for x: x + {a} = {b}"
        answer = x
        explanation = f"x = {b} − {a} = {x}"
    elif difficulty == "medium":
        # ax = b
        a = random.randint(2, 8)
        x = random.randint(1, 12)
        b = a * x
        prompt = f"Solve for x: {a}x = {b}"
        answer = x
        explanation = f"x = {b} ÷ {a} = {x}"
    else:
        # ax + b = c
        a = random.randint(2, 6)
        b = random.randint(1, 10)
        x = random.randint(1, 10)
        c = a * x + b
        prompt = f"Solve for x: {a}x + {b} = {c}"
        answer = x
        explanation = f"{a}x = {c} − {b} = {c-b}, so x = {(c-b)//a}"
    
    return Question(
        prompt=prompt,
        answer=answer,
        explanation=explanation,
        difficulty=difficulty,
        metadata={"equation_type": "linear"},
    )


def generate_percentage(difficulty: str = "medium") -> Question:
    """Generate a percentage question."""
    if difficulty == "easy":
        percent = random.choice([10, 20, 25, 50])
        number = random.choice([10, 20, 40, 50, 100])
    else:
        percent = random.randint(5, 80)
        number = random.randint(20, 200)
    answer = round(number * percent / 100, 2)
    # Prefer integer answers when possible
    if answer == int(answer):
        answer = int(answer)
    return Question(
        prompt=f"What is {percent}% of {number}?",
        answer=answer,
        explanation=f"{percent}% of {number} = {number} × {percent}/100 = {answer}",
        difficulty=difficulty,
        metadata={"percent": percent, "number": number},
    )


# Registry of generators by topic
GENERATORS = {
    "addition": generate_addition,
    "subtraction": generate_subtraction,
    "multiplication": generate_multiplication,
    "division": generate_division,
    "fractions": generate_fraction_simplify,
    "equations": generate_linear_equation,
    "percentage": generate_percentage,
}


def generate_question(topic: str, difficulty: str = "medium") -> Question:
    """Generate a question for a given topic and difficulty."""
    if topic not in GENERATORS:
        raise ValueError(f"Unknown topic: {topic}. Available: {list(GENERATORS.keys())}")
    return GENERATORS[topic](difficulty)
