"""
Statistical utilities.
"""

import numpy as np
from scipy import stats


def descriptive_stats(data):
    """Basic descriptive statistics."""
    data = np.asarray(data)
    return {
        "mean": float(np.mean(data)),
        "std": float(np.std(data, ddof=1)),
        "median": float(np.median(data)),
        "min": float(np.min(data)),
        "max": float(np.max(data)),
        "q25": float(np.percentile(data, 25)),
        "q75": float(np.percentile(data, 75)),
    }


def linear_regression(x, y):
    """Simple linear regression."""
    slope, intercept, r_value, p_value, stderr = stats.linregress(x, y)
    return {
        "slope": slope,
        "intercept": intercept,
        "r_value": r_value,
        "p_value": p_value,
        "stderr": stderr,
    }


def confidence_interval(data, confidence=0.95):
    """Confidence interval for the mean."""
    data = np.asarray(data)
    n = len(data)
    mean = np.mean(data)
    se = stats.sem(data)
    h = se * stats.t.ppf((1 + confidence) / 2, n - 1)
    return float(mean - h), float(mean + h)
