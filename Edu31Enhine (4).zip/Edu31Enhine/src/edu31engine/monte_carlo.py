"""
Monte Carlo integration methods.

Monte Carlo integration estimates integrals by random sampling.
The basic idea: ∫_a^b f(x) dx ≈ (b-a) * average of f at random points.

Error typically decreases as 1/√N (slower than deterministic methods,
but scales better to high dimensions).
"""

import numpy as np
from typing import Callable, Tuple, Optional, Dict


def monte_carlo_basic(
    f: Callable,
    a: float,
    b: float,
    n: int = 10000,
    seed: Optional[int] = None,
) -> Dict:
    """
    Basic Monte Carlo integration.
    
    Estimate = (b - a) * mean(f(x_i)) where x_i ~ Uniform(a, b)
    
    Returns
    -------
    dict with estimate, std_error, samples
    """
    rng = np.random.default_rng(seed)
    x = rng.uniform(a, b, n)
    fx = f(x)
    estimate = (b - a) * np.mean(fx)
    # Standard error of the mean
    std_error = (b - a) * np.std(fx, ddof=1) / np.sqrt(n)
    return {
        "estimate": float(estimate),
        "std_error": float(std_error),
        "n": n,
        "method": "basic",
    }


def monte_carlo_stratified(
    f: Callable,
    a: float,
    b: float,
    n_strata: int = 10,
    n_per_stratum: int = 1000,
    seed: Optional[int] = None,
) -> Dict:
    """
    Stratified Monte Carlo: divide [a,b] into equal strata and sample
    uniformly within each. Reduces variance when f varies smoothly.
    """
    rng = np.random.default_rng(seed)
    edges = np.linspace(a, b, n_strata + 1)
    estimates = []
    variances = []
    
    for i in range(n_strata):
        left, right = edges[i], edges[i + 1]
        x = rng.uniform(left, right, n_per_stratum)
        fx = f(x)
        estimates.append((right - left) * np.mean(fx))
        variances.append(((right - left) ** 2) * np.var(fx, ddof=1) / n_per_stratum)
    
    estimate = np.sum(estimates)
    std_error = np.sqrt(np.sum(variances))
    return {
        "estimate": float(estimate),
        "std_error": float(std_error),
        "n": n_strata * n_per_stratum,
        "n_strata": n_strata,
        "method": "stratified",
    }


def monte_carlo_importance(
    f: Callable,
    a: float,
    b: float,
    proposal_pdf: Callable,
    proposal_sample: Callable,
    n: int = 10000,
    seed: Optional[int] = None,
) -> Dict:
    """
    Importance sampling Monte Carlo.
    
    Sample from a proposal distribution q(x) instead of uniform,
    then weight by f(x)/q(x).
    
    Parameters
    ----------
    proposal_pdf : callable
        q(x) — density of the proposal
    proposal_sample : callable
        Function that returns n samples from q (takes rng and n)
    """
    rng = np.random.default_rng(seed)
    x = proposal_sample(rng, n)
    # Clip to domain if needed
    x = np.clip(x, a, b)
    weights = f(x) / np.maximum(proposal_pdf(x), 1e-12)
    estimate = np.mean(weights) * (b - a)  # adjust if proposal is not normalized over [a,b]
    # Better: if proposal is defined on [a,b]
    estimate = np.mean(f(x) / proposal_pdf(x))
    std_error = np.std(f(x) / proposal_pdf(x), ddof=1) / np.sqrt(n)
    return {
        "estimate": float(estimate),
        "std_error": float(std_error),
        "n": n,
        "method": "importance",
    }


def monte_carlo_quasi(
    f: Callable,
    a: float,
    b: float,
    n: int = 10000,
    sequence: str = "halton",
) -> Dict:
    """
    Quasi-Monte Carlo using low-discrepancy sequences.
    
    Halton sequence (base 2) gives more uniform coverage than pure random.
    Error can converge closer to 1/N instead of 1/√N in low dimensions.
    """
    if sequence == "halton":
        # Simple 1D Halton (radical inverse in base 2)
        def radical_inverse(i, base=2):
            result = 0.0
            f = 1.0 / base
            while i > 0:
                result += f * (i % base)
                i //= base
                f /= base
            return result
        
        u = np.array([radical_inverse(i) for i in range(1, n + 1)])
    else:
        # Fallback to regular grid-like spacing with jitter
        u = (np.arange(n) + 0.5) / n
    
    x = a + (b - a) * u
    estimate = (b - a) * np.mean(f(x))
    return {
        "estimate": float(estimate),
        "n": n,
        "method": f"quasi-{sequence}",
    }


def compare_methods(
    f: Callable,
    a: float,
    b: float,
    exact: Optional[float] = None,
    n: int = 5000,
    seed: int = 42,
) -> Dict:
    """
    Compare basic, stratified, and quasi-Monte Carlo on the same problem.
    """
    results = {}
    
    results["basic"] = monte_carlo_basic(f, a, b, n=n, seed=seed)
    results["stratified"] = monte_carlo_stratified(
        f, a, b, n_strata=10, n_per_stratum=n // 10, seed=seed
    )
    results["quasi"] = monte_carlo_quasi(f, a, b, n=n)
    
    if exact is not None:
        for key in results:
            results[key]["error"] = abs(results[key]["estimate"] - exact)
            results[key]["exact"] = exact
    
    return results
