"""
Numerical integration methods.
"""

import numpy as np


def integrate_trapezoidal(f, a, b, n=100):
    """Integrate f from a to b using the trapezoidal rule."""
    x = np.linspace(a, b, n + 1)
    y = f(x)
    h = (b - a) / n
    return h * (0.5 * y[0] + 0.5 * y[-1] + np.sum(y[1:-1]))


def integrate_simpson(f, a, b, n=100):
    """Integrate f from a to b using Simpson's rule (n should be even)."""
    if n % 2 != 0:
        n += 1
    x = np.linspace(a, b, n + 1)
    y = f(x)
    h = (b - a) / n
    return (h / 3) * (y[0] + y[-1] + 4 * np.sum(y[1:-1:2]) + 2 * np.sum(y[2:-1:2]))


def integrate_gaussian(f, a, b, n=5):
    """Gaussian quadrature using SciPy."""
    from scipy.integrate import fixed_quad
    result, _ = fixed_quad(f, a, b, n=n)
    return result
