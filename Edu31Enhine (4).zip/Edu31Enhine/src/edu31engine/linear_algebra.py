"""
Linear algebra utilities.
"""

import numpy as np
from scipy.linalg import solve, eig, lu, qr


def solve_system(A, b):
    """Solve the linear system Ax = b."""
    return solve(np.asarray(A, dtype=float), np.asarray(b, dtype=float))


def eigenvalues(A):
    """Compute eigenvalues of matrix A."""
    return eig(np.asarray(A, dtype=float), right=False)


def matrix_lu(A):
    """LU decomposition."""
    return lu(np.asarray(A, dtype=float))


def matrix_qr(A):
    """QR decomposition."""
    return qr(np.asarray(A, dtype=float))


def condition_number(A):
    """Condition number of matrix A."""
    return np.linalg.cond(np.asarray(A, dtype=float))
