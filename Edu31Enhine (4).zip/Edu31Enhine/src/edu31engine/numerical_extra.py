"""
Additional numerical methods.
"""

import numpy as np
from scipy.integrate import solve_ivp


def newton_raphson(f, df, x0, tol=1e-8, max_iter=50):
    """
    Newton-Raphson root finding.
    
    Parameters
    ----------
    f : callable
        Function
    df : callable
        Derivative of f
    x0 : float
        Initial guess
        
    Returns
    -------
    dict
        root, iterations, success
    """
    x = float(x0)
    for i in range(max_iter):
        fx = f(x)
        if abs(fx) < tol:
            return {"root": x, "iterations": i + 1, "success": True}
        dfx = df(x)
        if abs(dfx) < 1e-14:
            return {"root": x, "iterations": i + 1, "success": False, "error": "derivative near zero"}
        x = x - fx / dfx
    return {"root": x, "iterations": max_iter, "success": False}


def bisection(f, a, b, tol=1e-8, max_iter=100):
    """
    Bisection method for root finding. Requires f(a)*f(b) < 0.
    """
    if f(a) * f(b) >= 0:
        raise ValueError("f(a) and f(b) must have opposite signs")
    
    for i in range(max_iter):
        mid = (a + b) / 2
        if abs(f(mid)) < tol or (b - a) / 2 < tol:
            return {"root": mid, "iterations": i + 1, "success": True}
        if f(a) * f(mid) < 0:
            b = mid
        else:
            a = mid
    return {"root": (a + b) / 2, "iterations": max_iter, "success": False}


def monte_carlo_integrate(f, a, b, n=10000, seed=None):
    """
    Monte Carlo integration of f over [a, b].
    """
    rng = np.random.default_rng(seed)
    x = rng.uniform(a, b, n)
    return (b - a) * np.mean(f(x))


def runge_kutta_4(f, y0, t_span, n_steps=100):
    """
    Classic 4th-order Runge-Kutta for scalar or vector ODE y' = f(t, y).
    """
    t0, tf = t_span
    h = (tf - t0) / n_steps
    t = np.linspace(t0, tf, n_steps + 1)
    y = np.zeros((n_steps + 1, len(np.atleast_1d(y0))))
    y[0] = np.atleast_1d(y0)
    
    for i in range(n_steps):
        ti = t[i]
        yi = y[i]
        k1 = h * np.asarray(f(ti, yi))
        k2 = h * np.asarray(f(ti + h/2, yi + k1/2))
        k3 = h * np.asarray(f(ti + h/2, yi + k2/2))
        k4 = h * np.asarray(f(ti + h, yi + k3))
        y[i+1] = yi + (k1 + 2*k2 + 2*k3 + k4) / 6
    
    return t, y
