"""
Edu31Enhine — Computational Mathematics Engine
"""

__version__ = "0.2.0"

# Core modules
from .numerical import integrate_trapezoidal, integrate_simpson
from .numerical_extra import newton_raphson, bisection, monte_carlo_integrate, runge_kutta_4
from .linear_algebra import solve_system, eigenvalues
from .linear_algebra_extra import matrix_inverse, determinant, power_iteration
from .optimization import gradient_descent
from .differential_equations import solve_ode
from .statistics import descriptive_stats
from .symbolic import differentiate, integrate_symbolic, solve_equation
from .low_discrepancy import (
    halton_sequence,
    halton_sequence_nd,
    kronecker_sequence,
    sobol_1d,
    discrepancy_estimate,
    generate_sequence,
)

__all__ = [
    "integrate_trapezoidal", "integrate_simpson",
    "newton_raphson", "bisection", "monte_carlo_integrate", "runge_kutta_4",
    "solve_system", "eigenvalues", "matrix_inverse", "determinant", "power_iteration",
    "gradient_descent", "solve_ode", "descriptive_stats",
    "differentiate", "integrate_symbolic", "solve_equation",
    "generate_question", "GENERATORS",
    "monte_carlo_basic", "monte_carlo_stratified", "monte_carlo_quasi", "compare_methods",
    "halton_sequence", "halton_sequence_nd", "kronecker_sequence", "sobol_1d", "discrepancy_estimate", "generate_sequence",
]
