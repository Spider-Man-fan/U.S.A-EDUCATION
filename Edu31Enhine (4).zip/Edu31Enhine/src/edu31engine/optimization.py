"""
Optimization methods.
"""

import numpy as np
from scipy.optimize import minimize


def numerical_gradient(f, x, eps=1e-8):
    """Compute numerical gradient of f at x."""
    x = np.asarray(x, dtype=float)
    grad = np.zeros_like(x)
    for i in range(len(x)):
        xp, xm = x.copy(), x.copy()
        xp[i] += eps
        xm[i] -= eps
        grad[i] = (f(xp) - f(xm)) / (2 * eps)
    return grad


def gradient_descent(f, x0, learning_rate=0.1, max_iter=1000, tol=1e-6):
    """Simple gradient descent with numerical gradients."""
    x = np.asarray(x0, dtype=float)
    for i in range(max_iter):
        grad = numerical_gradient(f, x)
        x_new = x - learning_rate * grad
        if np.linalg.norm(x_new - x) < tol:
            return {"x": x_new, "fun": f(x_new), "n_iter": i + 1, "success": True}
        x = x_new
    return {"x": x, "fun": f(x), "n_iter": max_iter, "success": False}


def minimize_function(f, x0, method="BFGS"):
    """Minimize using SciPy."""
    return minimize(f, x0, method=method)
