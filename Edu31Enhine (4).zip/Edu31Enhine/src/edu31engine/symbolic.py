"""
Symbolic mathematics utilities using SymPy.
"""

import sympy as sp


def differentiate(expr_str: str, var: str = "x") -> str:
    """Symbolically differentiate an expression string."""
    x = sp.symbols(var)
    expr = sp.sympify(expr_str)
    return str(sp.diff(expr, x))


def integrate_symbolic(expr_str: str, var: str = "x") -> str:
    """Symbolically integrate an expression string."""
    x = sp.symbols(var)
    expr = sp.sympify(expr_str)
    return str(sp.integrate(expr, x))


def solve_equation(eq_str: str, var: str = "x") -> list:
    """Solve equation (equals zero) for the variable."""
    x = sp.symbols(var)
    expr = sp.sympify(eq_str)
    solutions = sp.solve(expr, x)
    return [str(s) for s in solutions]


def limit(expr_str: str, var: str = "x", point=0) -> str:
    """Compute a limit."""
    x = sp.symbols(var)
    expr = sp.sympify(expr_str)
    return str(sp.limit(expr, x, point))


def series_expansion(expr_str: str, var: str = "x", point=0, n=6) -> str:
    """Taylor series expansion."""
    x = sp.symbols(var)
    expr = sp.sympify(expr_str)
    return str(expr.series(x, point, n).removeO())
