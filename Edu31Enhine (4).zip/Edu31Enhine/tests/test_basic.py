"""
Basic tests for Edu31Enhine.
"""

import numpy as np
import pytest
from edu31engine.numerical import integrate_simpson
from edu31engine.linear_algebra import solve_system
from edu31engine.symbolic import differentiate


def test_simpson_exact_for_quadratic():
    def f(x):
        return x**2
    result = integrate_simpson(f, 0, 1, n=10)
    assert abs(result - 1/3) < 1e-10


def test_solve_system():
    A = [[2, 1], [1, 3]]
    b = [5, 7]
    x = solve_system(A, b)
    residual = np.dot(A, x) - b
    assert np.allclose(residual, 0, atol=1e-10)


def test_differentiate():
    deriv = differentiate("x**2 + 3*x")
    assert "2*x" in deriv or "2*x + 3" in deriv
