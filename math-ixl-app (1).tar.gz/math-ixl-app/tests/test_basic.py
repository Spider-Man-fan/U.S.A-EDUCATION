"""
Basic tests for the IXL-style math app structure.
"""

import sys
sys.path.insert(0, ".")

from src.curriculum.skill_tree import get_skills_for_grade, get_skill
from src.engine.adaptive_engine import AdaptiveEngine
from src.models.models import Grade


def test_skills_for_grade():
    skills = get_skills_for_grade("1")
    assert len(skills) >= 2
    assert all(s.grade == Grade.GRADE_1 for s in skills)


def test_get_skill():
    skill = get_skill("3.A.1")
    assert skill is not None
    assert "Multiply" in skill.title


def test_adaptive_engine_score_increases():
    engine = AdaptiveEngine("test_user", "1.A.1")
    initial = engine.progress.smart_score
    q = engine.next_question()
    result = engine.submit_answer(q, q.correct_answer)
    assert result["smart_score"] > initial
    assert result["correct"] is True
