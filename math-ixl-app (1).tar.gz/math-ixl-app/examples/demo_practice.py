"""
Demo of practicing a skill with the adaptive engine.
"""

import sys
sys.path.insert(0, "..")

from src.engine.adaptive_engine import AdaptiveEngine
from src.curriculum.skill_tree import get_skill, get_skills_for_grade


def main():
    print("=== IXL-style Math Practice Demo ===\n")

    # Show skills for grade 1
    print("Grade 1 skills:")
    for skill in get_skills_for_grade("1"):
        print(f"  {skill.id}: {skill.title}")

    print("\n--- Practicing skill 1.A.1 (Add within 10) ---\n")

    engine = AdaptiveEngine(user_id="demo_student", skill_id="1.A.1")

    for i in range(5):
        q = engine.next_question()
        print(f"Question {i+1} [{q.difficulty.value}]: {q.prompt}")
        # Simulate correct answer for demo
        result = engine.submit_answer(q, q.correct_answer)
        print(f"  → Correct! SmartScore: {result['smart_score']}\n")

    print(f"Final SmartScore: {engine.progress.smart_score}")
    print(f"Mastered: {engine.progress.mastered}")


if __name__ == "__main__":
    main()
