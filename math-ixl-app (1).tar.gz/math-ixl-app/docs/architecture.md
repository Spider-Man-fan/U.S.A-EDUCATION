# Architecture Overview

## Skill Organization (IXL-style)

```
Grade / Course
 └── Section (letter: A, B, C...)
      └── Skill (number: 1, 2, 3...)
           └── Questions (adaptive difficulty)
```

### Example Skill ID Format
- `K.A.1` → Kindergarten, Section A, Skill 1
- `3.F.2` → Grade 3, Section F, Skill 2
- `A1.B.1` → Algebra 1, Section B, Skill 1

## SmartScore Algorithm (simplified)

- Start at 0
- Correct answer: gain points (larger gains when score is low)
- Incorrect answer: lose points (smaller losses when score is low)
- Difficulty increases as SmartScore rises
- Mastery typically considered at 90–100

## Adaptive Flow

1. User selects a skill
2. Engine generates a question at current difficulty
3. User answers
4. Score updates
5. Next question difficulty adjusts
6. Repeat until mastery or user exits

## Recommended Next Steps

- Expand skill definitions for full K–8 + high school coverage
- Build real question generators per skill type
- Add persistent storage (SQLite / Postgres) for user progress
- Create a simple web UI (FastAPI + Jinja or React)
- Implement diagnostic assessment that estimates overall level
- Add skill recommendations based on prerequisites and weak areas
