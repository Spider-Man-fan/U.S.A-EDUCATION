"""
Package init for curriculum.
"""
from .skill_tree import (
    SKILLS, get_skills_for_grade, get_skills_by_strand, get_skill, GRADE_SECTIONS
)
