"""
Curriculum structure and skill tree definitions.
Modeled after IXL’s grade → section → skill organization.
"""

from typing import Dict, List
from src.models.models import Grade, Strand, Skill


# Sample skill definitions (expand this significantly in production)
SKILLS: Dict[str, Skill] = {
    # Kindergarten examples
    "K.A.1": Skill(
        id="K.A.1",
        grade=Grade.KINDERGARTEN,
        section="A",
        number=1,
        title="Count to 10",
        description="Count objects and numbers up to 10",
        strand=Strand.NUMBERS_OPERATIONS,
    ),
    "K.B.1": Skill(
        id="K.B.1",
        grade=Grade.KINDERGARTEN,
        section="B",
        number=1,
        title="Identify shapes",
        description="Recognize circles, squares, triangles, and rectangles",
        strand=Strand.GEOMETRY,
    ),

    # Grade 1 examples
    "1.A.1": Skill(
        id="1.A.1",
        grade=Grade.GRADE_1,
        section="A",
        number=1,
        title="Add within 10",
        description="Add two numbers with sums up to 10",
        strand=Strand.NUMBERS_OPERATIONS,
        prerequisites=["K.A.1"],
    ),
    "1.B.1": Skill(
        id="1.B.1",
        grade=Grade.GRADE_1,
        section="B",
        number=1,
        title="Subtract within 10",
        description="Subtract numbers within 10",
        strand=Strand.NUMBERS_OPERATIONS,
    ),

    # Grade 3 examples
    "3.A.1": Skill(
        id="3.A.1",
        grade=Grade.GRADE_3,
        section="A",
        number=1,
        title="Multiply by 2, 5, and 10",
        description="Multiplication facts for 2s, 5s, and 10s",
        strand=Strand.NUMBERS_OPERATIONS,
    ),
    "3.F.1": Skill(
        id="3.F.1",
        grade=Grade.GRADE_3,
        section="F",
        number=1,
        title="Understand fractions",
        description="Identify and represent unit fractions",
        strand=Strand.FRACTIONS,
    ),

    # Algebra 1 examples
    "A1.A.1": Skill(
        id="A1.A.1",
        grade=Grade.ALGEBRA_1,
        section="A",
        number=1,
        title="Solve one-step equations",
        description="Solve equations of the form x + a = b or ax = b",
        strand=Strand.ALGEBRA,
    ),
    "A1.B.1": Skill(
        id="A1.B.1",
        grade=Grade.ALGEBRA_1,
        section="B",
        number=1,
        title="Linear equations in slope-intercept form",
        description="Write and graph y = mx + b",
        strand=Strand.ALGEBRA,
    ),
}


def get_skills_for_grade(grade: str) -> List[Skill]:
    """Return all skills for a given grade code."""
    return [s for s in SKILLS.values() if s.grade.value == grade]


def get_skills_by_strand(strand: Strand) -> List[Skill]:
    return [s for s in SKILLS.values() if s.strand == strand]


def get_skill(skill_id: str) -> Skill:
    return SKILLS.get(skill_id)


# Section descriptions per grade (expand as needed)
GRADE_SECTIONS = {
    "K": {
        "A": "Numbers to 10",
        "B": "Shapes",
        "C": "Comparing",
    },
    "1": {
        "A": "Addition within 10",
        "B": "Subtraction within 10",
        "C": "Place value",
    },
    "3": {
        "A": "Multiplication",
        "B": "Division",
        "F": "Fractions",
        "G": "Geometry",
    },
    "A1": {
        "A": "Equations",
        "B": "Functions",
        "C": "Inequalities",
    },
}
