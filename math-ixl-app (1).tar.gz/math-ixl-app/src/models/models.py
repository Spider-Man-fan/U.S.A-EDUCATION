"""
Core data models for the IXL-style math app.
"""

from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class Grade(str, Enum):
    PRE_K = "P"
    KINDERGARTEN = "K"
    GRADE_1 = "1"
    GRADE_2 = "2"
    GRADE_3 = "3"
    GRADE_4 = "4"
    GRADE_5 = "5"
    GRADE_6 = "6"
    GRADE_7 = "7"
    GRADE_8 = "8"
    ALGEBRA_1 = "A1"
    GEOMETRY = "G"
    ALGEBRA_2 = "A2"
    PRECALCULUS = "PC"
    CALCULUS = "C"


class Strand(str, Enum):
    NUMBERS_OPERATIONS = "numbers_operations"
    ALGEBRA = "algebra"
    FRACTIONS = "fractions"
    GEOMETRY = "geometry"
    MEASUREMENT = "measurement"
    DATA_PROBABILITY = "data_probability"


class Difficulty(str, Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"
    CHALLENGE = "challenge"


class QuestionType(str, Enum):
    MULTIPLE_CHOICE = "multiple_choice"
    FILL_IN = "fill_in"
    TRUE_FALSE = "true_false"
    DRAG_DROP = "drag_drop"
    GRAPHING = "graphing"


class Skill(BaseModel):
    id: str                          # e.g. "3.A.1"
    grade: Grade
    section: str                     # e.g. "A"
    number: int                      # e.g. 1
    title: str
    description: str
    strand: Strand
    prerequisites: List[str] = Field(default_factory=list)
    standards: List[str] = Field(default_factory=list)  # e.g. CCSS codes
    estimated_minutes: int = 5


class Question(BaseModel):
    id: str
    skill_id: str
    type: QuestionType
    prompt: str
    choices: Optional[List[str]] = None
    correct_answer: Any
    explanation: Optional[str] = None
    difficulty: Difficulty = Difficulty.MEDIUM
    metadata: Dict[str, Any] = Field(default_factory=dict)


class UserProgress(BaseModel):
    user_id: str
    skill_id: str
    smart_score: int = 0             # 0–100
    questions_answered: int = 0
    questions_correct: int = 0
    current_difficulty: Difficulty = Difficulty.EASY
    mastered: bool = False
    last_practiced: Optional[str] = None


class DiagnosticLevel(BaseModel):
    user_id: str
    overall_level: float = 0.0      # e.g. 350 = mid 3rd grade
    strand_levels: Dict[Strand, float] = Field(default_factory=dict)
    recommended_skills: List[str] = Field(default_factory=list)
