"""
Adaptive practice engine inspired by IXL’s SmartScore system.
"""

import random
from typing import Optional, Dict
from src.models.models import Question, Difficulty, UserProgress, QuestionType


class AdaptiveEngine:
    def __init__(self, user_id: str, skill_id: str):
        self.user_id = user_id
        self.skill_id = skill_id
        self.progress = UserProgress(user_id=user_id, skill_id=skill_id)
        self.question_history: list = []

    def next_question(self) -> Question:
        """Select or generate the next question based on current SmartScore and difficulty."""
        difficulty = self._select_difficulty()
        question = self._generate_question(difficulty)
        self.question_history.append(question.id)
        return question

    def submit_answer(self, question: Question, user_answer) -> Dict:
        """Process an answer, update SmartScore, and return feedback."""
        correct = self._check_answer(question, user_answer)
        self.progress.questions_answered += 1
        if correct:
            self.progress.questions_correct += 1
            self._increase_score()
        else:
            self._decrease_score()

        self.progress.current_difficulty = self._select_difficulty()
        self.progress.mastered = self.progress.smart_score >= 90

        return {
            "correct": correct,
            "smart_score": self.progress.smart_score,
            "explanation": question.explanation,
            "mastered": self.progress.mastered,
        }

    def _select_difficulty(self) -> Difficulty:
        score = self.progress.smart_score
        if score < 40:
            return Difficulty.EASY
        elif score < 70:
            return Difficulty.MEDIUM
        elif score < 90:
            return Difficulty.HARD
        else:
            return Difficulty.CHALLENGE

    def _increase_score(self):
        # IXL-style: larger gains at low scores, smaller at high scores
        gain = max(1, int((100 - self.progress.smart_score) * 0.15))
        self.progress.smart_score = min(100, self.progress.smart_score + gain)

    def _decrease_score(self):
        loss = max(1, int(self.progress.smart_score * 0.08))
        self.progress.smart_score = max(0, self.progress.smart_score - loss)

    def _check_answer(self, question: Question, user_answer) -> bool:
        # Simple comparison; expand for different question types
        return str(user_answer).strip().lower() == str(question.correct_answer).strip().lower()

    def _generate_question(self, difficulty: Difficulty) -> Question:
        """Placeholder procedural generator. Replace with real generators per skill."""
        # Example: simple addition question
        if "add" in self.skill_id.lower() or "1.A" in self.skill_id:
            a = random.randint(1, 5 if difficulty == Difficulty.EASY else 10)
            b = random.randint(1, 5 if difficulty == Difficulty.EASY else 10)
            return Question(
                id=f"q_{random.randint(1000,9999)}",
                skill_id=self.skill_id,
                type=QuestionType.FILL_IN,
                prompt=f"What is {a} + {b}?",
                correct_answer=a + b,
                explanation=f"{a} + {b} = {a + b}",
                difficulty=difficulty,
            )
        # Default fallback
        return Question(
            id=f"q_{random.randint(1000,9999)}",
            skill_id=self.skill_id,
            type=QuestionType.MULTIPLE_CHOICE,
            prompt="Sample question for this skill",
            choices=["A", "B", "C", "D"],
            correct_answer="A",
            difficulty=difficulty,
        )
