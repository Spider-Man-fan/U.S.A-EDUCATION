# Math Practice App (IXL-inspired Structure)

A structured math learning platform inspired by IXL’s skill-based, adaptive practice system.

## Core Concepts (modeled after IXL)

- **Grades / Courses**: Pre-K, Kindergarten, Grades 1–8, Algebra 1, Geometry, Algebra 2, Precalculus, Calculus
- **Strands**: Numbers & Operations, Algebra & Algebraic Thinking, Fractions, Geometry, Measurement, Data & Probability
- **Skills**: Individual practice units (e.g., "Add within 20", "Solve linear equations")
- **Sections**: Letter-coded groups within a grade (A, B, C...) containing related skills
- **Adaptive Practice**: Questions adjust difficulty based on performance
- **SmartScore / Mastery**: Progress score (0–100) per skill; higher scores require harder questions
- **Diagnostic Level**: Overall working grade level estimate

## Project Structure

```
math-ixl-app/
├── src/
│   ├── models/           # Data models (Skill, Question, UserProgress, etc.)
│   ├── curriculum/       # Skill trees, grade definitions, strand mappings
│   ├── engine/           # Adaptive engine, scoring, question selection
│   └── api/              # (placeholder for FastAPI / web endpoints)
├── data/
│   ├── skills/           # Skill definitions by grade
│   ├── questions/        # Question banks or generators
│   └── users/            # Sample progress data
├── examples/
├── tests/
├── docs/
└── static/               # Frontend assets (if building a web UI)
```

## Key Features to Implement

1. **Skill Tree Navigation** — Browse by grade → section → skill
2. **Question Practice** — Serve questions, accept answers, give instant feedback
3. **Adaptive Difficulty** — Increase/decrease difficulty based on correct/incorrect
4. **Mastery Tracking** — SmartScore algorithm per skill
5. **Progress Dashboard** — Skills mastered, diagnostic level, recommendations
6. **Question Generators** — Procedural generation for infinite practice (addition, fractions, equations, etc.)

## Quick Start

```bash
pip install -r requirements.txt
python examples/demo_practice.py
```

## Sample Usage

```python
from src.curriculum.skill_tree import get_skills_for_grade
from src.engine.adaptive_engine import AdaptiveEngine

skills = get_skills_for_grade("3")
engine = AdaptiveEngine(user_id="student1", skill_id="3.A.1")
question = engine.next_question()
# ... present question, collect answer, update score
```

## License

MIT
